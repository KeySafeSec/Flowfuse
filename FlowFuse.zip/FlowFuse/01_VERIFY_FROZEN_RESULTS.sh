#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

echo "============================================================"
echo "FlowFuse — frozen paper-result verification"
echo "============================================================"

python "$ROOT/06_SUMMARIZE_THREE_SEEDS_FINAL3_ARTIFACT.py"

python - "$ROOT" <<'PY'
import json, math, sys
from pathlib import Path

root = Path(sys.argv[1])

def close(a, b, tol=5e-4):
    return abs(float(a)-float(b)) <= tol

# VulFixed: verify that the final report and main table are readable and non-empty.
vf = root / "VulFix/output/VulFixed_BPRD_PAIRED_FINAL/test"
report = json.load(open(vf/"VULFIXED_FINAL_REPORT.json", encoding="utf-8"))
table = json.load(open(vf/"TEST_MAIN_TABLE.json", encoding="utf-8"))
pred = vf/"TEST_PREDICTIONS_STRICT_PAIRED.jsonl"
n_pred = sum(1 for line in open(pred, encoding="utf-8") if line.strip())
if n_pred <= 0:
    raise SystemExit("[FAIL] VulFixed strict-paired predictions are empty")
print(f"[OK] VulFixed final report readable; strict-paired prediction rows={n_pred}")

# MegaVul: verify the frozen headline values.
mp = root / "MegaVul/run_v74_bprd_megavul_frozen_replay"
m = json.load(open(mp/"MEGAVUL_FROZEN_REPLAY_REPORT.json", encoding="utf-8"))
if m.get("zero_shot") is not True:
    raise SystemExit("[FAIL] MegaVul report is not marked zero_shot=true")
if int(m.get("mega_rows", -1)) != 1086 or int(m.get("complete_pairs", -1)) != 543:
    raise SystemExit("[FAIL] Unexpected MegaVul population")
rows = {r["condition"]: r for r in m["results"]}
expected = {
    "V74_SINGLE": (0.5108481262, 0.0873272625, 0.5985267035),
    "BPRD_BLIND": (0.6685823755, 0.3638894212, 0.7329650092),
    "BPRD_PAIRED": (0.6717703349, 0.3693785852, 0.7366482505),
}
for name, (f1,mcc,pa) in expected.items():
    r=rows[name]
    if not (close(r["F1"],f1) and close(r["MCC"],mcc) and close(r["PairAcc"],pa)):
        raise SystemExit(f"[FAIL] MegaVul {name} metric mismatch")
print("[OK] MegaVul frozen zero-shot report matches expected headline values")
print("     V74_SINGLE : F1=51.08 MCC=8.73 PairAcc=59.85")
print("     BPRD_BLIND : F1=66.86 MCC=36.39 PairAcc=73.30")
print("     BPRD_PAIRED: F1=67.18 MCC=36.94 PairAcc=73.66")

blind = rows["BPRD_BLIND"]
if int(blind.get("accepted_pairs",-1)) != 540:
    raise SystemExit("[FAIL] MegaVul BPRD_BLIND accepted_pairs != 540")
print("[OK] MegaVul BPRD_BLIND accepted_pairs=540/543")
PY

echo
echo "[PASS] Frozen FlowFuse paper-facing results verified."
