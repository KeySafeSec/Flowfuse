#!/usr/bin/env python3
"""Artifact-safe relative-path summarizer for the frozen PrimeVul BPRD FINAL3 runs."""
import csv, json, statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BPRD = ROOT / "primevul-pair" / "BPRD" / "output"
OUT = ROOT / "artifact_verification" / "primevul_three_seed"
OUT.mkdir(parents=True, exist_ok=True)

RUNS = {
    42: BPRD / "run_v74_bprd_full_relhead_seed42_protocol",
    123: BPRD / "run_v74_bprd_full_relhead_seed123_protocol",
    2026: BPRD / "run_v74_bprd_full_relhead_seed2026_protocol",
}

rows, configs = [], []
for seed, run_dir in RUNS.items():
    report_path = run_dir / "TEST_REPORT_FROZEN.json"
    config_path = run_dir / "selected_config.json"
    if not report_path.is_file() or not config_path.is_file():
        raise FileNotFoundError(f"seed {seed}: missing frozen report/config")

    report = json.load(open(report_path, encoding="utf-8"))
    config = json.load(open(config_path, encoding="utf-8"))

    if report.get("test_used_for_selection") is not False:
        raise RuntimeError(f"seed {seed}: TEST was not explicitly excluded from selection")
    if config.get("test_opened") is not False:
        raise RuntimeError(f"seed {seed}: selected_config is not a pre-TEST frozen config")

    retrieval, base, bprd = report["retrieval_test"], report["base_test"], report["bprd_test"]
    rconf, oconf = config["retrieval"], config["orientation"]
    embedded = report["selected_on_valid"]

    if embedded["retrieval"]["threshold"] != rconf["threshold"]:
        raise RuntimeError(f"seed {seed}: retrieval threshold mismatch")
    if embedded["retrieval"]["margin"] != rconf["margin"]:
        raise RuntimeError(f"seed {seed}: retrieval margin mismatch")
    if embedded["orientation"] != oconf:
        raise RuntimeError(f"seed {seed}: orientation config mismatch")
    if embedded["v74_threshold"] != config["v74_threshold"]:
        raise RuntimeError(f"seed {seed}: v7.4 threshold mismatch")

    rows.append({
        "Seed": seed,
        "PairPrec": retrieval["precision"],
        "PairRec": retrieval["recall"],
        "AcceptedPairs": retrieval["pred_pairs"],
        "TruePairsAccepted": retrieval["tp"],
        "FalsePairsAccepted": retrieval["fp"],
        "BPRDProtocolBase_F1": base["f1"],
        "BPRDProtocolBase_MCC": base["mcc"],
        "BPRDProtocolBase_AUC": base["AUC"],
        "BPRD_F1": bprd["f1"],
        "BPRD_MCC": bprd["mcc"],
        "BPRD_AUC": bprd["AUC"],
        "BPRD_PR_AUC": bprd["PR_AUC"],
        "BPRD_PC": bprd["P-C_rate"],
        "BPRD_PairAcc": bprd["PairAcc_rate"],
    })
    configs.append({"Seed": seed, **config})

def stats(key):
    vals=[float(r[key]) for r in rows]
    return statistics.mean(vals), statistics.stdev(vals)

expected = {
    42: (0.7905, 0.5869, 0.8736, 388, 386, 2),
    123:(0.8010, 0.6066, 0.8761, 388, 386, 2),
    2026:(0.7885, 0.5818, 0.8726, 388, 386, 2),
}
for r in rows:
    ef1, emcc, eauc, ea, et, ef = expected[r["Seed"]]
    checks = [
        abs(r["BPRD_F1"]-ef1) <= 0.00006,
        abs(r["BPRD_MCC"]-emcc) <= 0.00006,
        abs(r["BPRD_AUC"]-eauc) <= 0.00006,
        r["AcceptedPairs"] == ea,
        r["TruePairsAccepted"] == et,
        r["FalsePairsAccepted"] == ef,
    ]
    if not all(checks):
        raise RuntimeError(f"seed {r['Seed']}: frozen result differs from FINAL3 expectation")

with open(OUT/"bprd_three_seed_metrics_RECOMPUTED.csv","w",newline="",encoding="utf-8") as f:
    w=csv.DictWriter(f, fieldnames=list(rows[0]))
    w.writeheader(); w.writerows(rows)
json.dump({"rows":rows}, open(OUT/"bprd_three_seed_metrics_RECOMPUTED.json","w",encoding="utf-8"),
          indent=2, ensure_ascii=False)

print("PrimeVul-Pair BPRD FINAL3")
for r in rows:
    print(f"seed {r['Seed']:4d}: F1={100*r['BPRD_F1']:.2f} "
          f"MCC={100*r['BPRD_MCC']:.2f} AUC={100*r['BPRD_AUC']:.2f} "
          f"accepted={r['AcceptedPairs']} "
          f"({r['TruePairsAccepted']} true + {r['FalsePairsAccepted']} false)")
print()
print("mean ± sample SD")
for key in ("BPRD_F1","BPRD_MCC","BPRD_AUC"):
    m,s=stats(key)
    print(f"{key}: {100*m:.2f} ± {100*s:.2f}")
print(f"[OK] Recomputed files written under {OUT.relative_to(ROOT)}")
