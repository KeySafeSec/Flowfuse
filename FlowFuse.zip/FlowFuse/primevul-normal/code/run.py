# run.py (PathCL v8.4 - regenpath-fastmcc)

from __future__ import absolute_import, division, print_function
import glob

import os
import sys
import re
import csv
import json
import time
import pickle
import random
import hashlib
import logging
import argparse
import traceback
import multiprocessing
from functools import partial
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda import amp
from torch.utils.data import DataLoader, Dataset, SequentialSampler, RandomSampler, Subset
from tqdm import tqdm, trange

from sklearn.metrics import (
    recall_score, precision_score, f1_score, accuracy_score, roc_auc_score,
    confusion_matrix, matthews_corrcoef, average_precision_score
)

from transformers import (
    AdamW, get_linear_schedule_with_warmup,
    RobertaConfig, RobertaModel, RobertaTokenizerFast
)

from model import Model

torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True

# =========================
# Global Config
# =========================
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:128"
os.environ["TOKENIZERS_PARALLELISM"] = "false"
if torch.cuda.is_available():
    torch.cuda.empty_cache()

MODEL_CLASSES = {'unixcoder': (RobertaConfig, RobertaModel, RobertaTokenizerFast)}
logger = logging.getLogger(__name__)


# =========================
# Keywords / Patterns
# =========================
danger_op_keywords = {
    "strcpy", "strncpy", "sprintf", "vsprintf", "strcat", "strncat", "gets",
    "system", "popen", "exec", "execve",
    "mysql_query", "sqlite3_exec", "pqexec"
}
# 移除 ->  *  &  .  这四个高频噪声符号，只保留真正的危险 API
# 原版包含 -> * & . 导致 C++ 代码几乎每行都命中
# 修复：只保留真正的危险内存操作 API
pointer_op_keywords = {
    "malloc", "calloc", "realloc", "free", "alloca",
    "memset", "memcpy", "memmove", "memcmp",
    "read", "write", "fread", "fwrite",
    "recv", "send", "recvfrom", "sendto",
    "strcpy", "strncpy", "strcat", "strncat",
    "sprintf", "snprintf", "vsprintf",
    "gets", "fgets",
}


defense_op_patterns = {
    re.compile(r'if\s*\(\s*([a-zA-Z0-9_*->\.]+)\s*==\s*(NULL|nullptr|0)\s*\)'),
    re.compile(r'if\s*\(\s*(NULL|nullptr|0)\s*==\s*([a-zA-Z0-9_*->\.]+)\s*\)'),
    re.compile(r'if\s*\(\s*!\s*([a-zA-Z0-9_]*?(ptr|buf|ctx|node|data|list|obj|mem|addr|entry)[a-zA-Z0-9_*->\.]*)\s*\)'),
    re.compile(r'if\s*\(\s*([a-zA-Z0-9_*->\.]+)\s*!=\s*(NULL|nullptr|0)\s*\)'),
    re.compile(r'if\s*\(\s*(NULL|nullptr|0)\s*!=\s*([a-zA-Z0-9_*->\.]+)\s*\)'),
    re.compile(r'assert\s*\(\s*([a-zA-Z0-9_*->\.]+)\s*\)'),
}



# =========================
# Utils
# =========================
def set_seed(args):
    random.seed(args.seed)
    np.random.seed(args.seed)
    os.environ['PYTHONHASHSEED'] = str(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.deterministic = True


def safe_makedirs(path):
    os.makedirs(path, exist_ok=True)


def dump_json(obj, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def save_fatal_error(output_dir, stage, e):
    safe_makedirs(output_dir)
    p = os.path.join(output_dir, "fatal_errors.log")
    with open(p, "a", encoding="utf-8") as f:
        f.write("=" * 120 + "\n")
        f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] stage={stage}\n")
        f.write(repr(e) + "\n")
        f.write(traceback.format_exc() + "\n")


def model_forward_get_logits_and_extra(model, inputs):
    """
    兼容:
      - model(...) -> logits
      - model(...) -> (logits, extra_loss)
    """
    out = model(**inputs)
    if isinstance(out, tuple):
        logits = out[0]
        extra_loss = out[1] if len(out) > 1 and torch.is_tensor(out[1]) else None
    else:
        logits = out
        extra_loss = None
    return logits, extra_loss


# =========================
# Data Features
# =========================
class InputFeatures(object):
    def __init__(self, idx, input_ids, special_token_pos, global_input_ids, label,
                 vul_type, original_func,
                 raw_paths=None, raw_patch_paths=None,
                 patch_input_ids=None, patch_special_token_pos=None, has_patch=False):
        self.idx = idx
        self.input_ids = input_ids
        self.special_token_pos = special_token_pos
        self.global_input_ids = global_input_ids
        self.label = label
        self.vul_type = vul_type
        self.original_func = original_func

        self.raw_paths = raw_paths if raw_paths else []
        self.raw_patch_paths = raw_patch_paths if raw_patch_paths else []

        self.patch_input_ids = patch_input_ids if patch_input_ids else []
        self.patch_special_token_pos = patch_special_token_pos if patch_special_token_pos else []
        self.has_patch = has_patch


def _global_line_score(line: str) -> float:
    if not line or not line.strip():
        return -1.0

    s = 0.0
    if "<DEF:" in line:
        s += 4.0
    if "<USE:" in line:
        s += 4.0

    if re.search(
        r'\b(malloc|calloc|realloc|free|memcpy|memmove|memset|strcpy|strncpy|strcat|strncat|'
        r'sprintf|snprintf|vsprintf|gets|fgets|read|write|recv|send|system|popen|exec\w*)\b',
        line
    ):
        s += 3.5

    if re.search(r'^\s*(if|else|for|while|switch|case|try|catch|return|goto)\b', line):
        s += 2.0

    if re.search(r'\b(NULL|-ENOMEM|ENOMEM|assert|BUG_ON|panic)\b', line):
        s += 1.8

    if "=" in line:
        s += 0.5

    return s


def build_global_snippet_by_keylines(code_text: str, max_lines: int = 140, add_neighbors: bool = True) -> str:
    """
    从全函数中抽关键行，替代简单首尾截断。
    """
    if not code_text:
        return ""

    lines = [ln for ln in code_text.splitlines() if ln.strip()]
    if len(lines) <= max_lines:
        return "\n".join(lines)

    scored = [(i, ln, _global_line_score(ln)) for i, ln in enumerate(lines)]
    ranked = sorted(scored, key=lambda x: x[2], reverse=True)

    chosen = {0, len(lines) - 1}  # 首尾保留

    for i, ln, sc in ranked:
        if len(chosen) >= max_lines:
            break
        if sc > 0:
            chosen.add(i)

    if add_neighbors and len(chosen) < max_lines:
        for i, ln, sc in ranked:
            if len(chosen) >= max_lines:
                break
            if sc <= 0:
                continue
            for j in (i - 1, i + 1):
                if 0 <= j < len(lines):
                    chosen.add(j)
                    if len(chosen) >= max_lines:
                        break

    if len(chosen) < max_lines:
        for i in range(len(lines)):
            if len(chosen) >= max_lines:
                break
            chosen.add(i)

    return "\n".join(lines[i] for i in sorted(chosen))

def text_to_tokens_and_special_pos(text_str, tokenizer, args):
    special_token_spans = defaultdict(list)

    # DANGER
    for op in danger_op_keywords:
        try:
            pattern = re.compile(r'\b' + re.escape(op) + r'\b')
            for m in pattern.finditer(text_str):
                special_token_spans['[DANGER_OP]'].append(m.span())
        except re.error:
            pass

    # POINTER
    for op in pointer_op_keywords:
        try:
            if op in ['->', '*', '&', '.']:
                pattern = re.compile(re.escape(op))
            else:
                pattern = re.compile(r'\b' + re.escape(op) + r'\b')
            for m in pattern.finditer(text_str):
                special_token_spans['[POINTER_OP]'].append(m.span())
        except re.error:
            pass

    # DEFENSE
    for pattern in defense_op_patterns:
        for m in pattern.finditer(text_str):
            special_token_spans['[DEFENSE_OP]'].append(m.span())

    # DATA_FLOW from <DEF:...> / <USE:...> tags in path text
    for m in re.finditer(r'<\s*(DEF|USE)\s*:[^>]*>', text_str):
        special_token_spans['[DATA_FLOW]'].append(m.span())

    all_spans = []
    for t, spans in special_token_spans.items():
        for s, e in spans:
            all_spans.append((s, e, t))
    all_spans.sort()

    # merge overlaps
    merged = []
    if all_spans:
        cur = all_spans[0]
        for i in range(1, len(all_spans)):
            nxt = all_spans[i]
            if nxt[0] < cur[1]:
                ns, ne = min(cur[0], nxt[0]), max(cur[1], nxt[1])
                types = {cur[2], nxt[2]}
                if '[DANGER_OP]' in types:
                    nt = '[DANGER_OP]'
                elif '[DEFENSE_OP]' in types:
                    nt = '[DEFENSE_OP]'
                elif '[DATA_FLOW]' in types:
                    nt = '[DATA_FLOW]'
                else:
                    nt = '[POINTER_OP]'
                cur = (ns, ne, nt)
            else:
                merged.append(cur)
                cur = nxt
        merged.append(cur)

    parts, last = [], 0
    for s, e, t in merged:
        if s > last:
            parts.append(text_str[last:s])
        parts.append(t)
        last = e
    if last < len(text_str):
        parts.append(text_str[last:])
    enhanced_text = "".join(parts)

    # tokenize
    seq_tokens = tokenizer.tokenize(enhanced_text)
    max_len = args.block_size - 2
    if len(seq_tokens) > max_len:
        half = max_len // 2
        seq_tokens = seq_tokens[:half] + seq_tokens[-(half + max_len % 2):]

    final_tokens = [tokenizer.cls_token] + seq_tokens + [tokenizer.sep_token]
    seq_ids = tokenizer.convert_tokens_to_ids(final_tokens)
    seq_ids += [tokenizer.pad_token_id] * (args.block_size - len(seq_ids))
    seq_ids = seq_ids[:args.block_size]

    # special positions
    pos_info = defaultdict(list)
    special_token_ids = {
        '[DANGER_OP]': tokenizer.convert_tokens_to_ids('[DANGER_OP]'),
        '[POINTER_OP]': tokenizer.convert_tokens_to_ids('[POINTER_OP]'),
        '[DEFENSE_OP]': tokenizer.convert_tokens_to_ids('[DEFENSE_OP]'),
        '[DATA_FLOW]': tokenizer.convert_tokens_to_ids('[DATA_FLOW]'),
    }
    for token_type, token_id_val in special_token_ids.items():
        for i, token_id in enumerate(seq_ids):
            if token_id == token_id_val:
                pos_info[token_type].append(i)

    return seq_ids, pos_info


def convert_examples_to_features(js, path_dict, tokenizer, args):
    try:
        current_idx = js.get('idx')
        idx_label = int(js.get('target'))
        vul_type = js.get('vul_type', 'unknown')
        original_func = js.get('func', '') or js.get('code', '') or js.get('func_main', '')

        if idx_label not in {0, 1}:
            return None, f"Invalid target label: {idx_label}"

        sample_entry = path_dict.get(current_idx)
        if sample_entry is None:
            if isinstance(current_idx, str) and current_idx.isdigit():
                sample_entry = path_dict.get(int(current_idx))
            elif isinstance(current_idx, int):
                sample_entry = path_dict.get(str(current_idx))
        if sample_entry is None:
            return None, f"IDX {current_idx} not found in path_dict"

        max_paths_main = getattr(args, "max_paths_main", getattr(args, "max_paths", 15))
        max_paths_patch = getattr(args, "max_paths_patch", min(3, max_paths_main))
        use_patch_diff_only = bool(getattr(args, "use_patch_diff_only", False))
        max_global_lines = int(getattr(args, "max_global_lines", 140))

        def uniq_keep_order(lst):
            seen = set()
            out = []
            for x in (lst or []):
                if isinstance(x, str):
                    k = x.strip()
                else:
                    k = str(x).strip() if x is not None else ""
                if not k:
                    continue
                if k not in seen:
                    seen.add(k)
                    out.append(k)
            return out

        if isinstance(sample_entry, dict):
            rec = sample_entry
        else:
            return None, f"sample_entry invalid type: {type(sample_entry)}"

        # 主路径 / patch路径
        main_paths = uniq_keep_order(rec.get('path_token', []))
        patch_paths = uniq_keep_order(rec.get('patch_path_token', []))
        has_patch_flag = bool(rec.get('has_patch', False))

        if not main_paths:
            return None, "path_token is empty"

        main_keep = main_paths[:max_paths_main]

        all_seq_ids, all_pos_info = [], []
        for path_code_str in main_keep:
            seq_ids, pos_info = text_to_tokens_and_special_pos(path_code_str, tokenizer, args)
            all_seq_ids.append(seq_ids)
            all_pos_info.append(pos_info)

        if not all_seq_ids:
            return None, "No valid main path sequences generated"

        # ---- patch路径 ----
        patch_seq_ids, patch_pos_info = [], []
        has_patch = bool(has_patch_flag and len(patch_paths) > 0)

        if has_patch:
            if use_patch_diff_only:
                main_set = set(main_paths)
                patch_only = [p for p in patch_paths if p not in main_set]
                patch_keep = patch_only[:max_paths_patch]
                if not patch_keep:
                    patch_keep = patch_paths[:min(2, max_paths_patch)]
            else:
                patch_keep = patch_paths[:max_paths_patch]

            for patch_code_str in patch_keep:
                p_ids, p_pos = text_to_tokens_and_special_pos(patch_code_str, tokenizer, args)
                patch_seq_ids.append(p_ids)
                patch_pos_info.append(p_pos)

            if not patch_seq_ids:
                has_patch = False

        # ---- 全局流（关键片段抽取优先）----
        global_text = original_func if isinstance(original_func, str) else ""
        global_snippet = build_global_snippet_by_keylines(
            global_text,
            max_lines=max_global_lines,
            add_neighbors=True
        )

        global_tokens = tokenizer.tokenize(global_snippet)
        max_len_global = args.block_size - 2
        if len(global_tokens) > max_len_global:
            # 二次兜底：仍超长时才首尾截断
            half = max_len_global // 2
            global_tokens = global_tokens[:half] + global_tokens[-(half + max_len_global % 2):]

        global_final_tokens = [tokenizer.cls_token] + global_tokens + [tokenizer.sep_token]
        global_input_ids = tokenizer.convert_tokens_to_ids(global_final_tokens)
        global_input_ids += [tokenizer.pad_token_id] * (args.block_size - len(global_input_ids))
        global_input_ids = global_input_ids[:args.block_size]

        return InputFeatures(
            current_idx, all_seq_ids, all_pos_info, global_input_ids, idx_label,
            vul_type, original_func,
            raw_paths=main_keep,
            raw_patch_paths=patch_paths[:max_paths_patch] if has_patch else [],
            patch_input_ids=patch_seq_ids,
            patch_special_token_pos=patch_pos_info,
            has_patch=has_patch,
        ), None


    except Exception as e:
        return None, f"Unhandled exception for idx={js.get('idx', 'N/A')}: {e}\n{traceback.format_exc()}"




def _process_line_wrapper(line_info, **kwargs):
    line_index, line_content = line_info
    use_cache = kwargs['use_cache']
    cache_dir = kwargs['cache_dir']
    worker_func_partial = kwargs['worker_func_partial']

    line_strip = line_content.strip()
    if not line_strip:
        return None, "Empty line"

    CACHE_VERSION = "v8_4_regenpath_fastmcc"

    cache_key = hashlib.md5(f"{line_strip}-{line_index}-{CACHE_VERSION}".encode('utf-8')).hexdigest()
    cache_file = os.path.join(cache_dir, f"{cache_key}.pkl")

    if use_cache and os.path.exists(cache_file):
        try:
            with open(cache_file, 'rb') as f:
                return pickle.load(f)
        except Exception:
            pass

    try:
        js = json.loads(line_strip)
        if 'idx' not in js:
            js['idx'] = f"line_{line_index}"
        feature, reason = worker_func_partial(js=js)

        if use_cache and feature is not None:
            safe_makedirs(cache_dir)
            with open(cache_file, 'wb') as f:
                pickle.dump((feature, reason), f)

        return feature, reason
    except Exception as e:
        return None, f"JSON/Cache error on line {line_index}: {e}"


# =========================
# Dataset
# =========================
class TextDataset(Dataset):
    def __init__(self, tokenizer, args, file_path, pkl_file, use_cache=False, cache_dir='cached_features', task_name=""):
        self.tokenizer = tokenizer
        self.args = args
        self.examples = []
        self.skipped_reasons = Counter()

        lg = logging.getLogger(f"{__name__}.TextDataset.{task_name}")
        lg.info(f"[{task_name}] 加载路径字典: {pkl_file}")

        # ===== 分片缓存参数 =====
        use_shard_cache = bool(getattr(args, "use_shard_cache", False))
        shard_size = int(getattr(args, "shard_size", 10000))
        manifest_path = os.path.join(cache_dir, "_manifest.json")

        def _build_data_sig():
            return hashlib.md5(
                f"{file_path}|{pkl_file}|{self.args.block_size}|"
                f"{getattr(self.args, 'max_paths_main', getattr(self.args, 'max_paths', 15))}|"
                f"{getattr(self.args, 'max_paths_patch', 3)}|"
                f"{int(getattr(self.args, 'max_global_lines', 140))}|"
                f"{bool(getattr(self.args, 'use_patch_diff_only', False))}|"
                f"v8_4_regenpath_fastmcc".encode("utf-8")

            ).hexdigest()

        # ===== 1) 加载 path_dict =====
        try:
            with open(pkl_file, 'rb') as f:
                path_dict = pickle.load(f)

            # 兼容：若pkl是 list[dict]，转成 idx->record
            if isinstance(path_dict, list):
                new_map = {}
                for rec in path_dict:
                    if not isinstance(rec, dict):
                        continue
                    ridx = rec.get("idx")
                    if ridx is None:
                        continue
                    new_map[ridx] = rec
                    if isinstance(ridx, str) and ridx.isdigit():
                        new_map[int(ridx)] = rec
                    elif isinstance(ridx, int):
                        new_map[str(ridx)] = rec
                path_dict = new_map

        except Exception as e:
            lg.error(f"无法加载 PKL 文件 {pkl_file}: {e}")
            return

        # ===== 2) 加载 JSONL 行 =====
        lg.info(f"[{task_name}] 加载数据源: {file_path}")
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = list(enumerate(f))
        except Exception as e:
            lg.error(f"无法加载 JSONL 文件 {file_path}: {e}")
            return

        if use_cache:
            safe_makedirs(cache_dir)

        # ===== 3) 优先读取分片聚合缓存 =====
        if use_cache and use_shard_cache and os.path.exists(manifest_path):
            try:
                with open(manifest_path, "r", encoding="utf-8") as f:
                    manifest = json.load(f)

                old_sig = manifest.get("data_sig", "")
                cur_sig = _build_data_sig()

                if old_sig == cur_sig:
                    shard_files = sorted(glob.glob(os.path.join(cache_dir, "shard_*.pkl")))
                    if shard_files:
                        for sf in tqdm(shard_files, desc=f"[{task_name}] 读取分片缓存"):
                            with open(sf, "rb") as f:
                                part = pickle.load(f)
                            self.examples.extend(part.get("examples", []))
                            self.skipped_reasons.update(Counter(part.get("skipped_reasons", {})))

                        lg.info(f"[{task_name}] 命中分片缓存: shards={len(shard_files)}, examples={len(self.examples)}")
                        return
                    else:
                        lg.warning(f"[{task_name}] manifest存在但无shard文件，回退重建")
                else:
                    lg.warning(f"[{task_name}] 分片缓存签名不匹配，回退重建")
            except Exception as e:
                lg.warning(f"[{task_name}] 读取分片缓存失败，回退重建: {e}")

        # ===== 4) 常规处理（支持小文件cache），并带失败回退单进程 =====
        worker_func = partial(convert_examples_to_features, path_dict=path_dict, tokenizer=tokenizer, args=args)
        process_line_func = partial(
            _process_line_wrapper,
            use_cache=use_cache,
            cache_dir=cache_dir,
            worker_func_partial=worker_func
        )

        def _run_multiprocess():
            with ProcessPoolExecutor(max_workers=args.num_preprocessing_workers) as executor:
                results = tqdm(
                    executor.map(process_line_func, lines, chunksize=args.preprocessing_chunksize),
                    total=len(lines),
                    desc=f"[{task_name}] 转换特征"
                )
                for feature, reason in results:
                    if feature:
                        self.examples.append(feature)
                    else:
                        self.skipped_reasons[reason or "Unknown"] += 1

        def _run_singleprocess():
            for li in tqdm(lines, total=len(lines), desc=f"[{task_name}] 转换特征(单进程)"):
                feature, reason = process_line_func(li)
                if feature:
                    self.examples.append(feature)
                else:
                    self.skipped_reasons[reason or "Unknown"] += 1

        try:
            if int(getattr(args, "num_preprocessing_workers", 0)) > 0:
                _run_multiprocess()
            else:
                _run_singleprocess()
        except Exception as e:
            lg.warning(f"[{task_name}] 多进程失败，自动回退单进程: {e}")
            self.examples = []
            self.skipped_reasons = Counter()
            _run_singleprocess()

        # ===== 5) 首次构建后写入分片聚合缓存 =====
        if use_cache and use_shard_cache and self.examples:
            try:
                # 清理旧shard
                for old in glob.glob(os.path.join(cache_dir, "shard_*.pkl")):
                    try:
                        os.remove(old)
                    except Exception:
                        pass

                total = len(self.examples)
                n_shards = (total + shard_size - 1) // shard_size

                for sid in tqdm(range(n_shards), desc=f"[{task_name}] 写入分片缓存"):
                    s = sid * shard_size
                    e = min((sid + 1) * shard_size, total)
                    shard_obj = {
                        "examples": self.examples[s:e],
                        "skipped_reasons": {}
                    }
                    sf = os.path.join(cache_dir, f"shard_{sid:05d}.pkl")
                    with open(sf, "wb") as f:
                        pickle.dump(shard_obj, f, protocol=pickle.HIGHEST_PROTOCOL)

                manifest = {
                    "task": task_name,
                    "num_examples": len(self.examples),
                    "num_skipped": int(sum(self.skipped_reasons.values())),
                    "skipped_reasons": dict(self.skipped_reasons),
                    "n_shards": n_shards,
                    "shard_size": shard_size,
                    "data_sig": _build_data_sig(),
                    "created_at": time.strftime("%Y-%m-%d %H:%M:%S")
                }
                with open(manifest_path, "w", encoding="utf-8") as f:
                    json.dump(manifest, f, ensure_ascii=False, indent=2)

                lg.info(f"[{task_name}] 分片缓存写入完成: shards={n_shards}, path={cache_dir}")
            except Exception as e:
                lg.warning(f"[{task_name}] 写入分片缓存失败: {e}")

        lg.info(f"[{task_name}] 完成: 加载 {len(self.examples)}，跳过 {sum(self.skipped_reasons.values())}")
        if self.skipped_reasons:
            lg.warning(f"[{task_name}] 跳过原因 Top10: {self.skipped_reasons.most_common(10)}")

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, i):
        ex = self.examples[i]

        # ====== 空代码兜底 ======
        if not ex.original_func or len(ex.original_func.strip()) < 30:
            pad = self.args.block_size
            return {
                'path_ids': [[self.tokenizer.pad_token_id] * pad],
                'danger_mask': [[0] * pad],
                'pointer_mask': [[0] * pad],
                'defense_mask': [[0] * pad],
                'data_mask': [[0] * pad],
                'global_ids': [self.tokenizer.pad_token_id] * pad,
                'vuln_label': -100,
                'original_index': i,
                'patch_ids': [],
                'patch_danger_mask': [],
                'patch_pointer_mask': [],
                'patch_defense_mask': [],
                'patch_data_mask': [],
                'has_patch': False,
            }

        path_ids = [p[:self.args.block_size] for p in ex.input_ids]

        danger_masks, pointer_masks, defense_masks, data_masks = [], [], [], []
        for pos_info in ex.special_token_pos:
            d = [0] * self.args.block_size
            p = [0] * self.args.block_size
            f = [0] * self.args.block_size
            da = [0] * self.args.block_size
            for pos in pos_info.get('[DANGER_OP]', []):
                if 0 <= pos < self.args.block_size: d[pos] = 1
            for pos in pos_info.get('[POINTER_OP]', []):
                if 0 <= pos < self.args.block_size: p[pos] = 1
            for pos in pos_info.get('[DEFENSE_OP]', []):
                if 0 <= pos < self.args.block_size: f[pos] = 1
            for pos in pos_info.get('[DATA_FLOW]', []):
                if 0 <= pos < self.args.block_size: da[pos] = 1
            danger_masks.append(d)
            pointer_masks.append(p)
            defense_masks.append(f)
            data_masks.append(da)

        patch_ids = [p[:self.args.block_size] for p in ex.patch_input_ids]
        p_danger, p_pointer, p_defense, p_data = [], [], [], []
        for pos_info in ex.patch_special_token_pos:
            d = [0] * self.args.block_size
            p = [0] * self.args.block_size
            f = [0] * self.args.block_size
            da = [0] * self.args.block_size
            for pos in pos_info.get('[DANGER_OP]', []):
                if 0 <= pos < self.args.block_size: d[pos] = 1
            for pos in pos_info.get('[POINTER_OP]', []):
                if 0 <= pos < self.args.block_size: p[pos] = 1
            for pos in pos_info.get('[DEFENSE_OP]', []):
                if 0 <= pos < self.args.block_size: f[pos] = 1
            for pos in pos_info.get('[DATA_FLOW]', []):
                if 0 <= pos < self.args.block_size: da[pos] = 1
            p_danger.append(d)
            p_pointer.append(p)
            p_defense.append(f)
            p_data.append(da)

        return {
            'path_ids': path_ids,
            'danger_mask': danger_masks,
            'pointer_mask': pointer_masks,
            'defense_mask': defense_masks,
            'data_mask': data_masks,
            'global_ids': ex.global_input_ids,
            'vuln_label': ex.label,
            'original_index': i,
            'patch_ids': patch_ids,
            'patch_danger_mask': p_danger,
            'patch_pointer_mask': p_pointer,
            'patch_defense_mask': p_defense,
            'patch_data_mask': p_data,
            'has_patch': ex.has_patch,
        }



def collate_fn(batch, pad_token_id, max_paths_main, max_paths_patch, path_dropout_rate=0.0):
    original_indices = [item['original_index'] for item in batch]

    path_ids_list = [item['path_ids'] for item in batch]
    danger_mask_list = [item['danger_mask'] for item in batch]
    pointer_mask_list = [item['pointer_mask'] for item in batch]
    defense_mask_list = [item['defense_mask'] for item in batch]
    data_mask_list = [item['data_mask'] for item in batch]

    global_ids_list = [item['global_ids'] for item in batch]
    vuln_labels_list = [item['vuln_label'] for item in batch]

    # patch
    has_patch_list = [item.get('has_patch', False) for item in batch]
    patch_ids_list = [item.get('patch_ids', []) for item in batch]
    patch_danger_list = [item.get('patch_danger_mask', []) for item in batch]
    patch_pointer_list = [item.get('patch_pointer_mask', []) for item in batch]
    patch_defense_list = [item.get('patch_defense_mask', []) for item in batch]
    patch_data_list = [item.get('patch_data_mask', []) for item in batch]

    # Path Dropout（只对主路径）
    if path_dropout_rate > 0:
        for i in range(len(path_ids_list)):
            num_paths = len(path_ids_list[i])
            if num_paths > 1:
                num_to_keep = max(1, int(num_paths * (1.0 - path_dropout_rate)))
                if num_to_keep < num_paths:
                    idx_keep = sorted(random.sample(range(num_paths), num_to_keep))
                    path_ids_list[i] = [path_ids_list[i][j] for j in idx_keep]
                    danger_mask_list[i] = [danger_mask_list[i][j] for j in idx_keep]
                    pointer_mask_list[i] = [pointer_mask_list[i][j] for j in idx_keep]
                    defense_mask_list[i] = [defense_mask_list[i][j] for j in idx_keep]
                    data_mask_list[i] = [data_mask_list[i][j] for j in idx_keep]

    batch_size = len(batch)
    block_size = len(path_ids_list[0][0]) if path_ids_list and path_ids_list[0] else 0
    actual_max_paths = min(max((len(p) for p in path_ids_list), default=0), max_paths_main)

    # ---- 主路径张量 ----
    path_ids_tensor = torch.full((batch_size, actual_max_paths, block_size), pad_token_id, dtype=torch.long)
    danger_mask_tensor = torch.zeros((batch_size, actual_max_paths, block_size), dtype=torch.long)
    pointer_mask_tensor = torch.zeros((batch_size, actual_max_paths, block_size), dtype=torch.long)
    defense_mask_tensor = torch.zeros((batch_size, actual_max_paths, block_size), dtype=torch.long)
    data_mask_tensor = torch.zeros((batch_size, actual_max_paths, block_size), dtype=torch.long)
    path_mask_tensor = torch.zeros((batch_size, actual_max_paths), dtype=torch.float)

    for i in range(batch_size):
        t = min(len(path_ids_list[i]), actual_max_paths)
        if t > 0:
            path_ids_tensor[i, :t] = torch.tensor(path_ids_list[i][:t], dtype=torch.long)
            danger_mask_tensor[i, :t] = torch.tensor(danger_mask_list[i][:t], dtype=torch.long)
            pointer_mask_tensor[i, :t] = torch.tensor(pointer_mask_list[i][:t], dtype=torch.long)
            defense_mask_tensor[i, :t] = torch.tensor(defense_mask_list[i][:t], dtype=torch.long)
            data_mask_tensor[i, :t] = torch.tensor(data_mask_list[i][:t], dtype=torch.long)
            path_mask_tensor[i, :t] = 1.0

    path_attn_mask = (path_ids_tensor != pad_token_id).long()

    # ---- patch 路径张量 ----
    any_has_patch = any(has_patch_list)
    patch_ids_tensor = None
    patch_attn_mask = None
    patch_mask_tensor = None
    patch_danger_tensor = None
    patch_pointer_tensor = None
    patch_defense_tensor = None
    patch_data_tensor = None

    if any_has_patch:
        patch_max_paths = min(
            max((len(p) for p in patch_ids_list if p), default=0),
            max_paths_patch
        )

        if patch_max_paths > 0:
            patch_ids_tensor = torch.full((batch_size, patch_max_paths, block_size), pad_token_id, dtype=torch.long)
            patch_danger_tensor = torch.zeros((batch_size, patch_max_paths, block_size), dtype=torch.long)
            patch_pointer_tensor = torch.zeros((batch_size, patch_max_paths, block_size), dtype=torch.long)
            patch_defense_tensor = torch.zeros((batch_size, patch_max_paths, block_size), dtype=torch.long)
            patch_data_tensor = torch.zeros((batch_size, patch_max_paths, block_size), dtype=torch.long)
            patch_mask_tensor = torch.zeros((batch_size, patch_max_paths), dtype=torch.float)

            for i in range(batch_size):
                if has_patch_list[i] and patch_ids_list[i]:
                    t = min(len(patch_ids_list[i]), patch_max_paths)
                    patch_ids_tensor[i, :t] = torch.tensor(patch_ids_list[i][:t], dtype=torch.long)
                    patch_danger_tensor[i, :t] = torch.tensor(patch_danger_list[i][:t], dtype=torch.long)
                    patch_pointer_tensor[i, :t] = torch.tensor(patch_pointer_list[i][:t], dtype=torch.long)
                    patch_defense_tensor[i, :t] = torch.tensor(patch_defense_list[i][:t], dtype=torch.long)
                    patch_data_tensor[i, :t] = torch.tensor(patch_data_list[i][:t], dtype=torch.long)
                    patch_mask_tensor[i, :t] = 1.0

            patch_attn_mask = (patch_ids_tensor != pad_token_id).long()
        else:
            any_has_patch = False

    # ---- 全局流 ----
    global_ids_tensor = torch.tensor(global_ids_list, dtype=torch.long)
    global_attn_mask = (global_ids_tensor != pad_token_id).long()
    vuln_labels = torch.tensor(vuln_labels_list, dtype=torch.long)

    result = {
        'path_ids': path_ids_tensor,
        'path_attention_mask': path_attn_mask,
        'path_mask': path_mask_tensor,
        'danger_mask': danger_mask_tensor,
        'pointer_mask': pointer_mask_tensor,
        'defense_mask': defense_mask_tensor,
        'data_mask': data_mask_tensor,
        'global_ids': global_ids_tensor,
        'global_attention_mask': global_attn_mask,
        'vuln_labels': vuln_labels,
        'original_indices': original_indices,
    }

    if any_has_patch:
        result['patch_path_ids'] = patch_ids_tensor
        result['patch_path_attention_mask'] = patch_attn_mask
        result['patch_path_mask'] = patch_mask_tensor
        result['patch_danger_mask'] = patch_danger_tensor
        result['patch_pointer_mask'] = patch_pointer_tensor
        result['patch_defense_mask'] = patch_defense_tensor
        result['patch_data_mask'] = patch_data_tensor

    return result




# =========================
# Evaluate / Error Analysis
# =========================
def save_error_analysis(args, dataloader, indices, labels, preds, probs, task_name):
    dataset = dataloader.dataset
    errors = []

    for i in range(len(preds)):
        if preds[i] == labels[i]:
            continue

        ex = None
        idx_in_loader = indices[i]

        try:
            if isinstance(dataset, Subset):
                ex = dataset.dataset.examples[idx_in_loader]
            else:
                ex = dataset.examples[idx_in_loader]
        except Exception:
            ex = None

        raw_paths = getattr(ex, 'raw_paths', []) if ex else []
        raw_patch_paths = getattr(ex, 'raw_patch_paths', []) if ex else []

        errors.append({
            "id": getattr(ex, 'idx', idx_in_loader) if ex else idx_in_loader,
            "true": int(labels[i]),
            "label": int(labels[i]),   # 兼容旧分析脚本
            "pred": int(preds[i]),
            "conf": float(probs[i]),
            "prob": float(probs[i]),   # 兼容旧分析脚本
            "type": getattr(ex, 'vul_type', 'unknown') if ex else 'unknown',

            # 原函数，建议至少放长一点，避免截断误判
            "func": (getattr(ex, 'original_func', '')[:3000] if ex else ""),

            # path 视角
            "num_paths": len(raw_paths),
            "paths_preview": raw_paths[:3],   # 前3条主路径预览
            "has_patch": bool(getattr(ex, 'has_patch', False)) if ex else False,
            "num_patch_paths": len(raw_patch_paths),
            "patch_paths_preview": raw_patch_paths[:2],
        })

    out_name = f"errors_{task_name.replace('/', '_').replace(' ', '_')}.jsonl"
    out_path = os.path.join(args.output_dir, out_name)
    with open(out_path, 'w', encoding='utf-8') as f:
        for err in errors:
            f.write(json.dumps(err, ensure_ascii=False) + '\n')

    logger.info(f"[{task_name}] 错误样本已保存: {out_path}, count={len(errors)}")

def search_best_threshold(all_labels, all_probs, metric="mcc",
                          t_min=0.05, t_max=0.95, t_step=0.01):
    if t_step <= 0:
        t_step = 0.01
    if t_max < t_min:
        t_min, t_max = t_max, t_min

    thresholds = np.arange(t_min, t_max + 1e-12, t_step)

    best_threshold = 0.5
    best_score = -1e18

    for t in thresholds:
        preds = [1 if p >= t else 0 for p in all_probs]

        if metric == "f1":
            score = f1_score(all_labels, preds, zero_division=0)
        elif metric == "recall":
            score = recall_score(all_labels, preds, zero_division=0)
        elif metric == "precision":
            score = precision_score(all_labels, preds, zero_division=0)
        else:
            score = matthews_corrcoef(all_labels, preds)

        if score > best_score:
            best_score = score
            best_threshold = float(t)

    return float(best_threshold), float(best_score)
# =========================
# Temperature Calibration  ★ 新增
# =========================
def compute_vds(all_labels, all_probs, target_fpr=0.0005):
    """
    VD-S (Weissberg ICSE'26): FNR% at fixed FPR=0.05%.
    Lower is better. 100 = miss all vulns.
    """
    from sklearn.metrics import roc_curve
    if len(set(all_labels)) < 2:
        return 100.0
    fpr_arr, tpr_arr, _ = roc_curve(all_labels, all_probs)
    idx = np.where(fpr_arr <= target_fpr)[0]
    if len(idx) == 0:
        return 100.0
    best_idx = idx[-1]
    fnr = 1.0 - tpr_arr[best_idx]
    return float(fnr * 100.0)


def compute_bacc(all_labels, all_preds):
    """Balanced Accuracy = (TPR + TNR) / 2"""
    tn, fp, fn, tp = confusion_matrix(all_labels, all_preds, labels=[0, 1]).ravel()
    tpr = tp / max(tp + fn, 1)
    tnr = tn / max(tn + fp, 1)
    return (tpr + tnr) / 2.0


class TemperatureScaler(nn.Module):
    def __init__(self):
        super().__init__()
        # 用 log 空间参数化，确保 temperature 永远为正
        self.log_temperature = nn.Parameter(torch.zeros(1))  # exp(0) = 1.0

    def forward(self, logits):
        # clamp 防止极端值
        temp = torch.exp(self.log_temperature).clamp(min=0.1, max=10.0)
        return logits / temp

    @property
    def temperature(self):
        return torch.exp(self.log_temperature).clamp(min=0.1, max=10.0)



def calibrate_temperature(model, valid_loader, args, max_iters=50):
    """在验证集上学习最优温度参数，使NLL最小化。"""
    model.eval()
    logits_list, labels_list = [], []

    with torch.no_grad():
        for batch in tqdm(valid_loader, desc="Collecting logits for calibration", leave=False):
            inputs = {k: v.to(args.device) for k, v in batch.items()
                      if isinstance(v, torch.Tensor) and k != 'original_indices'}
            inputs["return_aux"] = False
            model_unwrapped = model.module if hasattr(model, 'module') else model

            with torch.cuda.amp.autocast(enabled=args.fp16):
                out = model_unwrapped(**inputs)
                logits = out[0] if isinstance(out, tuple) else out

            labs = inputs["vuln_labels"]
            valid_mask = (labs >= 0)
            if valid_mask.sum() > 0:
                logits_list.append(logits[valid_mask].float().cpu())
                labels_list.append(labs[valid_mask].cpu())

    if not logits_list:
        logger.warning("[Calibrate] 无有效样本，跳过校准")
        return 1.0

    all_logits = torch.cat(logits_list, dim=0)
    all_labels = torch.cat(labels_list, dim=0)

    scaler = TemperatureScaler().to(args.device)
    optimizer = torch.optim.LBFGS([scaler.log_temperature], lr=0.01, max_iter=max_iters)
    nll = nn.CrossEntropyLoss()

    _logits = all_logits.to(args.device)
    _labels = all_labels.to(args.device)

    def closure():
        optimizer.zero_grad()
        loss = nll(scaler(_logits), _labels)
        loss.backward()
        return loss

    optimizer.step(closure)

    learned_temp = scaler.temperature.item()

    # 安全检查：温度必须在合理范围内
    if learned_temp < 0.1 or learned_temp > 10.0:
        logger.warning(
            f"[Calibrate] 温度异常: {learned_temp:.4f}，回退到 1.0"
        )
        return 1.0

    logger.info(f"[Calibrate] learned temperature = {learned_temp:.4f}")
    return learned_temp


def evaluate(args, model, eval_dataloader, tokenizer=None, is_test=False,
             task_name="", error_analysis=False, save_preds_path=None,
             forced_threshold=None, temperature=1.0,
             search_metric=None):
    """
    search_metric: 覆盖 args.threshold_metric，用于 oracle 评估时
                   按不同指标搜 threshold（如 "f1" / "mcc"）
    """
    model.eval()

    all_preds = []
    all_labels = []
    all_probs = []
    all_indices = []
    eval_loss_sum = 0.0
    eval_steps = 0

    for batch in tqdm(eval_dataloader, desc=f"Eval {task_name}", leave=False):
        inputs = {k: v.to(args.device) for k, v in batch.items()
                  if isinstance(v, torch.Tensor) and k != 'original_indices'}
        inputs["return_aux"] = False
        batch_indices = batch.get('original_indices', [])

        with torch.no_grad():
            with amp.autocast(enabled=args.fp16):
                model_unwrapped = model.module if hasattr(model, 'module') else model
                out = model_unwrapped(**inputs)

                logits = out[0] if isinstance(out, tuple) else out
                labels = inputs["vuln_labels"]

                valid_mask = (labels >= 0)
                if valid_mask.sum() == 0:
                    continue

                criterion = getattr(args, "criterion", None)
                if criterion is not None:
                    loss = criterion(logits[valid_mask], labels[valid_mask])
                else:
                    loss = F.cross_entropy(logits[valid_mask], labels[valid_mask])

        eval_loss_sum += loss.item()
        eval_steps += 1

        scaled_logits = logits / temperature
        probs = torch.softmax(scaled_logits, dim=-1)

        prob_1 = probs[:, 1].detach().cpu().numpy()
        preds_np = scaled_logits.argmax(dim=-1).detach().cpu().numpy()
        labels_np = labels.detach().cpu().numpy()
        valid_np = valid_mask.detach().cpu().numpy()

        for j in range(len(labels_np)):
            if valid_np[j]:
                all_probs.append(float(prob_1[j]))
                all_preds.append(int(preds_np[j]))
                all_labels.append(int(labels_np[j]))
                if batch_indices:
                    all_indices.append(batch_indices[j])

    if not all_labels:
        logger.warning(f"[{task_name}] 无有效样本")
        return {
            "loss": 0.0, "acc": 0.0, "precision": 0.0, "recall": 0.0, "f1": 0.0,
            "mcc": 0.0, "auc": 0.0, "pr_auc": 0.0, "bacc": 0.0, "vds": 100.0,
            "threshold": 0.5,
            "tp": 0, "fp": 0, "tn": 0, "fn": 0, "total": 0
        }

    avg_loss = eval_loss_sum / max(eval_steps, 1)

    # 决定用哪个指标搜 threshold
    metric_for_thresh = (search_metric or getattr(args, "threshold_metric", "mcc")).lower()

    # ----- threshold 选择 -----
    if is_test and forced_threshold is not None:
        best_threshold = float(forced_threshold)
        logger.info(f"[{task_name}][TEST] forced_threshold={best_threshold:.4f}")
        final_preds = [1 if p >= best_threshold else 0 for p in all_probs]

    else:
        t_min = float(getattr(args, "threshold_search_min", 0.05))
        t_max = float(getattr(args, "threshold_search_max", 0.95))
        t_step = float(getattr(args, "threshold_search_step", 0.01))

        best_threshold, best_score = search_best_threshold(
            all_labels, all_probs,
            metric=metric_for_thresh,
            t_min=t_min, t_max=t_max, t_step=t_step
        )
        final_preds = [1 if p >= best_threshold else 0 for p in all_probs]

        task_name_lower = (task_name or "").lower()
        if ("valid" in task_name_lower) and ("epoch" in task_name_lower):
            args.best_threshold = float(best_threshold)

        logger.info(
            f"[{task_name}][VALID] threshold by {metric_for_thresh.upper()} = "
            f"{best_threshold:.4f}, best_score={best_score:.4f}"
        )

    # ----- 计算所有指标 -----
    acc = accuracy_score(all_labels, final_preds)
    prec = precision_score(all_labels, final_preds, zero_division=0)
    rec = recall_score(all_labels, final_preds, zero_division=0)
    f1 = f1_score(all_labels, final_preds, zero_division=0)
    mcc = matthews_corrcoef(all_labels, final_preds)
    bacc = compute_bacc(all_labels, final_preds)

    try:
        auc = roc_auc_score(all_labels, all_probs)
    except ValueError:
        auc = 0.0
    try:
        pr_auc = average_precision_score(all_labels, all_probs)
    except ValueError:
        pr_auc = 0.0

    vds = compute_vds(all_labels, all_probs, target_fpr=0.0005)

    tn, fp, fn, tp = confusion_matrix(all_labels, final_preds, labels=[0, 1]).ravel()

    results = {
        "loss": avg_loss, "acc": acc,
        "precision": prec, "recall": rec, "f1": f1,
        "mcc": mcc, "auc": auc, "pr_auc": pr_auc,
        "bacc": bacc, "vds": vds,
        "threshold": float(best_threshold),
        "search_metric": metric_for_thresh,
        "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn),
        "total": len(all_labels),
    }

    stage = "TEST" if is_test else "VALID"
    logger.info(
        f"[{task_name}][{stage}] loss={avg_loss:.4f} acc={acc:.4f} "
        f"P={prec:.4f} R={rec:.4f} F1={f1:.4f} MCC={mcc:.4f} "
        f"AUC={auc:.4f} PR-AUC={pr_auc:.4f} BAcc={bacc:.4f} VD-S={vds:.2f} "
        f"thresh={best_threshold:.4f}(by {metric_for_thresh})"
    )
    logger.info(f"[{task_name}][{stage}] TP={tp} FP={fp} TN={tn} FN={fn}")

    if save_preds_path:
        with open(save_preds_path, "w", encoding="utf-8") as f:
            f.write("true\tpred\tprob1\n")
            for t, p, prob in zip(all_labels, final_preds, all_probs):
                f.write(f"{t}\t{p}\t{prob:.6f}\n")

    if error_analysis and all_indices:
        save_error_analysis(
            args, eval_dataloader, all_indices,
            all_labels, final_preds, all_probs, task_name
        )

    return results







def build_subset_loader(dataset, indices, batch_size, collate_fn, num_workers=0):
    sub_ds = Subset(dataset, indices)
    sub_loader = DataLoader(
        sub_ds,
        sampler=SequentialSampler(sub_ds),
        batch_size=batch_size,
        collate_fn=collate_fn,
        num_workers=num_workers
    )
    return sub_loader


# =========================
# Train / Save
# =========================
def save_checkpoint(args, model, optimizer, scheduler, scaler, epoch, global_step, best_metric_val, epochs_no_improve, is_best=False):
    model_to_save = model.module if hasattr(model, 'module') else model

    if is_best:
        best_dir = os.path.join(args.output_dir, 'checkpoint-best')
        safe_makedirs(best_dir)

        torch.save(model_to_save.state_dict(), os.path.join(best_dir, 'model.bin'))
        model_to_save.config.save_pretrained(best_dir)

        if hasattr(args, 'tokenizer'):
            args.tokenizer.save_pretrained(best_dir)

        # 注意：args 里可能有不可序列化对象，尽量只保存轻量字段
        train_args_path = os.path.join(best_dir, 'training_args_light.json')
        light_args = {k: (v if isinstance(v, (int, float, str, bool, type(None))) else str(type(v)))
                      for k, v in vars(args).items()}
        dump_json(light_args, train_args_path)

        best_params = {
            'best_threshold': float(getattr(args, 'best_threshold', 0.5)),
            'best_metric_val': float(best_metric_val),
            'epoch': int(epoch),
            'global_step': int(global_step),
            'metric_name': args.metric_for_best_model
        }
        dump_json(best_params, os.path.join(best_dir, 'best_params.json'))

        # 可选：保存原型
        if hasattr(model_to_save, 'normal_prototypes'):
            torch.save(model_to_save.normal_prototypes.data, os.path.join(best_dir, 'prototypes.pt'))

        logger.info(f"[CKPT] 最佳模型保存到: {best_dir}")

    latest_dir = os.path.join(args.output_dir, 'checkpoint-latest')
    safe_makedirs(latest_dir)

    ckpt = {
        'epoch': epoch,
        'global_step': global_step,
        'model_state_dict': model_to_save.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict(),
        'best_metric_val': best_metric_val,
        'epochs_no_improve': epochs_no_improve,
    }
    if args.fp16:
        ckpt['scaler_state_dict'] = scaler.state_dict()

    torch.save(ckpt, os.path.join(latest_dir, 'checkpoint.bin'))

class FocalLoss(nn.Module):
    """
    Focal Loss: 降低 easy sample 的权重，聚焦 hard sample。
    gamma=0 退化为标准 CrossEntropy。
    """
    def __init__(self, weight=None, gamma=2.0, reduction='mean'):
        super().__init__()
        self.gamma = gamma
        self.weight = weight
        self.reduction = reduction

    def forward(self, logits, labels):
        ce = F.cross_entropy(logits, labels, weight=self.weight, reduction='none')
        pt = torch.exp(-ce)
        focal = ((1.0 - pt) ** self.gamma) * ce
        if self.reduction == 'mean':
            return focal.mean()
        elif self.reduction == 'sum':
            return focal.sum()
        return focal

def train(args, model, tokenizer, train_dataloader, eval_dataloader=None):
    import os
    import json

    # -------- 实际优化步数（向上取整）--------
    steps_per_epoch = max(
        1,
        (len(train_dataloader) + args.gradient_accumulation_steps - 1)
        // args.gradient_accumulation_steps
    )
    t_total = steps_per_epoch * int(args.num_train_epochs)

    no_decay = ["bias", "LayerNorm.weight"]
    optimizer_grouped_parameters = [
        {
            "params": [
                p for n, p in model.named_parameters()
                if not any(nd in n for nd in no_decay) and p.requires_grad
            ],
            "weight_decay": args.weight_decay,
        },
        {
            "params": [
                p for n, p in model.named_parameters()
                if any(nd in n for nd in no_decay) and p.requires_grad
            ],
            "weight_decay": 0.0,
        },
    ]

    optimizer = AdamW(
        optimizer_grouped_parameters,
        lr=args.learning_rate,
        eps=args.adam_epsilon
    )
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=int(t_total * args.warmup_ratio),
        num_training_steps=t_total,
    )
    scaler = amp.GradScaler(enabled=args.fp16)

    ce_criterion = args.criterion
    aux_loss_weight = float(getattr(args, "aux_loss_weight", 0.0))
    contrastive_weight = float(getattr(args, "contrastive_weight", 0.0))

    logger.info("***** 开始训练 *****")
    logger.info(f"  样本数 = {len(train_dataloader.dataset)}")
    logger.info(f"  Epoch = {int(args.num_train_epochs)}")
    logger.info(f"  每个epoch优化步数 = {steps_per_epoch}")
    logger.info(f"  总优化步数 = {t_total}")
    logger.info(f"  metric_for_best_model = {args.metric_for_best_model}")
    logger.info(f"  aux_loss_weight = {aux_loss_weight}")
    logger.info(f"  contrastive_weight = {contrastive_weight}")

    # ===== 断点参数初始化 =====
    start_epoch = 0
    global_step = 0
    best_metric_val = -1e9
    best_epoch = -1
    best_threshold = 0.5
    epochs_no_improve = 0

    # ===== Resume =====
    resume_path = getattr(args, "resume_from_checkpoint", "")
    if resume_path:
        ckpt_file = os.path.join(resume_path, "checkpoint.bin") if os.path.isdir(resume_path) else resume_path
        if os.path.exists(ckpt_file):
            logger.info(f"[Resume] Loading checkpoint from {ckpt_file}")
            ckpt = torch.load(ckpt_file, map_location=args.device)

            model_to_load = model.module if hasattr(model, "module") else model
            model_to_load.load_state_dict(ckpt["model_state_dict"], strict=True)

            optimizer.load_state_dict(ckpt["optimizer_state_dict"])
            scheduler.load_state_dict(ckpt["scheduler_state_dict"])
            if args.fp16 and "scaler_state_dict" in ckpt:
                scaler.load_state_dict(ckpt["scaler_state_dict"])

            start_epoch = int(ckpt.get("epoch", -1)) + 1
            global_step = int(ckpt.get("global_step", 0))
            best_metric_val = float(ckpt.get("best_metric_val", -1e9))
            epochs_no_improve = int(ckpt.get("epochs_no_improve", 0))

            bp = os.path.join(args.output_dir, "checkpoint-best", "best_params.json")
            if os.path.exists(bp):
                try:
                    with open(bp, "r", encoding="utf-8") as f:
                        best_threshold = float(json.load(f).get("best_threshold", 0.5))
                        args.best_threshold = best_threshold
                except Exception:
                    pass

            logger.info(
                f"[Resume] start_epoch={start_epoch}, global_step={global_step}, "
                f"best_metric_val={best_metric_val:.6f}, no_improve={epochs_no_improve}"
            )
        else:
            logger.warning(f"[Resume] checkpoint not found: {ckpt_file}")

    model.zero_grad()

    def _pick_metric(eval_results, metric_name):
        m = (metric_name or "mcc").lower()
        if m == "mcc":
            return float(eval_results.get("mcc", -1e9))
        if m == "f1":
            return float(eval_results.get("f1", -1e9))
        if m == "recall":
            return float(eval_results.get("recall", -1e9))
        if m == "precision":
            return float(eval_results.get("precision", -1e9))
        if m == "acc":
            return float(eval_results.get("acc", -1e9))
        return float(eval_results.get("mcc", -1e9))

    for epoch in trange(start_epoch, int(args.num_train_epochs), desc="Epoch"):
        model.train()
        epoch_loss_sum, epoch_ce_sum, epoch_aux_sum = 0.0, 0.0, 0.0
        epoch_steps = 0

        epoch_iter = tqdm(train_dataloader, desc="Iter", leave=False)
        for step, batch in enumerate(epoch_iter):
            inputs = {k: v.to(args.device) for k, v in batch.items() if isinstance(v, torch.Tensor)}

            with amp.autocast(enabled=args.fp16):
                model_unwrapped = model.module if hasattr(model, "module") else model

                use_aux = (aux_loss_weight > 0.0)
                inputs["return_aux"] = use_aux

                out = model(**inputs)

                if use_aux and isinstance(out, tuple) and len(out) >= 2 and torch.is_tensor(out[1]):
                    logits, aux_loss = out[0], out[1]
                else:
                    logits = out if not isinstance(out, tuple) else out[0]
                    aux_loss = torch.tensor(0.0, device=args.device)

                labels = inputs["vuln_labels"]
                valid_mask = (labels >= 0)
                if valid_mask.sum() == 0:
                    continue

                ce_loss = ce_criterion(logits[valid_mask], labels[valid_mask])

                proto_reg = torch.tensor(0.0, device=args.device)
                if contrastive_weight > 0:
                    if hasattr(model_unwrapped, "normal_prototypes") and model_unwrapped.normal_prototypes is not None:
                        proto = model_unwrapped.normal_prototypes
                        if proto.size(0) > 1:
                            proto_norm = F.normalize(proto, dim=-1)
                            sim = torch.mm(proto_norm, proto_norm.t())
                            mask = ~torch.eye(sim.size(0), dtype=torch.bool, device=sim.device)
                            proto_reg = sim[mask].mean()

                loss = ce_loss + aux_loss_weight * aux_loss + contrastive_weight * proto_reg

            loss_for_backward = loss / args.gradient_accumulation_steps if args.gradient_accumulation_steps > 1 else loss
            scaler.scale(loss_for_backward).backward()

            epoch_loss_sum += float(loss.item())
            epoch_ce_sum += float(ce_loss.item())
            epoch_aux_sum += float(aux_loss.item())
            epoch_steps += 1

            epoch_iter.set_postfix({
                "loss": f"{loss.item():.4f}",
                "ce": f"{ce_loss.item():.4f}",
                "aux": f"{aux_loss.item():.4f}",
            })

            if (step + 1) % args.gradient_accumulation_steps == 0:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)

                old_scale = scaler.get_scale()
                scaler.step(optimizer)
                scaler.update()
                new_scale = scaler.get_scale()

                if new_scale >= old_scale:
                    scheduler.step()

                model.zero_grad()
                global_step += 1

        # 处理最后不足 accumulation 的残留梯度
        if (len(train_dataloader) % args.gradient_accumulation_steps) != 0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)

            old_scale = scaler.get_scale()
            scaler.step(optimizer)
            scaler.update()
            new_scale = scaler.get_scale()
            if new_scale >= old_scale:
                scheduler.step()

            model.zero_grad()
            global_step += 1

        avg_loss = epoch_loss_sum / max(epoch_steps, 1)
        avg_ce = epoch_ce_sum / max(epoch_steps, 1)
        avg_aux = epoch_aux_sum / max(epoch_steps, 1)

        logger.info(
            f"Epoch {epoch}: avg_loss={avg_loss:.4f}, avg_ce={avg_ce:.4f}, "
            f"avg_aux={avg_aux:.4f}, lr={scheduler.get_last_lr()[0]:.2e}"
        )

        if eval_dataloader is not None:
            eval_results = evaluate(
                args, model, eval_dataloader,
                is_test=False,
                task_name=f"valid_epoch_{epoch}"
            )
            current_metric = _pick_metric(eval_results, args.metric_for_best_model)
            current_threshold = float(eval_results.get("threshold", 0.5))

            logger.info(f"Epoch {epoch} eval: {eval_results}")
            logger.info(f"Epoch {epoch} picked_metric({args.metric_for_best_model})={current_metric:.6f}")

            if current_metric > best_metric_val:
                best_metric_val = current_metric
                best_epoch = epoch
                best_threshold = current_threshold
                args.best_threshold = float(best_threshold)
                epochs_no_improve = 0

                save_checkpoint(
                    args=args, model=model, optimizer=optimizer,
                    scheduler=scheduler, scaler=scaler, epoch=epoch,
                    global_step=global_step, best_metric_val=best_metric_val,
                    epochs_no_improve=epochs_no_improve, is_best=True
                )
                logger.info(
                    f"  新最优模型已保存到 checkpoint-best, "
                    f"metric={best_metric_val:.6f}, epoch={best_epoch}, thresh={best_threshold:.4f}"
                )
            else:
                epochs_no_improve += 1
                logger.info(f"  本轮无提升: no_improve={epochs_no_improve}/{args.early_stopping_patience}")

            save_checkpoint(
                args=args, model=model, optimizer=optimizer,
                scheduler=scheduler, scaler=scaler, epoch=epoch,
                global_step=global_step, best_metric_val=best_metric_val,
                epochs_no_improve=epochs_no_improve, is_best=False
            )

            if epochs_no_improve >= args.early_stopping_patience:
                logger.info(f"早停触发：连续 {epochs_no_improve} 轮无提升，停止训练。")
                break
        else:
            save_checkpoint(
                args=args, model=model, optimizer=optimizer,
                scheduler=scheduler, scaler=scaler, epoch=epoch,
                global_step=global_step, best_metric_val=best_metric_val,
                epochs_no_improve=epochs_no_improve, is_best=False
            )

    # ★ 修复：去掉重复的 logger.info，只保留一条
    logger.info(
        f"训练结束: best_epoch={best_epoch}, "
        f"best_{args.metric_for_best_model}={best_metric_val:.6f}, "
        f"best_threshold={best_threshold:.4f}"
    )

    # ★ 新增：训练结束后在验证集上做温度校准
    temperature = 1.0
    if eval_dataloader is not None:
        logger.info("[Calibrate] 训练结束，开始温度校准...")
        try:
            temperature = calibrate_temperature(model, eval_dataloader, args)
            args.temperature = temperature

            logger.info("[Calibrate] 用校准温度重新搜索验证集最优阈值...")
            calib_results = evaluate(
                args, model, eval_dataloader,
                is_test=False,
                task_name="valid_calibrated",
                temperature=temperature
            )
            calib_threshold = float(calib_results.get("threshold", best_threshold))
            calib_mcc = float(calib_results.get("mcc", 0.0))

            logger.info(
                f"[Calibrate] 校准后: temp={temperature:.4f}, "
                f"threshold={calib_threshold:.4f}, MCC={calib_mcc:.4f} "
                f"(校准前: threshold={best_threshold:.4f}, MCC={best_metric_val:.4f})"
            )

            if calib_mcc >= best_metric_val:
                best_threshold = calib_threshold
                args.best_threshold = best_threshold
                logger.info(f"[Calibrate] 采用校准后阈值: {best_threshold:.4f}")
            else:
                logger.info(f"[Calibrate] 校准后无提升，保留原阈值: {best_threshold:.4f}")

            best_dir = os.path.join(args.output_dir, 'checkpoint-best')
            safe_makedirs(best_dir)
            dump_json({
                "temperature": temperature,
                "calibrated_threshold": calib_threshold,
                "calibrated_mcc": calib_mcc,
                "original_threshold": float(getattr(args, 'best_threshold', 0.5)),
            }, os.path.join(best_dir, "calibration.json"))

        except Exception as e:
            logger.warning(f"[Calibrate] 温度校准失败: {e}")
            temperature = 1.0
            args.temperature = 1.0
    else:
        args.temperature = 1.0

    # ★ 修复：只保留一个 return，包含 temperature
    return {
        "global_step": global_step,
        "best_epoch": best_epoch,
        "best_metric_val": best_metric_val,
        "best_threshold": best_threshold,
        "temperature": temperature,
    }

# =========================
# Main
# =========================
def save_results_bundle(output_dir, all_results):
    safe_makedirs(output_dir)
    json_path = os.path.join(output_dir, "test_results_all.json")
    csv_path = os.path.join(output_dir, "test_results_all.csv")
    summary_path = os.path.join(output_dir, "test_summary.json")

    dump_json(all_results, json_path)

    keys = ["task", "acc", "recall", "precision", "f1", "mcc", "pr_auc", "auc", "bacc", "vds", "threshold"]

    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in all_results:
            w.writerow({k: r.get(k, "") for k in keys})

    summary = {
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "num_tasks": len(all_results),
        "results": all_results
    }
    dump_json(summary, summary_path)

    logger.info(f"结果已保存: {json_path}")
    logger.info(f"结果已保存: {csv_path}")
    logger.info(f"结果已保存: {summary_path}")


def main():
    # if sys.platform.startswith('linux') and multiprocessing.get_start_method(allow_none=True) != 'spawn':
    #     try:
    #         multiprocessing.set_start_method('spawn', force=True)
    #     except RuntimeError:
    #         pass

    parser = argparse.ArgumentParser()
    parser.add_argument("--threshold_metric", default="mcc", type=str,
                        choices=["mcc", "f1", "precision", "recall"])
    parser.add_argument("--use_per_type_threshold", action="store_true",
                        help="测试子任务时是否使用按漏洞类型在valid上校准的threshold；默认关闭，使用global threshold")


    parser.add_argument("--use_class_weights", action="store_true")
    parser.add_argument("--class_weight_cap", default=8.0, type=float)

    parser.add_argument("--resume_from_checkpoint", type=str, default="",
                        help="Path to checkpoint dir or checkpoint.bin")
    parser.add_argument("--max_global_lines", default=140, type=int)

    parser.add_argument("--use_shard_cache", action="store_true")
    parser.add_argument("--shard_size", default=10000, type=int)

    # ---- 阈值搜索 ----
    parser.add_argument("--threshold_search_min", type=float, default=0.35)
    parser.add_argument("--threshold_search_max", type=float, default=0.90)
    parser.add_argument("--threshold_search_step", type=float, default=0.01)
    parser.add_argument("--min_precision", default=0.58, type=float)
    parser.add_argument("--min_recall", default=0.55, type=float)
    parser.add_argument("--alpha_f1", default=0.50, type=float)
    parser.add_argument("--beta_precision", default=0.25, type=float)
    parser.add_argument("--gamma_recall", default=0.25, type=float)

    # ---- 路径 ----
    parser.add_argument("--max_paths_main", default=12, type=int)
    parser.add_argument("--max_paths_patch", default=3, type=int)
    parser.add_argument("--use_patch_diff_only", action="store_true")
    parser.add_argument("--enable_gradient_checkpointing", action="store_true")




    # ---- 文件路径 ----
    parser.add_argument("--output_dir", required=True, type=str)
    parser.add_argument("--data_dir", required=True, type=str)
    parser.add_argument("--pkl_dir", required=True, type=str)
    parser.add_argument("--model_name_or_path", required=True, type=str)

    parser.add_argument("--train_file_name", default="train_synced.jsonl")
    parser.add_argument("--valid_file_name", default="valid_synced.jsonl")
    parser.add_argument("--test_file_name", default="test_synced.jsonl")
    parser.add_argument("--pkl_file_name_train", default="dataflow_primevul_train.pkl")
    parser.add_argument("--pkl_file_name_valid", default="dataflow_primevul_valid.pkl")
    parser.add_argument("--pkl_file_name_test", default="dataflow_primevul_test.pkl")

    # ---- 模式 ----
    parser.add_argument("--do_train", action='store_true')
    parser.add_argument("--do_eval", action='store_true')
    parser.add_argument("--do_test", action='store_true')
    parser.add_argument("--use_cache", action='store_true')
    parser.add_argument("--fp16", action='store_true')
    parser.add_argument("--balance_test_set", action='store_true')

    # ---- 模型 ----
    parser.add_argument("--model_type", default="unixcoder")
    parser.add_argument("--block_size", default=512, type=int)
    parser.add_argument("--max_paths", default=8, type=int)

    # ---- 训练超参 ----
    parser.add_argument("--train_batch_size", default=1, type=int)
    parser.add_argument("--eval_batch_size", default=1, type=int)
    parser.add_argument("--gradient_accumulation_steps", default=12, type=int)
    parser.add_argument("--learning_rate", default=1e-5, type=float)
    parser.add_argument("--weight_decay", default=0.01, type=float)
    parser.add_argument("--adam_epsilon", default=1e-8, type=float)
    parser.add_argument("--max_grad_norm", default=1.0, type=float)
    parser.add_argument("--num_train_epochs", default=12, type=int)
    parser.add_argument("--warmup_ratio", default=0.06, type=float)
    parser.add_argument("--path_dropout_rate", default=0.15, type=float)
    parser.add_argument("--early_stopping_patience", default=7, type=int)
    parser.add_argument("--patience", default=5, type=int)
    parser.add_argument("--metric_for_best_model", default="mcc")


    parser.add_argument("--seed", default=42, type=int)

    # ---- 数据处理 ----
    parser.add_argument("--cache_dir_name", default="cached_features_v8_4_regenpath_fastmcc")

    parser.add_argument("--num_preprocessing_workers", default=8, type=int)
    parser.add_argument("--num_dataloader_workers", default=4, type=int)
    parser.add_argument("--preprocessing_chunksize", default=64, type=int)

    # ---- PathCL 新增 ----
    parser.add_argument("--n_prototypes", default=16, type=int)
    parser.add_argument("--contrastive_weight", default=0.2, type=float)
    parser.add_argument("--aux_loss_weight", default=0.03, type=float)

    parser.add_argument("--proto_ema", default=0.05, type=float)
    parser.add_argument("--focal_gamma", default=2.0, type=float)
    parser.add_argument("--n_ants", default=30, type=int)
    parser.add_argument("--n_aco_iterations", default=20, type=int)

    args = parser.parse_args()


    if not hasattr(args, "max_paths_main"):
        args.max_paths_main = args.max_paths
    if not hasattr(args, "max_paths_patch"):
        args.max_paths_patch = min(3, args.max_paths)

    safe_makedirs(args.output_dir)
    log_file_path = os.path.join(args.output_dir, "run_log_v8_4_regenpath_fastmcc.log")

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(log_file_path, mode='w', encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

    logger.info("=" * 25 + " PathCL v6.1 Start " + "=" * 25)
    logger.info(f"args: {args}")

    args.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    args.n_gpu = torch.cuda.device_count()
    set_seed(args)

    try:
        config = MODEL_CLASSES[args.model_type][0].from_pretrained(args.model_name_or_path)
        tokenizer = MODEL_CLASSES[args.model_type][2].from_pretrained(args.model_name_or_path)

        new_special_tokens = ['[DANGER_OP]', '[POINTER_OP]', '[DEFENSE_OP]', '[DATA_FLOW]']
        tokenizer.add_special_tokens({'additional_special_tokens': new_special_tokens})

        encoder = MODEL_CLASSES[args.model_type][1].from_pretrained(args.model_name_or_path, config=config)
        encoder.resize_token_embeddings(len(tokenizer))
        logger.info(f"max_position_embeddings={config.max_position_embeddings}, block_size={args.block_size}")
        if args.block_size > int(getattr(config, "max_position_embeddings", 512)):
            logger.warning(
                f"block_size({args.block_size}) > max_position_embeddings({config.max_position_embeddings}), "
                f"将导致超长部分不可用/越界风险，建议设为 <= {config.max_position_embeddings - 2}"
            )
        if args.enable_gradient_checkpointing and hasattr(encoder, "gradient_checkpointing_enable"):
            encoder.gradient_checkpointing_enable()
            logger.info("Gradient checkpointing enabled.")

        model = Model(encoder, config, tokenizer, args).to(args.device)

        if args.n_gpu > 1:
            model = torch.nn.DataParallel(model)

        args.tokenizer = tokenizer
        cache_dir_base = os.path.join(args.output_dir, args.cache_dir_name)

        # ========= Train =========
        if args.do_train:
            logger.info("\n" + "=" * 60 + "\n***** 开始训练 *****\n" + "=" * 60)

            train_dataset = TextDataset(
                tokenizer, args,
                os.path.join(args.data_dir, args.train_file_name),
                os.path.join(args.pkl_dir, args.pkl_file_name_train),
                args.use_cache,
                os.path.join(cache_dir_base, "train"),
                "Train"
            )
            if not train_dataset.examples:
                logger.error("训练集为空，退出")
                return

            counts = Counter([ex.label for ex in train_dataset.examples])
            n0 = counts.get(0, 0)
            n1 = counts.get(1, 0)
            total = n0 + n1

            if args.use_class_weights and n0 > 0 and n1 > 0:
                w0 = total / (2.0 * n0)
                w1 = total / (2.0 * n1)

                # cap 正类权重，避免过激
                w1 = min(w1, float(args.class_weight_cap))

                # 可选：避免负类权重过小
                w0 = max(w0, 0.5)

                class_weights = torch.tensor([w0, w1], dtype=torch.float).to(args.device)
                logger.info(
                    f"Train label dist: {counts}, "
                    f"class_weights(capped)={class_weights.tolist()}, "
                    f"focal_gamma={args.focal_gamma}"
                )
            else:
                class_weights = None
                logger.info(
                    f"Train label dist: {counts}, "
                    f"class_weights=None, focal_gamma={args.focal_gamma}"
                )

            args.criterion = FocalLoss(weight=class_weights, gamma=args.focal_gamma)

            collate_train = partial(
                collate_fn,
                pad_token_id=tokenizer.pad_token_id,
                max_paths_main=args.max_paths_main,
                max_paths_patch=args.max_paths_patch,
                path_dropout_rate=args.path_dropout_rate
            )

            train_loader = DataLoader(
                train_dataset, sampler=RandomSampler(train_dataset),
                batch_size=args.train_batch_size, collate_fn=collate_train,
                num_workers=args.num_dataloader_workers, pin_memory=True
            )

            eval_loader = None
            if args.do_eval:
                valid_dataset = TextDataset(
                    tokenizer, args,
                    os.path.join(args.data_dir, args.valid_file_name),
                    os.path.join(args.pkl_dir, args.pkl_file_name_valid),
                    args.use_cache,
                    os.path.join(cache_dir_base, "valid"),
                    "Valid"
                )
                if valid_dataset.examples:
                    collate_eval = partial(
                        collate_fn,
                        pad_token_id=tokenizer.pad_token_id,
                        max_paths_main=args.max_paths_main,
                        max_paths_patch=args.max_paths_patch,
                        path_dropout_rate=0.0
                    )
                    eval_loader = DataLoader(
                        valid_dataset, sampler=SequentialSampler(valid_dataset),
                        batch_size=args.eval_batch_size, collate_fn=collate_eval,
                        num_workers=args.num_dataloader_workers, pin_memory=True
                    )
                else:
                    logger.warning("验证集为空，跳过验证")

            train(args, model, tokenizer, train_loader, eval_loader)

        # ========= Test =========
        # ========= Test =========
        # ========= Test =========
        if args.do_test:
            logger.info("\n" + "=" * 60 + "\n***** 开始测试 *****\n" + "=" * 60)

            best_dir = os.path.join(args.output_dir, 'checkpoint-best')
            best_model_path = os.path.join(best_dir, 'model.bin')
            if not os.path.exists(best_model_path):
                logger.error(f"找不到最佳模型: {best_model_path}")
                return

            model_to_load = model.module if hasattr(model, 'module') else model
            model_to_load.load_state_dict(torch.load(best_model_path, map_location=args.device))
            logger.info(f"加载模型: {best_model_path}")

            proto_path = os.path.join(best_dir, 'prototypes.pt')
            if os.path.exists(proto_path) and hasattr(model_to_load, 'normal_prototypes'):
                model_to_load.normal_prototypes.data = torch.load(proto_path, map_location=args.device)
                logger.info(f"加载原型: {proto_path}")

            if not hasattr(args, 'criterion') or args.criterion is None:
                args.criterion = FocalLoss(gamma=args.focal_gamma)

            collate_test = partial(
                collate_fn,
                pad_token_id=tokenizer.pad_token_id,
                max_paths_main=args.max_paths_main,
                max_paths_patch=args.max_paths_patch,
                path_dropout_rate=0.0
            )

            # ---- 加载温度（带安全检查）----
            calibration_path = os.path.join(best_dir, "calibration.json")
            temperature = 1.0
            if os.path.exists(calibration_path):
                try:
                    with open(calibration_path, "r", encoding="utf-8") as f:
                        calib_info = json.load(f)
                        raw_temp = float(calib_info.get("temperature", 1.0))
                    # 安全检查
                    if 0.1 <= raw_temp <= 10.0:
                        temperature = raw_temp
                        logger.info(f"[TEST] 加载校准温度: {temperature:.4f}")
                    else:
                        logger.warning(
                            f"[TEST] 校准温度异常({raw_temp:.4f})，使用默认 1.0"
                        )
                except Exception as e:
                    logger.warning(f"[TEST] 温度校准读取失败: {e}")

            # =========================================================
            # 1) Valid 上搜 threshold（标准做法，无泄漏）
            # =========================================================
            valid_dataset = TextDataset(
                tokenizer, args,
                os.path.join(args.data_dir, args.valid_file_name),
                os.path.join(args.pkl_dir, args.pkl_file_name_valid),
                args.use_cache,
                os.path.join(cache_dir_base, "valid"),
                "ValidForThreshold"
            )
            if not valid_dataset.examples:
                logger.error("验证集为空")
                return

            valid_loader = DataLoader(
                valid_dataset,
                sampler=SequentialSampler(valid_dataset),
                batch_size=args.eval_batch_size,
                collate_fn=collate_test,
                num_workers=args.num_dataloader_workers
            )

            # 用 F1 搜 valid threshold
            valid_f1_res = evaluate(
                args, model, valid_loader,
                is_test=False,
                task_name="valid_thresh_by_f1",
                temperature=temperature,
                search_metric="f1"
            )
            valid_thresh_f1 = float(valid_f1_res.get("threshold", 0.5))

            # 用 MCC 搜 valid threshold
            valid_mcc_res = evaluate(
                args, model, valid_loader,
                is_test=False,
                task_name="valid_thresh_by_mcc",
                temperature=temperature,
                search_metric="mcc"
            )
            valid_thresh_mcc = float(valid_mcc_res.get("threshold", 0.5))

            logger.info(f"[THRESH] valid threshold by F1  = {valid_thresh_f1:.4f}")
            logger.info(f"[THRESH] valid threshold by MCC = {valid_thresh_mcc:.4f}")

            # =========================================================
            # 2) 加载 TEST
            # =========================================================
            test_dataset = TextDataset(
                tokenizer, args,
                os.path.join(args.data_dir, args.test_file_name),
                os.path.join(args.pkl_dir, args.pkl_file_name_test),
                args.use_cache,
                os.path.join(cache_dir_base, "test"),
                "Test"
            )
            if not test_dataset.examples:
                logger.error("测试集为空，退出")
                return

            test_loader = DataLoader(
                test_dataset,
                sampler=SequentialSampler(test_dataset),
                batch_size=args.eval_batch_size,
                collate_fn=collate_test,
                num_workers=args.num_dataloader_workers
            )

            all_results = []

            # =========================================================
            # 3) Standard: 用 valid threshold 评估 test（无泄漏）
            # =========================================================
            std_f1 = evaluate(
                args, model, test_loader,
                is_test=True,
                task_name="Std(valid-F1)",
                error_analysis=True,
                save_preds_path=os.path.join(args.output_dir, "predictions_std_f1.txt"),
                forced_threshold=valid_thresh_f1,
                temperature=temperature
            )
            all_results.append({'task': 'Std(valid-F1)', **std_f1})

            std_mcc = evaluate(
                args, model, test_loader,
                is_test=True,
                task_name="Std(valid-MCC)",
                forced_threshold=valid_thresh_mcc,
                temperature=temperature
            )
            all_results.append({'task': 'Std(valid-MCC)', **std_mcc})

            # =========================================================
            # 4) Oracle: 在 test 上搜最优 threshold（仅供参考，不用于下游）
            # =========================================================
            oracle_f1 = evaluate(
                args, model, test_loader,
                is_test=False,
                task_name="Oracle(F1)",
                error_analysis=True,
                save_preds_path=os.path.join(args.output_dir, "predictions_oracle_f1.txt"),
                temperature=temperature,
                search_metric="f1"
            )
            all_results.append({'task': 'Oracle(F1)', **oracle_f1})

            oracle_mcc = evaluate(
                args, model, test_loader,
                is_test=False,
                task_name="Oracle(MCC)",
                temperature=temperature,
                search_metric="mcc"
            )
            all_results.append({'task': 'Oracle(MCC)', **oracle_mcc})

            # =========================================================
            # 5) 打印论文格式结果表
            # =========================================================
            logger.info("\n" + "=" * 130)
            logger.info("Final Test Results (Weissberg ICSE'26 format)")
            logger.info("=" * 130)
            header = "{:<20} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8}".format(
                "Task", "F1↑", "AUPRC↑", "MCC↑", "BAcc↑", "VD-S↓",
                "AUC", "P", "R", "Thresh"
            )
            logger.info(header)
            logger.info("-" * 130)
            for r in all_results:
                row = "{:<20} {:<8.2f} {:<8.2f} {:<8.2f} {:<8.2f} {:<8.2f} {:<8.4f} {:<8.4f} {:<8.4f} {:<8.4f}".format(
                    r.get('task', 'N/A'),
                    r.get('f1', 0.0) * 100,
                    r.get('pr_auc', 0.0) * 100,
                    r.get('mcc', 0.0) * 100,
                    r.get('bacc', 0.0) * 100,
                    r.get('vds', 100.0),
                    r.get('auc', 0.0),
                    r.get('precision', 0.0),
                    r.get('recall', 0.0),
                    r.get('threshold', 0.5),
                )
                logger.info(row)
            logger.info("=" * 130)

            logger.info("\n--- Weissberg ICSE'26 baselines (Table 6) ---")
            logger.info("UniXcoder:  F1=20.69  AUPRC=13.32  MCC=21.36  BAcc=67.23  VD-S=92.84")
            logger.info("SCM:        F1=20.32  AUPRC=13.80  MCC=18.90  BAcc=62.22  VD-S=90.20")
            logger.info("PDBERT:     F1=19.50  AUPRC=13.38  MCC=20.67  BAcc=69.19  VD-S=92.40")

            save_results_bundle(args.output_dir, all_results)

            # =========================================================
            # 6) 按漏洞类型分组测试
            #    ★ 关键修复：用 valid_thresh_mcc（来自验证集），不用 oracle
            # =========================================================
            per_type_threshold = valid_thresh_mcc  # ← 从 valid 来，无泄漏

            indices_by_type = defaultdict(list)
            nonvuln_indices = []
            for i, ex in enumerate(test_dataset.examples):
                if ex.label == 0 or ex.vul_type == 'nonvuln':
                    nonvuln_indices.append(i)
                else:
                    indices_by_type[ex.vul_type].append(i)

            vuln_types = sorted([vt for vt in indices_by_type.keys() if vt != 'unknown'])
            logger.info(f"\n测试漏洞类型: {vuln_types}")

            type_results = []
            for vt in vuln_types:
                task_name = f"d2a-{vt.replace('_', '-')}"
                pos_idx = indices_by_type.get(vt, [])
                if not pos_idx:
                    continue

                neg_idx = nonvuln_indices
                if args.balance_test_set and len(pos_idx) <= len(nonvuln_indices):
                    neg_idx = random.sample(nonvuln_indices, len(pos_idx))

                subset_indices = pos_idx + neg_idx
                sub_ds = Subset(test_dataset, subset_indices)
                sub_loader = DataLoader(
                    sub_ds,
                    sampler=SequentialSampler(sub_ds),
                    batch_size=args.eval_batch_size,
                    collate_fn=collate_test,
                    num_workers=0
                )

                res = evaluate(
                    args, model, sub_loader,
                    is_test=True,
                    task_name=task_name,
                    error_analysis=True,
                    forced_threshold=per_type_threshold,  # ← valid 阈值
                    temperature=temperature
                )
                type_results.append({'task': task_name, **res})

            if type_results:
                logger.info("\n" + "=" * 130)
                logger.info(f"Per-Type Results (valid-MCC threshold={per_type_threshold:.4f})")
                logger.info("=" * 130)
                logger.info(header)
                logger.info("-" * 130)
                for r in type_results:
                    row = "{:<20} {:<8.2f} {:<8.2f} {:<8.2f} {:<8.2f} {:<8.2f} {:<8.4f} {:<8.4f} {:<8.4f} {:<8.4f}".format(
                        r.get('task', 'N/A'),
                        r.get('f1', 0.0) * 100,
                        r.get('pr_auc', 0.0) * 100,
                        r.get('mcc', 0.0) * 100,
                        r.get('bacc', 0.0) * 100,
                        r.get('vds', 100.0),
                        r.get('auc', 0.0),
                        r.get('precision', 0.0),
                        r.get('recall', 0.0),
                        r.get('threshold', 0.5),
                    )
                    logger.info(row)
                logger.info("=" * 130)

            save_results_bundle(args.output_dir, all_results + type_results)

            # ---- 原型统计 ----
            model_unwrapped = model.module if hasattr(model, 'module') else model
            if hasattr(model_unwrapped, 'normal_prototypes'):
                proto = model_unwrapped.normal_prototypes.data
                proto_norm = F.normalize(proto, dim=-1)
                sim = torch.mm(proto_norm, proto_norm.t())
                n = sim.size(0)
                mask = ~torch.eye(n, dtype=torch.bool, device=sim.device)
                avg_sim = sim[mask].mean().item()
                max_sim = sim[mask].max().item()
                min_sim = sim[mask].min().item()
                logger.info(
                    f"Prototype stats: n={n}, avg_sim={avg_sim:.4f}, "
                    f"max_sim={max_sim:.4f}, min_sim={min_sim:.4f}, "
                    f"dispersion={1 - avg_sim:.4f}"
                )





    except Exception as e:
        logger.error(f"Fatal error: {e}")
        logger.error(traceback.format_exc())
        save_fatal_error(args.output_dir, "main", e)
        raise



if __name__ == "__main__":
    if sys.platform.startswith('linux') and multiprocessing.get_start_method(allow_none=True) != 'spawn':
        try:
            multiprocessing.set_start_method('spawn', force=True)
        except RuntimeError:
            pass
    main()
