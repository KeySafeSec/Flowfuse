import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers.modeling_utils import PreTrainedModel
from transformers import RobertaConfig


class Model(PreTrainedModel):
    config_class = RobertaConfig
    base_model_prefix = "encoder"

    def __init__(self, encoder, config, tokenizer, args):
        super().__init__(config)
        self.encoder = encoder
        self.config = config
        self.args = args
        self.hidden_size = config.hidden_size

        # special token ids
        self.tok_danger = tokenizer.convert_tokens_to_ids('[DANGER_OP]')
        self.tok_pointer = tokenizer.convert_tokens_to_ids('[POINTER_OP]')
        self.tok_defense = tokenizer.convert_tokens_to_ids('[DEFENSE_OP]')
        self.tok_dataflow = tokenizer.convert_tokens_to_ids('[DATA_FLOW]')

        # semantic vectors
        self.danger_embedding = nn.Parameter(torch.randn(self.hidden_size) * 0.02)
        self.pointer_embedding = nn.Parameter(torch.randn(self.hidden_size) * 0.02)
        self.defense_embedding = nn.Parameter(torch.randn(self.hidden_size) * 0.02)
        self.data_flow_embedding = nn.Parameter(torch.randn(self.hidden_size) * 0.02)

        # inter-path attention
        n_heads = max(1, min(config.num_attention_heads, 8))
        self.path_attention = nn.MultiheadAttention(
            embed_dim=self.hidden_size,
            num_heads=n_heads,
            dropout=config.attention_probs_dropout_prob,
            batch_first=True
        )
        self.path_attention_norm = nn.LayerNorm(self.hidden_size)

        # === 路径加权池化 ===
        self.path_score = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size // 2),
            nn.GELU(),
            nn.Dropout(config.hidden_dropout_prob),
            nn.Linear(self.hidden_size // 2, 1)
        )

        # prototypes
        n_prototypes = int(getattr(args, "n_prototypes", 16))
        self.normal_prototypes = nn.Parameter(torch.randn(n_prototypes, self.hidden_size) * 0.02)
        self.proto_temperature = float(getattr(args, "proto_temperature", 0.1))
        self.proto_ema = float(getattr(args, "proto_ema", 0.01))

        # diff head
        self.diff_head = nn.Sequential(
            nn.Linear(self.hidden_size * 2, self.hidden_size),
            nn.GELU(),
            nn.Dropout(config.hidden_dropout_prob),
        )

        # local diff gate
        self.gate_linear = nn.Linear(self.hidden_size * 2, self.hidden_size)
        self.gate_sigmoid = nn.Sigmoid()

        # === global gated fusion ===
        self.global_gate = nn.Sequential(
            nn.Linear(self.hidden_size * 2, self.hidden_size),
            nn.GELU(),
            nn.Dropout(config.hidden_dropout_prob),
            nn.Linear(self.hidden_size, 1)
        )
        self.global_delta = nn.Sequential(
            nn.Linear(self.hidden_size * 2, self.hidden_size),
            nn.GELU(),
            nn.Dropout(config.hidden_dropout_prob),
            nn.Linear(self.hidden_size, self.hidden_size)
        )
        self.global_norm = nn.LayerNorm(self.hidden_size)

        self.ffn = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size * 4),
            nn.GELU(),
            nn.Dropout(config.hidden_dropout_prob),
            nn.Linear(self.hidden_size * 4, self.hidden_size),
        )
        self.ffn_norm = nn.LayerNorm(self.hidden_size)
        self.classifier = nn.Linear(self.hidden_size, 2)

        self.init_weights()

    @staticmethod
    def _masked_mean(x, mask, eps=1e-5):  # [修复]: FP16 安全的 eps
        m = mask.unsqueeze(-1).float()
        return (x * m).sum(dim=1) / m.sum(dim=1).clamp(min=eps)

    def _build_feature_masks_from_ids(self, path_ids):
        danger = (path_ids == self.tok_danger).long()
        pointer = (path_ids == self.tok_pointer).long()
        defense = (path_ids == self.tok_defense).long()
        data = (path_ids == self.tok_dataflow).long()
        return danger, pointer, defense, data

    def _encode_paths(self, path_ids, path_attention_mask, path_mask,
                      danger_mask=None, pointer_mask=None, defense_mask=None, data_mask=None):
        B, T, L = path_ids.shape

        if danger_mask is None or pointer_mask is None or defense_mask is None or data_mask is None:
            d, p, f, da = self._build_feature_masks_from_ids(path_ids)
            if danger_mask is None:
                danger_mask = d
            if pointer_mask is None:
                pointer_mask = p
            if defense_mask is None:
                defense_mask = f
            if data_mask is None:
                data_mask = da

        flat_ids = path_ids.view(B * T, L)
        flat_attn = path_attention_mask.view(B * T, L)

        word_emb = self.encoder.embeddings.word_embeddings(flat_ids)

        def inject(mask_tensor, emb_vec):
            return mask_tensor.view(B * T, L).unsqueeze(-1).float() * emb_vec

        word_emb = word_emb + inject(danger_mask, self.danger_embedding)
        word_emb = word_emb + inject(pointer_mask, self.pointer_embedding)
        word_emb = word_emb + inject(defense_mask, self.defense_embedding)
        word_emb = word_emb + inject(data_mask, self.data_flow_embedding)

        out = self.encoder(inputs_embeds=word_emb, attention_mask=flat_attn)
        cls_each_path = out.last_hidden_state[:, 0, :].view(B, T, -1)

        key_padding = (path_mask == 0)
        
        # [修复]: 如果某个样本的所有路径都被 mask 掉，MultiheadAttention 会报错或产生 NaN
        # 我们需要确保至少有一个元素是不被 mask 的。
        # 这里的技巧是：如果全 0，就强制让第一个位置为 1（后续 weighted pooling 会再把它清零，不影响语义）
        all_masked = key_padding.all(dim=1)
        if all_masked.any():
            key_padding = key_padding.clone()
            key_padding[all_masked, 0] = False

        attn_out, _ = self.path_attention(
            cls_each_path, cls_each_path, cls_each_path,
            key_padding_mask=key_padding
        )
        path_rep = self.path_attention_norm(cls_each_path + attn_out)

        # 路径加权池化
        scores = self.path_score(path_rep).squeeze(-1)  # [B, T]
        
        # [修复]: 在 FP16 下，用 -1e4 代替 -1e9 避免下溢出
        scores = scores.masked_fill(path_mask == 0, -1e4)
        
        weights = torch.softmax(scores, dim=-1)
        
        # [核心修复]: 当 path_mask 整行都是 0 时（例如没有 Patch 路径的样本），
        # Softmax 的分母是 exp(-1e4)*T 约等于 0，导致 0/0 = NaN。
        # 这里强制把产生的 NaN 替换回 0.0，并再次应用 mask 确保绝对安全。
        weights = torch.nan_to_num(weights, nan=0.0)
        weights = weights.masked_fill(path_mask == 0, 0.0)
        
        path_summary = torch.sum(path_rep * weights.unsqueeze(-1), dim=1)

        return path_summary

    def _prototype_reference(self, path_summary):
        # [修复]: FP16 安全的 eps，1e-8 会截断为 0 导致除零 NaN
        proto = F.normalize(self.normal_prototypes, dim=-1, eps=1e-5)
        rep = F.normalize(path_summary, dim=-1, eps=1e-5)
        sim = torch.mm(rep, proto.t())
        
        # [修复]: 增加温度系数的 clamp，防止除以极小值
        temp = max(self.proto_temperature, 1e-4)
        w = F.softmax(sim / temp, dim=-1)
        w = torch.nan_to_num(w, nan=0.0) # 兜底防 NaN
        
        ref = torch.mm(w, self.normal_prototypes)
        return ref, sim, w

    def _compute_diff_rep(self, path_summary, patch_summary=None):
        if patch_summary is not None:
            diff = path_summary - patch_summary
        else:
            ref, _, _ = self._prototype_reference(path_summary)
            diff = path_summary - ref
        combined = torch.cat([path_summary, diff], dim=-1)
        return self.diff_head(combined)

    def _update_prototypes_ema(self, safe_summaries):
        if safe_summaries is None or safe_summaries.size(0) == 0:
            return
        with torch.no_grad():
            # [修复]: FP16 安全的 eps
            feats = F.normalize(safe_summaries.detach(), dim=-1, eps=1e-5)
            
            # [修复]: 检查 feats 是否包含 NaN，防止污染原型
            if torch.isnan(feats).any():
                return
                
            sims = F.cosine_similarity(
                feats.unsqueeze(1),
                self.normal_prototypes.unsqueeze(0),
                dim=-1
            )  # [N, K]
            assignments = sims.argmax(dim=-1)
            for k in range(self.normal_prototypes.size(0)):
                mask = (assignments == k)
                if mask.any():
                    centroid = feats[mask].mean(dim=0)
                    old = self.normal_prototypes.data[k]
                    new = (1.0 - self.proto_ema) * old + self.proto_ema * centroid
                    # [修复]: FP16 安全的 eps
                    self.normal_prototypes.data[k] = F.normalize(new, dim=0, eps=1e-5)

    def _global_fuse(self, local_rep, global_rep):
        if global_rep is None:
            return local_rep

        pair = torch.cat([local_rep, global_rep], dim=-1)
        gate = torch.sigmoid(self.global_gate(pair))   # [B,1]
        delta = self.global_delta(pair)                # [B,H]
        fused = local_rep + gate * delta
        fused = self.global_norm(fused)
        return fused

    def forward(self,
                path_ids=None, path_attention_mask=None, path_mask=None,
                danger_mask=None, pointer_mask=None, defense_mask=None, data_mask=None,
                global_ids=None, global_attention_mask=None,
                vuln_labels=None,
                patch_path_ids=None, patch_path_attention_mask=None, patch_path_mask=None,
                patch_danger_mask=None, patch_pointer_mask=None,
                patch_defense_mask=None, patch_data_mask=None,
                return_aux=False,
                **kwargs):

        # 1) 编码主路径
        path_summary = self._encode_paths(
            path_ids, path_attention_mask, path_mask,
            danger_mask, pointer_mask, defense_mask, data_mask
        )
        return_aux = bool(return_aux)

        # 2) 编码 patch 路径（如果有）
        patch_summary = None
        if (patch_path_ids is not None
                and patch_path_mask is not None
                and patch_path_mask.numel() > 0
                and patch_path_mask.sum() > 0):
            patch_summary = self._encode_paths(
                patch_path_ids, patch_path_attention_mask, patch_path_mask,
                patch_danger_mask, patch_pointer_mask,
                patch_defense_mask, patch_data_mask
            )

        # 3) Diff 表征
        diff_rep = self._compute_diff_rep(path_summary, patch_summary)

        # 4) local diff gate
        gate_input = torch.cat([path_summary, diff_rep], dim=-1)
        gate = self.gate_sigmoid(self.gate_linear(gate_input))
        fused = gate * path_summary + (1 - gate) * diff_rep

        # 5) 编码全局代码
        global_cls = None
        if global_ids is not None and global_attention_mask is not None:
            global_out = self.encoder(input_ids=global_ids, attention_mask=global_attention_mask)
            global_cls = global_out.last_hidden_state[:, 0, :]

        # 6) global gated fusion
        fused = self._global_fuse(fused, global_cls)

        # 7) FFN + 分类
        fused = self.ffn_norm(fused + self.ffn(fused))
        logits = self.classifier(fused)

        # 8) Aux loss（修复版：保证非负且防 NaN）
        if return_aux and vuln_labels is not None:
            # [修复]: FP16 安全的 eps
            fused_norm = F.normalize(fused, dim=-1, eps=1e-5)
            proto_norm = F.normalize(self.normal_prototypes, dim=-1, eps=1e-5)

            sim = torch.mm(fused_norm, proto_norm.t())  # [B, K], 范围约 [-1, 1]

            aux_loss = torch.tensor(0.0, device=logits.device)
            valid = 0

            for i in range(fused.size(0)):
                label = vuln_labels[i].item()
                if label < 0:
                    continue

                max_sim = sim[i].max()

                if label == 0:
                    # 正常样本应接近 normal prototypes，loss >= 0
                    aux_loss += (1.0 - max_sim)
                    valid += 1
                elif label == 1:
                    # 漏洞样本不应过于接近 normal prototypes，loss >= 0
                    aux_loss += F.relu(max_sim - 0.3)
                    valid += 1

            if valid > 0:
                aux_loss = aux_loss / valid
            else:
                aux_loss = torch.tensor(0.0, device=logits.device)

            if self.training:
                safe_mask = (vuln_labels == 0)
                if safe_mask.any():
                    self._update_prototypes_ema(fused[safe_mask])

            # [修复]: 兜底防止 aux_loss 变成 NaN 污染主 Loss
            if torch.isnan(aux_loss):
                aux_loss = torch.tensor(0.0, device=logits.device, requires_grad=True)

            return logits, aux_loss

        return logits

