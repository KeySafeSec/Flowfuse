#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

echo "============================================================"
echo "FlowFuse anonymous artifact — layout check"
echo "============================================================"

required=(
  "primevul-pair/three_seed_summary/bprd_three_seed_metrics_FINAL3.json"
  "primevul-pair/BPRD/output/run_v74_bprd_full_relhead_seed42_protocol/TEST_REPORT_FROZEN.json"
  "primevul-pair/BPRD/output/run_v74_bprd_full_relhead_seed42_protocol/selected_config.json"
  "primevul-pair/BPRD/output/run_v74_bprd_full_relhead_seed123_protocol/TEST_REPORT_FROZEN.json"
  "primevul-pair/BPRD/output/run_v74_bprd_full_relhead_seed123_protocol/selected_config.json"
  "primevul-pair/BPRD/output/run_v74_bprd_full_relhead_seed2026_protocol/TEST_REPORT_FROZEN.json"
  "primevul-pair/BPRD/output/run_v74_bprd_full_relhead_seed2026_protocol/selected_config.json"
  "VulFix/output/VulFixed_BPRD_PAIRED_FINAL/test/VULFIXED_FINAL_REPORT.json"
  "VulFix/output/VulFixed_BPRD_PAIRED_FINAL/test/TEST_MAIN_TABLE.json"
  "VulFix/output/VulFixed_BPRD_PAIRED_FINAL/test/TEST_PREDICTIONS_STRICT_PAIRED.jsonl"
  "MegaVul/run_v74_bprd_megavul_frozen_replay/MEGAVUL_FROZEN_REPLAY_REPORT.json"
  "MegaVul/run_v74_bprd_megavul_frozen_replay/MEGAVUL_FROZEN_REPLAY_PREDICTIONS.jsonl"
)

missing=0
for f in "${required[@]}"; do
  if [[ -f "$f" ]]; then
    printf '[OK] %s\n' "$f"
  else
    printf '[MISSING] %s\n' "$f"
    missing=1
  fi
done

if [[ "$missing" -ne 0 ]]; then
  echo
  echo "[FAIL] Required frozen artifact files are missing."
  exit 2
fi

echo
echo "[OK] Core frozen artifact layout is complete."
echo
echo "NOTE: Before anonymous publication, also run the identity/path scan"
echo "      documented in README.md."
