#!/usr/bin/env bash
set -euo pipefail
ROOT="${FLOWFUSE_ROOT:-<ARTIFACT_ROOT>}"
HERE="$(cd "$(dirname "$0")" && pwd)"
MEGA="$ROOT/data/megal/processed_DataFlow_v7_4_pmcl_diverse"
PAIR_VALID="$ROOT/data/primevul/data/primevul_final_datasets/paired/single_function/processed_DataFlow_v7_4_pmcl_diverse"
MODEL_BASE="$ROOT/models/unixcoder-base-nine"
PAIR_OUT="$ROOT/output/run_unixcoder_v7_4_pmcl_diverse"
PAIR_CKPT="$PAIR_OUT/checkpoint-best/model.bin"
EXPECTED_SHA="5f3edde87f8f898b3e2db4af9ad30405ac7e2854e4a4204473aed3e3c6de7738"
OUT="$ROOT/output/run_v74_megavul_zeroshot_FINAL"
STAGE="$OUT/stage"

export PYTHONPATH="$ROOT:$ROOT/code:$HERE:${PYTHONPATH:-}"
export CUDA_VISIBLE_DEVICES="${GPU:-0}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-max_split_size_mb:128}"
export PYTHONUNBUFFERED=1

[[ -f "$PAIR_CKPT" ]] || { echo "[FATAL] missing $PAIR_CKPT"; exit 2; }
got="$(sha256sum "$PAIR_CKPT"|awk '{print $1}')"
[[ "$got" == "$EXPECTED_SHA" ]] || { echo "[FATAL] checkpoint SHA mismatch: $got"; exit 2; }
python "$HERE/verify_megavul_v74.py"  --raw "<HISTORICAL_PROJECT_ROOT>/data/megal/processed_DataFlow_final/test_paired_synced.jsonl" --dir "$MEGA"

mkdir -p "$OUT/checkpoint-best" "$STAGE"
ln -sfn "$PAIR_CKPT" "$OUT/checkpoint-best/model.bin"
# Threshold is selected ONLY on original PrimeVul-Pair VALID.
ln -sfn "$PAIR_VALID/valid_synced.jsonl" "$STAGE/valid_synced.jsonl"
ln -sfn "$PAIR_VALID/dataflow_primevul_valid.pkl" "$STAGE/dataflow_primevul_valid.pkl"
# TEST is MegaVul v7.4.
ln -sfn "$MEGA/test_synced.jsonl" "$STAGE/test_synced.jsonl"
ln -sfn "$MEGA/dataflow_megavul_test.pkl" "$STAGE/dataflow_megavul_test.pkl"

cd "$HERE"
python run.py  --output_dir "$OUT" --data_dir "$STAGE" --pkl_dir "$STAGE"  --valid_file_name valid_synced.jsonl --test_file_name test_synced.jsonl  --pkl_file_name_valid dataflow_primevul_valid.pkl  --pkl_file_name_test dataflow_megavul_test.pkl  --model_name_or_path "$MODEL_BASE"  --do_test --use_cache --fp16  --use_global_branch --enable_gradient_checkpointing  --block_size 860 --max_paths 12 --max_paths_main 8 --max_global_lines 140  --path_diversity_lambda 0.45 --context_score_scale 0.50  --path_rep_dropout 0.10 --path_dropout_rate 0.0 --proj_dim 128  --head_dropout 0.18 --fusion_dropout 0.15 --pairs_per_batch 2  --eval_batch_size "${EVAL_BATCH_SIZE:-8}" --eval_path_chunk_size 24  --metric_for_best_model auc --threshold_metric mcc --threshold_search_step 0.005  --cache_dir_name cached_features_megavul_v7_4_zeroshot  --num_preprocessing_workers 8 --num_dataloader_workers 4  2>&1 | tee "$OUT/TEST_ZEROSHOT.log"

echo
echo "===== ZERO-SHOT RESULT ====="
grep -E 'Loaded best model|\[THRESH\]|\[Std\(valid-MCC\)\]\[TEST\]|P-C=|P-V=|P-B=|P-R=|PairAcc=|Final Test Results'  "$OUT/TEST_ZEROSHOT.log" | tail -80 || true
