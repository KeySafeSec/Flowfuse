# run.py (FlowFuse v7.4 — PMCL + danger/defense interaction + global/path fusion)
#
# Strictness guarantees:
# 1) preprocessing PKLs must NOT contain counterpart/diff-aware path selection;
# 2) model forward is identical in train/valid/test and consumes one function only;
# 3) pair_id is used only by PairBatchSampler and pair losses after independent forwards;
# 4) thresholds are selected on validation only; no test-oracle rows are reported;
# 5) pretrained UniXcoder is never reinitialized by the wrapper model.
#
from __future__ import absolute_import, division, print_function

import os
import sys
import re
import csv
import json
import time
import pickle
import random
import hashlib
import logging
import argparse
import traceback
import multiprocessing
from functools import partial
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda import amp
from torch.utils.data import DataLoader, Dataset, Sampler, SequentialSampler, Subset
from tqdm import tqdm, trange

from sklearn.metrics import (
    recall_score, precision_score, f1_score, accuracy_score, roc_auc_score,
    confusion_matrix, matthews_corrcoef, average_precision_score, roc_curve
)

from transformers import (
    AdamW, get_linear_schedule_with_warmup,
    RobertaConfig, RobertaModel, RobertaTokenizerFast
)

from model import Model

torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True

os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:128"
os.environ["TOKENIZERS_PARALLELISM"] = "false"
if torch.cuda.is_available():
    torch.cuda.empty_cache()

MODEL_CLASSES = {'unixcoder': (RobertaConfig, RobertaModel, RobertaTokenizerFast)}
logger = logging.getLogger(__name__)

CACHE_VERSION = "v7_4_pmcl_diverse_sourceaware"


# =========================
# Keywords / Patterns
# =========================
danger_op_keywords = {
    "strcpy", "strncpy", "sprintf", "snprintf", "vsprintf", "strcat", "strncat", "gets",
    "memcpy", "memmove", "memset", "malloc", "calloc", "realloc", "free",
    "read", "recv", "fread", "system", "popen", "exec", "execve",
    "mysql_query", "sqlite3_exec", "pqexec",
}

pointer_op_keywords = {
    "malloc", "calloc", "realloc", "free", "alloca",
    "memset", "memcpy", "memmove", "memcmp",
    "read", "write", "fread", "fwrite",
    "recv", "send", "recvfrom", "sendto",
    "strcpy", "strncpy", "strcat", "strncat",
    "sprintf", "snprintf", "vsprintf",
    "gets", "fgets",
}

# 注意：不要放 r'if\s*\(\s*(\w+)\s*\)' 这种泛匹配，会让几乎每个 if 都变成 DEFENSE_OP
defense_op_patterns = {
    re.compile(r'if\s*\(\s*([a-zA-Z0-9_*->\.]+)\s*==\s*(NULL|nullptr|0)\s*\)'),
    re.compile(r'if\s*\(\s*(NULL|nullptr|0)\s*==\s*([a-zA-Z0-9_*->\.]+)\s*\)'),
    re.compile(r'if\s*\(\s*!\s*([a-zA-Z0-9_]*?(ptr|buf|ctx|node|data|list|obj|mem|addr|entry)[a-zA-Z0-9_*->\.]*)\s*\)'),
    re.compile(r'if\s*\(\s*([a-zA-Z0-9_*->\.]+)\s*!=\s*(NULL|nullptr|0)\s*\)'),
    re.compile(r'if\s*\(\s*(NULL|nullptr|0)\s*!=\s*([a-zA-Z0-9_*->\.]+)\s*\)'),
    re.compile(r'assert\s*\(\s*([a-zA-Z0-9_*->\.]+)\s*\)'),
}


# =========================
# Utils
# =========================
def set_seed(args):
    random.seed(args.seed)
    np.random.seed(args.seed)
    os.environ['PYTHONHASHSEED'] = str(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.deterministic = True


def safe_makedirs(path):
    os.makedirs(path, exist_ok=True)


def dump_json(obj, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def save_fatal_error(output_dir, stage, e):
    safe_makedirs(output_dir)
    p = os.path.join(output_dir, "fatal_errors.log")
    with open(p, "a", encoding="utf-8") as f:
        f.write("=" * 120 + "\n")
        f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] stage={stage}\n")
        f.write(repr(e) + "\n")
        f.write(traceback.format_exc() + "\n")


def _strip_private(d):
    return {k: v for k, v in d.items() if not k.startswith("_")}


# =========================
# Data Features
# =========================
class InputFeatures(object):
    def __init__(self, idx, input_ids, special_token_pos, global_input_ids, label,
                 vul_type, original_func, pair_id=None, raw_paths=None,
                 path_source=None, teacher_path_scores=None):
        self.idx = idx
        self.input_ids = input_ids
        self.special_token_pos = special_token_pos
        self.global_input_ids = global_input_ids
        self.label = label
        self.vul_type = vul_type
        self.original_func = original_func
        self.pair_id = None if pair_id is None else str(pair_id)
        self.raw_paths = raw_paths if raw_paths else []
        self.path_source = path_source if isinstance(path_source, list) else []
        self.teacher_path_scores = teacher_path_scores if teacher_path_scores else [0.0] * len(self.raw_paths)


def _global_line_score(line: str) -> float:
    if not line or not line.strip():
        return -1.0
    s = 0.0
    if "<DEF:" in line:
        s += 4.0
    if "<USE:" in line:
        s += 4.0
    if re.search(
        r'\b(malloc|calloc|realloc|free|memcpy|memmove|memset|strcpy|strncpy|strcat|strncat|'
        r'sprintf|snprintf|vsprintf|gets|fgets|read|write|recv|send|system|popen|exec\w*)\b', line
    ):
        s += 3.5
    if re.search(r'^\s*(if|else|for|while|switch|case|try|catch|return|goto)\b', line):
        s += 2.0
    if re.search(r'\b(NULL|-ENOMEM|ENOMEM|assert|BUG_ON|panic)\b', line):
        s += 1.8
    if "=" in line:
        s += 0.5
    return s


def build_global_snippet_by_keylines(code_text: str, max_lines: int = 140, add_neighbors: bool = True) -> str:
    if not code_text:
        return ""
    lines = [ln for ln in code_text.splitlines() if ln.strip()]
    if len(lines) <= max_lines:
        return "\n".join(lines)

    scored = [(i, ln, _global_line_score(ln)) for i, ln in enumerate(lines)]
    ranked = sorted(scored, key=lambda x: x[2], reverse=True)
    chosen = {0, len(lines) - 1}

    for i, ln, sc in ranked:
        if len(chosen) >= max_lines:
            break
        if sc > 0:
            chosen.add(i)

    if add_neighbors and len(chosen) < max_lines:
        for i, ln, sc in ranked:
            if len(chosen) >= max_lines:
                break
            if sc <= 0:
                continue
            for j in (i - 1, i + 1):
                if 0 <= j < len(lines):
                    chosen.add(j)
                    if len(chosen) >= max_lines:
                        break

    if len(chosen) < max_lines:
        for i in range(len(lines)):
            if len(chosen) >= max_lines:
                break
            chosen.add(i)

    return "\n".join(lines[i] for i in sorted(chosen))


def _path_has_danger(line: str) -> bool:
    return bool(re.search(
        r'\b(memcpy|memmove|memset|strcpy|strncpy|strcat|strncat|sprintf|snprintf|vsprintf|'
        r'gets|fgets|read|write|recv|send|malloc|calloc|realloc|free|system|popen|exec\w*)\b',
        line or '', re.IGNORECASE))


def _path_has_defense(line: str) -> bool:
    return bool(re.search(
        r'\b(?:if|while|assert|BUG_ON|WARN_ON)\s*\([^\n]*(?:NULL|nullptr|==|!=|<=|>=|<|>|sizeof|len|size|count|index|idx|bound)',
        line or '', re.IGNORECASE))


def _path_relation_prefix(text: str) -> str:
    lines = (text or '').splitlines()
    dangers = [i for i, ln in enumerate(lines) if _path_has_danger(ln)]
    defenses = [i for i, ln in enumerate(lines) if _path_has_defense(ln)]
    tags = []
    if dangers:
        if any(g < d for g in defenses for d in dangers):
            tags.append('[DEFENSE_TO_DANGER]')
        elif not defenses or not any(g < d for g in defenses for d in dangers):
            tags.append('[UNGUARDED_DANGER]')
    return ' '.join(tags)


def _insert_semantic_markers(text_str: str) -> str:
    """Insert markers while preserving the original lexical code.

    v7.0/v7.2 replaced matched spans (including complete if-guards) with a
    marker.  On minimal patches that can erase the only changed condition.
    v7.3 inserts markers before the span and keeps the original text intact.
    """
    text_str = text_str or ''
    inserts = defaultdict(set)

    for op in danger_op_keywords:
        try:
            for m in re.finditer(r'\b' + re.escape(op) + r'\b', text_str, re.IGNORECASE):
                inserts[m.start()].add('[DANGER_OP]')
        except re.error:
            pass
    for op in pointer_op_keywords:
        try:
            for m in re.finditer(r'\b' + re.escape(op) + r'\b', text_str, re.IGNORECASE):
                inserts[m.start()].add('[POINTER_OP]')
        except re.error:
            pass
    for pattern in defense_op_patterns:
        for m in pattern.finditer(text_str):
            inserts[m.start()].add('[DEFENSE_OP]')
    # Broader bounds/check guards complement the conservative base patterns.
    for m in re.finditer(
        r'\b(?:if|while)\s*\([^\n]*(?:<=|>=|<|>|sizeof|len|size|count|index|idx|bound)[^\n]*\)',
        text_str, re.IGNORECASE):
        inserts[m.start()].add('[DEFENSE_OP]')
    for m in re.finditer(r'<\s*(DEF|USE)\s*:[^>]*>', text_str):
        inserts[m.start()].add('[DATA_FLOW]')

    if not inserts:
        return text_str

    priority = {
        '[DANGER_OP]': 0, '[POINTER_OP]': 1, '[DEFENSE_OP]': 2, '[DATA_FLOW]': 3
    }
    pieces, last = [], 0
    for pos in sorted(inserts):
        if pos > last:
            pieces.append(text_str[last:pos])
        marks = sorted(inserts[pos], key=lambda x: priority.get(x, 99))
        pieces.append(' '.join(marks) + ' ')
        last = pos
    pieces.append(text_str[last:])
    return ''.join(pieces)


def text_to_tokens_and_special_pos(text_str, tokenizer, args, path_source='cfg'):
    source_marker = '[ANCHOR_PATH]' if path_source == 'anchor' else '[CFG_PATH]'
    relation_prefix = _path_relation_prefix(text_str)
    enhanced_text = f"{source_marker} {relation_prefix} {_insert_semantic_markers(text_str)}".strip()

    seq_tokens = tokenizer.tokenize(enhanced_text)
    max_len = args.block_size - 2
    if len(seq_tokens) > max_len:
        # Preserve both ends; anchor paths are short, while CFG paths can be long.
        half = max_len // 2
        seq_tokens = seq_tokens[:half] + seq_tokens[-(half + max_len % 2):]

    final_tokens = [tokenizer.cls_token] + seq_tokens + [tokenizer.sep_token]
    seq_ids = tokenizer.convert_tokens_to_ids(final_tokens)
    seq_ids += [tokenizer.pad_token_id] * (args.block_size - len(seq_ids))
    seq_ids = seq_ids[:args.block_size]

    pos_info = defaultdict(list)
    special_names = [
        '[DANGER_OP]', '[POINTER_OP]', '[DEFENSE_OP]', '[DATA_FLOW]',
        '[DEFENSE_TO_DANGER]', '[UNGUARDED_DANGER]', '[ANCHOR_PATH]', '[CFG_PATH]'
    ]
    for token_type in special_names:
        token_id_val = tokenizer.convert_tokens_to_ids(token_type)
        for i, token_id in enumerate(seq_ids):
            if token_id == token_id_val:
                pos_info[token_type].append(i)
    return seq_ids, pos_info


def _path_intrinsic_score(text: str, source='cfg') -> float:
    score = 0.25 if source == 'anchor' else 0.0
    for ln in (text or '').splitlines():
        if _path_has_danger(ln): score += 3.0
        if _path_has_defense(ln): score += 2.4
        if re.search(r'<\s*(DEF|USE)\s*:', ln): score += 1.5
        if re.search(r'(?:->|\*\s*[A-Za-z_(]|\[[^\]]+\])', ln): score += 0.6
    prefix = _path_relation_prefix(text)
    if '[DEFENSE_TO_DANGER]' in prefix: score += 2.0
    if '[UNGUARDED_DANGER]' in prefix: score += 1.5
    return score


def _path_token_set(text: str):
    return set(re.findall(r'[A-Za-z_]\w*|==|!=|<=|>=|->|\d+', text or ''))


def _path_line_set_v74(text: str):
    return {
        re.sub(r'\s+', ' ', x).strip()
        for x in (text or '').splitlines()
        if re.sub(r'\s+', ' ', x).strip()
    }


def _line_similarity_v74(a, b):
    if not a or not b:
        return 0.0
    return len(a & b) / max(1, len(a | b))


def _select_current_function_paths(records, k: int, diversity_lambda=0.35):
    """v7.4 source-aware risk/diversity selector.

    Preprocessing already removes the dominant CFG-CFG redundancy. This is a
    final cap for unusually path-rich functions. It never reads teacher scores.
    """
    if len(records) <= k:
        return records

    remaining = [dict(r) for r in records]
    for r in remaining:
        r['_lines_v74'] = _path_line_set_v74(r.get('text', ''))

    selected = []
    used_sources = set()

    while remaining and len(selected) < k:
        best_i, best_val = 0, -1e30
        for i, r in enumerate(remaining):
            base = float(r.get('score', _path_intrinsic_score(r['text'], r['source'])))

            if not selected:
                novelty = 1.0
            else:
                sims = [
                    _line_similarity_v74(r['_lines_v74'], q['_lines_v74'])
                    for q in selected
                ]
                novelty = 1.0 - max(sims, default=0.0)

            source_bonus = 0.15 if r.get('source') not in used_sources else 0.0

            # Same-source CFG near-duplicates receive an additional penalty.
            cfg_dup_penalty = 0.0
            if r.get('source') == 'cfg':
                for q in selected:
                    if q.get('source') != 'cfg':
                        continue
                    sim = _line_similarity_v74(r['_lines_v74'], q['_lines_v74'])
                    if sim >= 0.75:
                        cfg_dup_penalty = max(cfg_dup_penalty, 1.25 * sim)

            val = (
                base
                + float(diversity_lambda) * novelty
                + source_bonus
                - cfg_dup_penalty
            )
            if val > best_val:
                best_i, best_val = i, val

        chosen = remaining.pop(best_i)
        selected.append(chosen)
        used_sources.add(chosen.get('source'))

    for r in selected:
        r.pop('_lines_v74', None)
    return selected


def convert_examples_to_features(js, path_dict, tokenizer, args):
    """Build v7.3 features from current-function candidates.

    TRAIN PKLs may carry teacher_path_scores, but these scores are never used to
    choose paths or create model input tokens.  They are returned only as an
    auxiliary loss target.
    """
    try:
        current_idx = js.get('idx')
        idx_label = int(js.get('target'))
        vul_type = js.get('vul_type', 'unknown')
        pair_id = js.get('pair_id', None)
        original_func = js.get('func_main') or js.get('func') or js.get('code') or ''
        if idx_label not in {0, 1}:
            return None, f"Invalid target label: {idx_label}"
        if not isinstance(original_func, str) or len(original_func.strip()) < 20:
            return None, "current function is empty/too short"

        sample_entry = path_dict.get(current_idx)
        if sample_entry is None:
            if isinstance(current_idx, str) and current_idx.isdigit():
                sample_entry = path_dict.get(int(current_idx))
            elif isinstance(current_idx, int):
                sample_entry = path_dict.get(str(current_idx))

        max_paths_main = int(getattr(args, 'max_paths_main', getattr(args, 'max_paths', 12)))
        max_global_lines = int(getattr(args, 'max_global_lines', 140))
        diversity_lambda = float(getattr(args, 'path_diversity_lambda', 0.35))

        records = []
        if isinstance(sample_entry, dict):
            paths = sample_entry.get('path_token', []) or []
            sources = sample_entry.get('path_source', []) or []
            intrinsic = sample_entry.get('path_intrinsic_score', []) or []
            teacher = sample_entry.get('teacher_path_scores', []) or []
            for i, text in enumerate(paths):
                if not isinstance(text, str) or not text.strip():
                    continue
                source = sources[i] if i < len(sources) else 'cfg'
                score = float(intrinsic[i]) if i < len(intrinsic) else _path_intrinsic_score(text, source)
                tscore = float(teacher[i]) if i < len(teacher) else 0.0
                records.append({'text': text, 'source': source, 'score': score, 'teacher': tscore})

        path_source_summary = 'cfg'
        if not records:
            path_source_summary = 'raw_function_fallback'
            fallback = build_global_snippet_by_keylines(
                original_func, max_lines=max_global_lines, add_neighbors=True
            )
            records = [{
                'text': fallback if fallback.strip() else original_func,
                'source': 'anchor', 'score': 0.0, 'teacher': 0.0,
            }]

        selected = _select_current_function_paths(records, max_paths_main, diversity_lambda)
        main_keep = [r['text'] for r in selected]
        source_keep = [r['source'] for r in selected]
        teacher_keep = [float(r.get('teacher', 0.0)) for r in selected]
        if any(x == 'anchor' for x in source_keep) and any(x == 'cfg' for x in source_keep):
            path_source_summary = 'cfg+anchor'
        elif source_keep:
            path_source_summary = source_keep[0]

        all_seq_ids, all_pos_info = [], []
        for path_code_str, path_source in zip(main_keep, source_keep):
            seq_ids, pos_info = text_to_tokens_and_special_pos(
                path_code_str, tokenizer, args, path_source=path_source
            )
            all_seq_ids.append(seq_ids)
            all_pos_info.append(pos_info)
        if not all_seq_ids:
            return None, 'No valid current-function path sequences generated'

        # Preserve lexical code in the global stream too; semantic markers are
        # inserted rather than replacing the guard/API itself.
        global_snippet = build_global_snippet_by_keylines(
            original_func, max_lines=max_global_lines, add_neighbors=True
        )
        global_marked = _insert_semantic_markers(global_snippet)
        global_tokens = tokenizer.tokenize(global_marked)
        max_len_global = args.block_size - 2
        if len(global_tokens) > max_len_global:
            half = max_len_global // 2
            global_tokens = global_tokens[:half] + global_tokens[-(half + max_len_global % 2):]
        global_final_tokens = [tokenizer.cls_token] + global_tokens + [tokenizer.sep_token]
        global_input_ids = tokenizer.convert_tokens_to_ids(global_final_tokens)
        global_input_ids += [tokenizer.pad_token_id] * (args.block_size - len(global_input_ids))
        global_input_ids = global_input_ids[:args.block_size]

        return InputFeatures(
            current_idx, all_seq_ids, all_pos_info, global_input_ids, idx_label,
            vul_type, original_func, pair_id=pair_id, raw_paths=main_keep,
            path_source=source_keep, teacher_path_scores=teacher_keep,
        ), None
    except Exception as e:
        return None, f"Unhandled exception for idx={js.get('idx', 'N/A')}: {e}\n{traceback.format_exc()}"


def _process_line_wrapper(line_info, **kwargs):
    line_index, line_content = line_info
    use_cache = kwargs['use_cache']
    cache_dir = kwargs['cache_dir']
    worker_func_partial = kwargs['worker_func_partial']

    line_strip = line_content.strip()
    if not line_strip:
        return None, "Empty line"

    cache_key = hashlib.md5(f"{line_strip}-{line_index}-{CACHE_VERSION}".encode('utf-8')).hexdigest()
    cache_file = os.path.join(cache_dir, f"{cache_key}.pkl")

    if use_cache and os.path.exists(cache_file):
        try:
            with open(cache_file, 'rb') as f:
                return pickle.load(f)
        except Exception:
            pass

    try:
        js = json.loads(line_strip)
        if 'idx' not in js:
            js['idx'] = f"line_{line_index}"
        feature, reason = worker_func_partial(js=js)

        if use_cache and feature is not None:
            safe_makedirs(cache_dir)
            with open(cache_file, 'wb') as f:
                pickle.dump((feature, reason), f)

        return feature, reason
    except Exception as e:
        return None, f"JSON/Cache error on line {line_index}: {e}"


def assert_v73_path_dict(path_dict, pkl_file, task_name=''):
    if not isinstance(path_dict, dict):
        raise TypeError(f"Path PKL must be a dict: {pkl_file}")
    forbidden_fields = {
        'patch_path_token', 'has_patch', 'diff_coverage_ratio', 'diff_nodes_detail',
        'func_patch', 'counterpart_path_token',
    }
    is_train = str(task_name).lower().startswith('train')
    for idx, rec in path_dict.items():
        if not isinstance(rec, dict):
            continue
        present = sorted(forbidden_fields.intersection(rec.keys()))
        if present:
            raise RuntimeError(
                f"V7.3 protocol violation: legacy counterpart input fields {present} "
                f"found at idx={idx} in {pkl_file}"
            )
        if rec.get('strict_single_function', False) is not True:
            raise RuntimeError(
                f"V7.3 requires current-function candidate paths: idx={idx}, file={pkl_file}"
            )
        has_teacher = bool(rec.get('teacher_train_only', False) or rec.get('teacher_path_scores'))
        if has_teacher and not is_train:
            raise RuntimeError(
                f"V7.3 validation/test PKL contains train-only pair teacher data at idx={idx}. "
                "Regenerate PKLs with data_process_single.py v7.4."
            )



# =========================
# Dataset
# =========================
class TextDataset(Dataset):
    def __init__(self, tokenizer, args, file_path, pkl_file,
                 use_cache=False, cache_dir='cached_features', task_name=""):
        self.tokenizer = tokenizer
        self.args = args
        self.examples = []
        self.skipped_reasons = Counter()

        lg = logging.getLogger(f"{__name__}.TextDataset.{task_name}")
        lg.info(f"[{task_name}] 加载路径字典: {pkl_file}")

        try:
            with open(pkl_file, 'rb') as f:
                path_dict = pickle.load(f)
            if isinstance(path_dict, list):
                new_map = {}
                for rec in path_dict:
                    if not isinstance(rec, dict):
                        continue
                    ridx = rec.get("idx")
                    if ridx is None:
                        continue
                    new_map[ridx] = rec
                    if isinstance(ridx, str) and ridx.isdigit():
                        new_map[int(ridx)] = rec
                    elif isinstance(ridx, int):
                        new_map[str(ridx)] = rec
                path_dict = new_map
            assert_v73_path_dict(path_dict, pkl_file, task_name=task_name)
        except Exception as e:
            lg.error(f"无法加载 PKL 文件 {pkl_file}: {e}")
            raise

        lg.info(f"[{task_name}] 加载数据源: {file_path}")
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = list(enumerate(f))
        except Exception as e:
            lg.error(f"无法加载 JSONL 文件 {file_path}: {e}")
            return

        if use_cache:
            safe_makedirs(cache_dir)

        worker_func = partial(convert_examples_to_features, path_dict=path_dict,
                              tokenizer=tokenizer, args=args)
        process_line_func = partial(
            _process_line_wrapper,
            use_cache=use_cache, cache_dir=cache_dir, worker_func_partial=worker_func
        )

        def _run_multiprocess():
            with ProcessPoolExecutor(max_workers=args.num_preprocessing_workers) as executor:
                results = tqdm(
                    executor.map(process_line_func, lines, chunksize=args.preprocessing_chunksize),
                    total=len(lines), desc=f"[{task_name}] 转换特征"
                )
                for feature, reason in results:
                    if feature:
                        self.examples.append(feature)
                    else:
                        self.skipped_reasons[reason or "Unknown"] += 1

        def _run_singleprocess():
            for li in tqdm(lines, total=len(lines), desc=f"[{task_name}] 转换特征(单进程)"):
                feature, reason = process_line_func(li)
                if feature:
                    self.examples.append(feature)
                else:
                    self.skipped_reasons[reason or "Unknown"] += 1

        try:
            if int(getattr(args, "num_preprocessing_workers", 0)) > 0:
                _run_multiprocess()
            else:
                _run_singleprocess()
        except Exception as e:
            lg.warning(f"[{task_name}] 多进程失败，回退单进程: {e}")
            self.examples = []
            self.skipped_reasons = Counter()
            _run_singleprocess()

        source_counts = Counter(
            "+".join(sorted(set(getattr(ex, "path_source", []) or ["unknown"])))
            for ex in self.examples
        )
        n_pair = len({ex.pair_id for ex in self.examples if ex.pair_id is not None})
        lg.info(f"[{task_name}] path_source={dict(source_counts)}")
        lg.info(f"[{task_name}] 完成: 加载 {len(self.examples)}，跳过 "
                f"{sum(self.skipped_reasons.values())}，pair_id 数={n_pair}")
        if self.skipped_reasons:
            lg.warning(f"[{task_name}] 跳过原因 Top10: {self.skipped_reasons.most_common(10)}")

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, i):
        ex = self.examples[i]
        bs = self.args.block_size
        special_names = [
            '[DANGER_OP]', '[POINTER_OP]', '[DEFENSE_OP]', '[DATA_FLOW]',
            '[DEFENSE_TO_DANGER]', '[UNGUARDED_DANGER]', '[ANCHOR_PATH]', '[CFG_PATH]'
        ]

        if not ex.original_func or len(ex.original_func.strip()) < 30:
            zero_path = [[self.tokenizer.pad_token_id] * bs]
            out = {
                'path_ids': zero_path,
                'global_ids': [self.tokenizer.pad_token_id] * bs,
                'vuln_label': -100,
                'original_index': i,
                'pair_id': ex.pair_id,
                'teacher_path_scores': [0.0],
            }
            key_map = {
                '[DANGER_OP]':'danger_mask', '[POINTER_OP]':'pointer_mask',
                '[DEFENSE_OP]':'defense_mask', '[DATA_FLOW]':'data_mask',
                '[DEFENSE_TO_DANGER]':'def2danger_mask', '[UNGUARDED_DANGER]':'unguarded_mask',
                '[ANCHOR_PATH]':'anchor_mask', '[CFG_PATH]':'cfg_mask',
            }
            for key in key_map.values(): out[key] = [[0] * bs]
            return out

        path_ids = [p[:bs] for p in ex.input_ids]
        mask_lists = {name: [] for name in special_names}
        for pos_info in ex.special_token_pos:
            for name in special_names:
                arr = [0] * bs
                for pos in pos_info.get(name, []):
                    if 0 <= pos < bs:
                        arr[pos] = 1
                mask_lists[name].append(arr)

        return {
            'path_ids': path_ids,
            'danger_mask': mask_lists['[DANGER_OP]'],
            'pointer_mask': mask_lists['[POINTER_OP]'],
            'defense_mask': mask_lists['[DEFENSE_OP]'],
            'data_mask': mask_lists['[DATA_FLOW]'],
            'def2danger_mask': mask_lists['[DEFENSE_TO_DANGER]'],
            'unguarded_mask': mask_lists['[UNGUARDED_DANGER]'],
            'anchor_mask': mask_lists['[ANCHOR_PATH]'],
            'cfg_mask': mask_lists['[CFG_PATH]'],
            'global_ids': ex.global_input_ids,
            'vuln_label': ex.label,
            'original_index': i,
            'pair_id': ex.pair_id,
            'teacher_path_scores': list(ex.teacher_path_scores[:len(path_ids)]),
        }


def collate_fn(batch, pad_token_id, max_paths_main, path_dropout_rate=0.0):
    """Current-function tensors + TRAIN-only localization targets."""
    original_indices = [item['original_index'] for item in batch]
    pair_ids = [item.get('pair_id', None) for item in batch]
    path_ids_list = [list(item['path_ids']) for item in batch]
    mask_keys = [
        'danger_mask', 'pointer_mask', 'defense_mask', 'data_mask',
        'def2danger_mask', 'unguarded_mask', 'anchor_mask', 'cfg_mask',
    ]
    masks = {k: [list(x) for x in [item[k] for item in batch]] for k in mask_keys}
    teacher_list = [list(item.get('teacher_path_scores', [])) for item in batch]
    global_ids_list = [item['global_ids'] for item in batch]
    vuln_labels_list = [item['vuln_label'] for item in batch]

    if path_dropout_rate > 0:
        for i in range(len(path_ids_list)):
            n = len(path_ids_list[i])
            if n <= 1:
                continue
            keep = max(1, int(round(n * (1.0 - path_dropout_rate))))
            if keep >= n:
                continue
            mandatory = []
            ts = teacher_list[i]
            if ts and max(ts) > 0:
                mandatory = [max(range(min(len(ts), n)), key=lambda j: ts[j])]
            pool = [j for j in range(n) if j not in mandatory]
            need = max(0, keep - len(mandatory))
            sel = sorted(mandatory + random.sample(pool, min(need, len(pool))))
            path_ids_list[i] = [path_ids_list[i][j] for j in sel]
            for k in mask_keys:
                masks[k][i] = [masks[k][i][j] for j in sel]
            teacher_list[i] = [teacher_list[i][j] if j < len(teacher_list[i]) else 0.0 for j in sel]

    B = len(batch)
    block_size = len(path_ids_list[0][0]) if path_ids_list and path_ids_list[0] else 0
    T = max(1, min(max((len(p) for p in path_ids_list), default=1), max_paths_main))
    path_ids_t = torch.full((B, T, block_size), pad_token_id, dtype=torch.long)
    mask_tensors = {k: torch.zeros((B, T, block_size), dtype=torch.long) for k in mask_keys}
    path_mask_t = torch.zeros((B, T), dtype=torch.float)
    teacher_t = torch.zeros((B, T), dtype=torch.float)
    teacher_available_t = torch.zeros((B,), dtype=torch.float)

    for i in range(B):
        t = min(len(path_ids_list[i]), T)
        if t <= 0:
            continue
        path_ids_t[i, :t] = torch.tensor(path_ids_list[i][:t], dtype=torch.long)
        for k in mask_keys:
            mask_tensors[k][i, :t] = torch.tensor(masks[k][i][:t], dtype=torch.long)
        path_mask_t[i, :t] = 1.0
        ts = teacher_list[i][:t]
        if ts:
            teacher_t[i, :len(ts)] = torch.tensor(ts, dtype=torch.float)
            if max(ts) > 0:
                teacher_available_t[i] = 1.0

    global_ids_t = torch.tensor(global_ids_list, dtype=torch.long)
    out = {
        'path_ids': path_ids_t,
        'path_attention_mask': (path_ids_t != pad_token_id).long(),
        'path_mask': path_mask_t,
        'global_ids': global_ids_t,
        'global_attention_mask': (global_ids_t != pad_token_id).long(),
        'vuln_labels': torch.tensor(vuln_labels_list, dtype=torch.long),
        'teacher_path_scores': teacher_t,
        'teacher_available': teacher_available_t,
        'original_indices': original_indices,
        'pair_ids': pair_ids,
    }
    out.update(mask_tensors)
    return out


# =========================
# Pair-aware batching / losses
# =========================
class PairBatchSampler(Sampler):
    """每个 batch 由 pairs_per_batch 个完整 pair 组成（batch_size = 2 * pairs_per_batch）。"""

    def __init__(self, examples, pairs_per_batch=2, shuffle=True, seed=42, drop_unpaired=True):
        self.pairs_per_batch = max(1, int(pairs_per_batch))
        self.shuffle = shuffle
        self.seed = seed
        self.epoch = 0

        by_pair = defaultdict(dict)
        unpaired = []
        for i, ex in enumerate(examples):
            pid = getattr(ex, "pair_id", None)
            lab = int(getattr(ex, "label", -1))
            if pid is None or lab not in (0, 1):
                unpaired.append(i)
                continue
            if lab in by_pair[pid]:
                unpaired.append(i)
            else:
                by_pair[pid][lab] = i

        self.pairs = []
        for pid, d in by_pair.items():
            if 0 in d and 1 in d:
                self.pairs.append((d[1], d[0]))   # (vulnerable, patched)
            else:
                unpaired.extend(d.values())

        self.unpaired = [] if drop_unpaired else unpaired
        self.batches = self._build()

    def _build(self):
        rng = random.Random(self.seed + self.epoch)
        pairs = list(self.pairs)
        singles = list(self.unpaired)
        if self.shuffle:
            rng.shuffle(pairs)
            rng.shuffle(singles)

        batches = []
        for s in range(0, len(pairs), self.pairs_per_batch):
            flat = []
            for v, p in pairs[s:s + self.pairs_per_batch]:
                flat.extend([v, p])
            batches.append(flat)

        bs = 2 * self.pairs_per_batch
        for s in range(0, len(singles), bs):
            chunk = singles[s:s + bs]
            if chunk:
                batches.append(chunk)

        if self.shuffle:
            rng.shuffle(batches)
        return batches

    def set_epoch(self, epoch):
        self.epoch = int(epoch)
        self.batches = self._build()

    def __iter__(self):
        for b in self.batches:
            yield b

    def __len__(self):
        return len(self.batches)

    @property
    def num_pairs(self):
        return len(self.pairs)


def _batch_pair_index(pair_ids, labels):
    buckets = defaultdict(dict)
    for i, pid in enumerate(pair_ids):
        if pid is None:
            continue
        lab = int(labels[i].item())
        if lab in (0, 1) and lab not in buckets[pid]:
            buckets[pid][lab] = i
    vi, pi = [], []
    for d in buckets.values():
        if 0 in d and 1 in d:
            vi.append(d[1]); pi.append(d[0])
    return vi, pi


def compute_pair_losses(
    logits,
    embedding,
    pair_ids,
    labels,
    margin=0.5,
    rank_temperature=1.0,
):
    """
    Pair supervision applied AFTER independent single-function forwards.

    risk = logit(class=1) - logit(class=0)
    L_rank = softplus((margin - (risk_v - risk_safe))/T) * T

    Minimal vuln/patch pairs are NOT forced far apart in embedding space.
    The optional close loss preserves their shared semantics.
    """
    device = logits.device
    zero = torch.zeros((), device=device, dtype=logits.dtype)
    groups = defaultdict(dict)
    for i, pid in enumerate(pair_ids or []):
        if pid is None:
            continue
        lab = int(labels[i].item())
        if lab in (0, 1) and lab not in groups[str(pid)]:
            groups[str(pid)][lab] = i

    rank_items, close_items, gaps, orders = [], [], [], []
    risk = logits[:, 1] - logits[:, 0]
    temp = max(float(rank_temperature), 1e-4)

    for d in groups.values():
        if 0 not in d or 1 not in d:
            continue
        vi, si = d[1], d[0]
        gap = risk[vi] - risk[si]
        rank_items.append(F.softplus((float(margin) - gap) / temp) * temp)
        gaps.append(float(gap.detach().item()))
        orders.append(float((gap.detach() > 0).item()))
        if embedding is not None:
            cos = F.cosine_similarity(
                embedding[vi].unsqueeze(0), embedding[si].unsqueeze(0), dim=-1
            ).squeeze(0)
            close_items.append(1.0 - cos)

    n_pairs = len(rank_items)
    if n_pairs == 0:
        return zero, zero, 0, 0.0, 0.0

    rank_loss = torch.stack(rank_items).mean()
    close_loss = torch.stack(close_items).mean() if close_items else zero
    mean_gap = float(sum(gaps) / len(gaps))
    order_acc = float(sum(orders) / len(orders))
    return rank_loss, close_loss, n_pairs, mean_gap, order_acc


def compute_localization_loss(path_weights, teacher_scores, path_mask):
    """Cross-entropy from train-only minimal-change teacher to path attention."""
    if path_weights is None or teacher_scores is None:
        return torch.zeros((), device=path_mask.device if path_mask is not None else 'cpu')
    valid_mask = (path_mask > 0).float()
    target = teacher_scores.float().clamp(min=0.0) * valid_mask
    row_sum = target.sum(dim=1)
    valid_rows = row_sum > 0
    if not valid_rows.any():
        return torch.zeros((), device=path_weights.device, dtype=path_weights.dtype)
    target = target / row_sum.unsqueeze(1).clamp(min=1e-9)
    logw = torch.log(path_weights.clamp(min=1e-8))
    loss = -(target * logw).sum(dim=1)
    return loss[valid_rows].mean()


def active_pair_rank_weight(args, epoch):
    start = float(getattr(args, 'pair_rank_start_weight', 0.05))
    peak = float(getattr(args, 'pair_rank_weight', 0.10))
    peak_until = int(getattr(args, 'pair_rank_peak_until_epoch', 2))
    decay = float(getattr(args, 'pair_rank_decay', 0.75))
    min_w = float(getattr(args, 'pair_rank_min_weight', 0.02))
    if epoch <= 0:
        return start
    if epoch <= peak_until:
        return peak
    return max(min_w, peak * (decay ** (epoch - peak_until)))


def active_localization_weight(args, epoch):
    base = float(getattr(args, 'localization_weight', 0.15))
    hold = int(getattr(args, 'localization_hold_until_epoch', 3))
    decay = float(getattr(args, 'localization_decay', 0.85))
    min_w = float(getattr(args, 'localization_min_weight', 0.05))
    if epoch <= hold:
        return base
    return max(min_w, base * (decay ** (epoch - hold)))


class FocalLoss(nn.Module):
    """Cross-entropy when gamma=0; optional focal modulation otherwise."""
    def __init__(self, weight=None, gamma=0.0, label_smoothing=0.0, reduction="mean"):
        super().__init__()
        self.gamma = float(gamma)
        self.weight = weight
        self.label_smoothing = float(label_smoothing)
        self.reduction = reduction

    def forward(self, logits, labels):
        ce = F.cross_entropy(
            logits,
            labels,
            weight=self.weight,
            reduction="none",
            label_smoothing=self.label_smoothing,
        )
        if self.gamma <= 0:
            loss = ce
        else:
            probs = torch.softmax(logits.float(), dim=-1)
            pt = probs.gather(1, labels.view(-1, 1)).squeeze(1).to(ce.dtype)
            loss = ((1.0 - pt).clamp(min=0.0) ** self.gamma) * ce

        if self.reduction == "sum":
            return loss.sum()
        if self.reduction == "none":
            return loss
        return loss.mean()


# =========================
# Metrics
# =========================
def compute_vds(all_labels, all_probs, target_fpr=0.0005):
    """VD-S: FNR% at fixed FPR. Lower is better."""
    if len(set(all_labels)) < 2:
        return 100.0
    fpr_arr, tpr_arr, _ = roc_curve(all_labels, all_probs)
    idx = np.where(fpr_arr <= target_fpr)[0]
    if len(idx) == 0:
        return 100.0
    return float((1.0 - tpr_arr[idx[-1]]) * 100.0)


def compute_bacc(all_labels, all_preds):
    tn, fp, fn, tp = confusion_matrix(all_labels, all_preds, labels=[0, 1]).ravel()
    tpr = tp / max(tp + fn, 1)
    tnr = tn / max(tn + fp, 1)
    return (tpr + tnr) / 2.0


def search_best_threshold(all_labels, all_probs, metric="mcc", t_min=0.05, t_max=0.95, t_step=0.01):
    if t_step <= 0:
        t_step = 0.01
    if t_max < t_min:
        t_min, t_max = t_max, t_min

    best_threshold, best_score = 0.5, -1e18
    for t in np.arange(t_min, t_max + 1e-12, t_step):
        preds = [1 if p >= t else 0 for p in all_probs]
        if metric == "f1":
            score = f1_score(all_labels, preds, zero_division=0)
        elif metric == "recall":
            score = recall_score(all_labels, preds, zero_division=0)
        elif metric == "precision":
            score = precision_score(all_labels, preds, zero_division=0)
        else:
            score = matthews_corrcoef(all_labels, preds)
        if score > best_score:
            best_score = score
            best_threshold = float(t)
    return float(best_threshold), float(best_score)


def load_primevul_pair_meta(jsonl_path):
    """idx -> {pair_id, target}"""
    meta = {}
    with open(jsonl_path, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            row = json.loads(line)
            idx = row.get("idx")
            if idx is None:
                continue
            pid = row.get("pair_id")
            tgt = row.get("target")
            meta[str(idx)] = {
                "pair_id": None if pid is None else str(pid),
                "target": None if tgt is None else int(tgt),
            }
    return meta


def pair_metrics_from_scores(example_ids, labels, probs, meta, threshold):
    """
    从已缓存的单函数分数直接算 PrimeVul pair 指标，不需要重复前向。
      P-C: vulnerable->1 且 patched->0
      P-V: 两个都 ->1
      P-B: 两个都 ->0
      P-R: 反了
      PairAcc(补充): score(vul) > score(patch)
    """
    groups = defaultdict(dict)
    for eid, lab, prob in zip(example_ids, labels, probs):
        m = meta.get(str(eid))
        if not m or m["pair_id"] is None or m["target"] is None:
            continue
        groups[m["pair_id"]][int(m["target"])] = (float(prob), int(float(prob) >= float(threshold)))

    pc = pv = pb = pr = pairacc = 0
    complete = missing = 0
    detailed = []

    for pid, g in groups.items():
        if 1 not in g or 0 not in g:
            missing += 1
            continue
        complete += 1
        (v_prob, v_pred) = g[1]
        (p_prob, p_pred) = g[0]

        if v_pred == 1 and p_pred == 0:
            pc += 1; cat = "P-C"
        elif v_pred == 1 and p_pred == 1:
            pv += 1; cat = "P-V"
        elif v_pred == 0 and p_pred == 0:
            pb += 1; cat = "P-B"
        else:
            pr += 1; cat = "P-R"

        if v_prob > p_prob:
            pairacc += 1

        detailed.append({
            "pair_id": pid, "vul_pred": v_pred, "patch_pred": p_pred,
            "vul_prob": v_prob, "patch_prob": p_prob, "category": cat,
        })

    if complete == 0:
        return {"pairs": 0, "P-C": 0.0, "P-V": 0.0, "P-B": 0.0, "P-R": 0.0,
                "PairAcc": 0.0, "incomplete_pair_groups": missing,
                "counts": {"P-C": 0, "P-V": 0, "P-B": 0, "P-R": 0, "PairAcc": 0}}, []

    return {
        "pairs": complete,
        "incomplete_pair_groups": missing,
        "P-C": pc / complete, "P-V": pv / complete,
        "P-B": pb / complete, "P-R": pr / complete,
        "PairAcc": pairacc / complete,
        "counts": {"P-C": pc, "P-V": pv, "P-B": pb, "P-R": pr, "PairAcc": pairacc},
    }, detailed


def search_best_pair_threshold(example_ids, labels, probs, meta,
                               t_min=0.05, t_max=0.95, t_step=0.01):
    best_t, best_pc = 0.5, -1.0
    records = []
    for t in np.arange(t_min, t_max + 1e-12, t_step):
        res, _ = pair_metrics_from_scores(example_ids, labels, probs, meta, float(t))
        records.append({
            "threshold": round(float(t), 4),
            "P-C": round(res["P-C"], 4), "P-V": round(res["P-V"], 4),
            "P-B": round(res["P-B"], 4), "P-R": round(res["P-R"], 4),
            "PairAcc": round(res["PairAcc"], 4), "pairs": res["pairs"],
        })
        if res["P-C"] > best_pc:
            best_pc = res["P-C"]
            best_t = float(t)
    return float(best_t), float(best_pc), records


# =========================
# Evaluate
# =========================
def _get_base_dataset(dataset):
    return dataset.dataset if isinstance(dataset, Subset) else dataset


def save_error_analysis(args, dataloader, indices, labels, preds, probs, task_name,
                        path_weight_rows=None):
    base = _get_base_dataset(dataloader.dataset)
    errors = []
    for i in range(len(preds)):
        if preds[i] == labels[i]:
            continue
        try:
            ex = base.examples[indices[i]]
        except Exception:
            ex = None
        raw_paths = getattr(ex, 'raw_paths', []) if ex else []
        weights = path_weight_rows[i] if path_weight_rows and i < len(path_weight_rows) else []
        ranked = []
        for j, w in enumerate(weights[:len(raw_paths)]):
            ranked.append((float(w), j, raw_paths[j]))
        ranked.sort(reverse=True, key=lambda x: x[0])
        errors.append({
            'id': getattr(ex, 'idx', indices[i]) if ex else indices[i],
            'pair_id': getattr(ex, 'pair_id', None) if ex else None,
            'true': int(labels[i]), 'pred': int(preds[i]),
            'prob': float(probs[i]),
            'type': getattr(ex, 'vul_type', 'unknown') if ex else 'unknown',
            'func': (getattr(ex, 'original_func', '')[:12000] if ex else ''),
            'num_paths': len(raw_paths),
            'paths_preview': raw_paths[:3],
            'path_weights': [float(x) for x in weights[:len(raw_paths)]],
            'top_attention_paths': [
                {'weight': w, 'path_index': j, 'text': text[:2500]}
                for w, j, text in ranked[:3]
            ],
        })

    out_name = f"errors_{task_name.replace('/', '_').replace(' ', '_')}.jsonl"
    out_path = os.path.join(args.output_dir, out_name)
    with open(out_path, 'w', encoding='utf-8') as f:
        for err in errors:
            f.write(json.dumps(err, ensure_ascii=False) + '\n')
    logger.info(f"[{task_name}] 错误样本已保存: {out_path}, count={len(errors)}")


def evaluate(args, model, eval_dataloader, is_test=False, task_name="", stage_label=None,
             error_analysis=False, save_preds_path=None, forced_threshold=None,
             temperature=1.0, search_metric=None):
    """
    Strict evaluation: identical forward representation to training.

    _ids/_labels/_probs are cached only for post-hoc metrics; they never alter
    any sample's inference score.
    """
    model.eval()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    # Same single-function forward in train/valid/test.
    m = model.module if hasattr(model, 'module') else model

    base_ds = _get_base_dataset(eval_dataloader.dataset)

    all_labels, all_probs, all_indices = [], [], []
    all_path_weights = []
    eval_loss_sum, eval_steps = 0.0, 0

    for batch in tqdm(eval_dataloader, desc=f"Eval {task_name}", leave=False):
        inputs = {
            k: v.to(args.device) for k, v in batch.items()
            if isinstance(v, torch.Tensor)
            and k not in {'original_indices', 'teacher_path_scores', 'teacher_available'}
        }
        inputs["return_embedding"] = False
        inputs["return_path_weights"] = bool(error_analysis)
        inputs["return_global_embedding"] = False
        batch_indices = batch.get('original_indices', [])

        with torch.no_grad():
            with amp.autocast(enabled=args.fp16):
                out = m(**inputs)
                if error_analysis:
                    logits, batch_path_weights = out
                else:
                    logits = out[0] if isinstance(out, tuple) else out
                    batch_path_weights = None
                labels = inputs["vuln_labels"]
                valid_mask = (labels >= 0)
                if valid_mask.sum() == 0:
                    continue
                criterion = getattr(args, "criterion", None)
                loss = (criterion(logits[valid_mask], labels[valid_mask]) if criterion is not None
                        else F.cross_entropy(logits[valid_mask], labels[valid_mask]))

        eval_loss_sum += float(loss.item())
        eval_steps += 1

        probs = torch.softmax(logits.float() / float(temperature), dim=-1)
        prob_1 = probs[:, 1].detach().cpu().numpy()
        labels_np = labels.detach().cpu().numpy()
        valid_np = valid_mask.detach().cpu().numpy()

        for j in range(len(labels_np)):
            if valid_np[j]:
                all_probs.append(float(prob_1[j]))
                all_labels.append(int(labels_np[j]))
                all_indices.append(batch_indices[j] if batch_indices else -1)
                if error_analysis and batch_path_weights is not None:
                    all_path_weights.append(batch_path_weights[j].detach().float().cpu().tolist())

    stage = stage_label or ("TEST" if is_test else "VALID")

    if not all_labels:
        logger.warning(f"[{task_name}] 无有效样本")
        return {"loss": 0.0, "acc": 0.0, "precision": 0.0, "recall": 0.0, "f1": 0.0,
                "mcc": 0.0, "auc": 0.0, "pr_auc": 0.0, "bacc": 0.0, "vds": 100.0,
                "threshold": 0.5, "tp": 0, "fp": 0, "tn": 0, "fn": 0, "total": 0,
                "_ids": [], "_labels": [], "_probs": [], "_indices": []}

    avg_loss = eval_loss_sum / max(eval_steps, 1)

    if forced_threshold is not None:
        best_threshold = float(forced_threshold)
        thresh_src = "forced"
        logger.info(f"[{task_name}][{stage}] forced_threshold={best_threshold:.4f}")
    else:
        metric_for_thresh = (search_metric or getattr(args, "threshold_metric", "mcc")).lower()
        t_min = float(getattr(args, "threshold_search_min", 0.05))
        t_max = float(getattr(args, "threshold_search_max", 0.95))
        t_step = float(getattr(args, "threshold_search_step", 0.01))
        best_threshold, best_score = search_best_threshold(
            all_labels, all_probs, metric=metric_for_thresh,
            t_min=t_min, t_max=t_max, t_step=t_step
        )
        thresh_src = f"searched-by-{metric_for_thresh}"
        logger.info(f"[{task_name}][{stage}] threshold by {metric_for_thresh.upper()} = "
                    f"{best_threshold:.4f}, best_score={best_score:.4f}")

    final_preds = [1 if p >= best_threshold else 0 for p in all_probs]

    acc = accuracy_score(all_labels, final_preds)
    prec = precision_score(all_labels, final_preds, zero_division=0)
    rec = recall_score(all_labels, final_preds, zero_division=0)
    f1 = f1_score(all_labels, final_preds, zero_division=0)
    mcc = matthews_corrcoef(all_labels, final_preds)
    bacc = compute_bacc(all_labels, final_preds)
    try:
        auc = roc_auc_score(all_labels, all_probs)
    except ValueError:
        auc = 0.0
    try:
        pr_auc = average_precision_score(all_labels, all_probs)
    except ValueError:
        pr_auc = 0.0
    vds = compute_vds(all_labels, all_probs, target_fpr=0.0005)
    tn, fp, fn, tp = confusion_matrix(all_labels, final_preds, labels=[0, 1]).ravel()

    example_ids = []
    for i in all_indices:
        try:
            example_ids.append(str(base_ds.examples[i].idx))
        except Exception:
            example_ids.append(None)

    results = {
        "loss": avg_loss, "acc": acc, "precision": prec, "recall": rec, "f1": f1,
        "mcc": mcc, "auc": auc, "pr_auc": pr_auc, "bacc": bacc, "vds": vds,
        "threshold": float(best_threshold), "threshold_source": thresh_src,
        "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn),
        "total": len(all_labels),
        "_ids": example_ids, "_labels": all_labels, "_probs": all_probs, "_indices": all_indices,
    }

    logger.info(
        f"[{task_name}][{stage}] loss={avg_loss:.4f} acc={acc:.4f} P={prec:.4f} R={rec:.4f} "
        f"F1={f1:.4f} MCC={mcc:.4f} AUC={auc:.4f} PR-AUC={pr_auc:.4f} BAcc={bacc:.4f} "
        f"VD-S={vds:.2f} thresh={best_threshold:.4f}({thresh_src})"
    )
    logger.info(f"[{task_name}][{stage}] TP={tp} FP={fp} TN={tn} FN={fn}")

    if save_preds_path:
        with open(save_preds_path, "w", encoding="utf-8") as f:
            f.write("idx\ttrue\tpred\tprob1\n")
            for eid, t, p, prob in zip(example_ids, all_labels, final_preds, all_probs):
                f.write(f"{eid}\t{t}\t{p}\t{prob:.6f}\n")

    if error_analysis and all_indices:
        save_error_analysis(args, eval_dataloader, all_indices, all_labels,
                            final_preds, all_probs, task_name,
                            path_weight_rows=all_path_weights)

    return results


def report_pair_metrics(args, eval_res, meta, threshold, tag):
    res, detailed = pair_metrics_from_scores(
        eval_res["_ids"], eval_res["_labels"], eval_res["_probs"], meta, threshold
    )
    logger.info(
        f"[PrimeVul-Pair:{tag}] n={res['pairs']} P-C={res['P-C']:.4f} P-V={res['P-V']:.4f} "
        f"P-B={res['P-B']:.4f} P-R={res['P-R']:.4f} PairAcc={res['PairAcc']:.4f} "
        f"threshold={threshold:.4f}"
    )
    dump_json({"threshold": float(threshold), **res},
              os.path.join(args.output_dir, f"primevul_pair_{tag}.json"))
    with open(os.path.join(args.output_dir, f"primevul_pair_{tag}_details.jsonl"),
              "w", encoding="utf-8") as f:
        for row in detailed:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    return res


# =========================
# Checkpoint
# =========================
def save_checkpoint(args, model, optimizer, scheduler, scaler, epoch, global_step,
                    best_metric_val, epochs_no_improve, is_best=False):
    model_to_save = model.module if hasattr(model, 'module') else model

    if is_best:
        best_dir = os.path.join(args.output_dir, 'checkpoint-best')
        safe_makedirs(best_dir)
        torch.save(model_to_save.state_dict(), os.path.join(best_dir, 'model.bin'))
        model_to_save.config.save_pretrained(best_dir)
        if hasattr(args, 'tokenizer'):
            args.tokenizer.save_pretrained(best_dir)

        light_args = {k: (v if isinstance(v, (int, float, str, bool, type(None))) else str(type(v)))
                      for k, v in vars(args).items()}
        dump_json(light_args, os.path.join(best_dir, 'training_args_light.json'))
        dump_json({
            'best_threshold': float(getattr(args, 'best_threshold', 0.5)),
            'best_metric_val': float(best_metric_val),
            'epoch': int(epoch), 'global_step': int(global_step),
            'metric_name': args.metric_for_best_model,
        }, os.path.join(best_dir, 'best_params.json'))

        logger.info(f"[CKPT] 最佳模型保存到: {best_dir}")

    latest_dir = os.path.join(args.output_dir, 'checkpoint-latest')
    safe_makedirs(latest_dir)
    ckpt = {
        'epoch': epoch, 'global_step': global_step,
        'model_state_dict': model_to_save.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict(),
        'best_metric_val': best_metric_val,
        'epochs_no_improve': epochs_no_improve,
    }
    if args.fp16:
        ckpt['scaler_state_dict'] = scaler.state_dict()
    torch.save(ckpt, os.path.join(latest_dir, 'checkpoint.bin'))


# =========================
# Train
# =========================
def train(args, model, tokenizer, train_dataloader, eval_dataloader=None, valid_meta=None):
    """Strict training: pair ids affect losses only, never the forward representation."""
    steps_per_epoch = max(
        1,
        (len(train_dataloader) + args.gradient_accumulation_steps - 1)
        // args.gradient_accumulation_steps,
    )
    t_total = steps_per_epoch * int(args.num_train_epochs)

    no_decay = ["bias", "LayerNorm.weight", "layer_norm.weight"]
    base_model = model.module if hasattr(model, "module") else model
    # Group on the unwrapped module; DataParallel prefixes names with "module."
    # and would otherwise accidentally put the encoder into the head-LR group.
    named_params = [(n, p) for n, p in base_model.named_parameters() if p.requires_grad]
    encoder_named = [(n, p) for n, p in named_params if n.startswith("encoder.")]
    head_named = [(n, p) for n, p in named_params if not n.startswith("encoder.")]
    if not encoder_named:
        raise RuntimeError("Encoder parameter group is empty; refusing to train with wrong LR grouping")

    grouped = []
    for named, lr in [
        (encoder_named, float(args.encoder_learning_rate)),
        (head_named, float(args.head_learning_rate)),
    ]:
        grouped.append({
            "params": [p for n, p in named if not any(nd in n for nd in no_decay)],
            "weight_decay": args.weight_decay,
            "lr": lr,
        })
        grouped.append({
            "params": [p for n, p in named if any(nd in n for nd in no_decay)],
            "weight_decay": 0.0,
            "lr": lr,
        })

    optimizer = AdamW(grouped, eps=args.adam_epsilon)
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=int(t_total * args.warmup_ratio),
        num_training_steps=t_total,
    )
    scaler = amp.GradScaler(enabled=args.fp16)

    global_cons_w = float(getattr(args, "pair_global_consistency_weight", 0.02))
    logger.info("***** Start training (FlowFuse v7.4 PMCL+DIVERSE) *****")
    logger.info(
        f"samples={len(train_dataloader.dataset)} batches/epoch={len(train_dataloader)} "
        f"steps/epoch={steps_per_epoch}"
    )
    logger.info(
        f"encoder_lr={args.encoder_learning_rate:.2e} "
        f"head_lr={args.head_learning_rate:.2e} "
        f"rank_peak={args.pair_rank_weight} rank_start={args.pair_rank_start_weight} "
        f"localization={args.localization_weight} global_consistency={global_cons_w}"
    )

    start_epoch, global_step = 0, 0
    best_metric_val, best_epoch, best_threshold = -1e9, -1, 0.5
    epochs_no_improve = 0

    resume_path = getattr(args, "resume_from_checkpoint", "")
    if resume_path:
        ckpt_file = (
            os.path.join(resume_path, "checkpoint.bin")
            if os.path.isdir(resume_path) else resume_path
        )
        if os.path.exists(ckpt_file):
            ckpt = torch.load(ckpt_file, map_location=args.device)
            (model.module if hasattr(model, "module") else model).load_state_dict(
                ckpt["model_state_dict"], strict=True
            )
            optimizer.load_state_dict(ckpt["optimizer_state_dict"])
            scheduler.load_state_dict(ckpt["scheduler_state_dict"])
            if args.fp16 and "scaler_state_dict" in ckpt:
                scaler.load_state_dict(ckpt["scaler_state_dict"])
            start_epoch = int(ckpt.get("epoch", -1)) + 1
            global_step = int(ckpt.get("global_step", 0))
            best_metric_val = float(ckpt.get("best_metric_val", -1e9))
            epochs_no_improve = int(ckpt.get("epochs_no_improve", 0))

    model.zero_grad()

    def pick_metric(res, name, pair_res=None, best_pc=None):
        name = (name or "hybrid").lower()
        if name == "pairacc":
            return float(pair_res.get("PairAcc", -1e9)) if pair_res else -1e9
        if name == "pc":
            return float(best_pc if best_pc is not None else -1e9)
        if name == "hybrid":
            pa = float(pair_res.get("PairAcc", 0.0)) if pair_res else 0.0
            return 0.60 * float(res.get("auc", 0.0)) + 0.40 * pa
        if name in ("mcc", "f1", "recall", "precision", "acc", "auc", "pr_auc", "bacc"):
            return float(res.get(name, -1e9))
        return float(res.get("auc", -1e9))

    for epoch in trange(start_epoch, int(args.num_train_epochs), desc="Epoch"):
        model.train()
        if hasattr(train_dataloader.batch_sampler, "set_epoch"):
            train_dataloader.batch_sampler.set_epoch(epoch)

        rank_w = active_pair_rank_weight(args, epoch)
        loc_w = active_localization_weight(args, epoch)
        logger.info(
            f"Epoch {epoch}: active_pair_rank_weight={rank_w:.5f} "
            f"active_localization_weight={loc_w:.5f}"
        )

        sums = defaultdict(float)
        epoch_steps = pair_count = 0
        pair_order_sum = pair_gap_sum = 0.0
        epoch_iter = tqdm(train_dataloader, desc="Iter", leave=False)

        for step, batch in enumerate(epoch_iter):
            tensor_inputs = {
                k: v.to(args.device)
                for k, v in batch.items()
                if isinstance(v, torch.Tensor) and k != 'original_indices'
            }
            teacher_scores = tensor_inputs.pop('teacher_path_scores', None)
            tensor_inputs.pop('teacher_available', None)
            pair_ids = batch.get('pair_ids', [None] * tensor_inputs['vuln_labels'].size(0))

            with amp.autocast(enabled=args.fp16):
                model_inputs = dict(tensor_inputs)
                model_inputs['return_embedding'] = True
                model_inputs['return_path_weights'] = True
                model_inputs['return_global_embedding'] = True
                logits, emb, path_weights, global_emb = model(**model_inputs)

                labels = tensor_inputs['vuln_labels']
                valid = labels >= 0
                if valid.sum() == 0:
                    continue

                ce_loss = args.criterion(logits[valid], labels[valid])
                rank_loss, global_cons_loss, n_pairs, mean_gap, order_acc = compute_pair_losses(
                    logits, global_emb, pair_ids, labels,
                    margin=args.pair_margin,
                    rank_temperature=args.pair_rank_temperature,
                )
                loc_loss = compute_localization_loss(
                    path_weights, teacher_scores, tensor_inputs['path_mask']
                )
                pair_count += n_pairs
                pair_gap_sum += mean_gap * n_pairs
                pair_order_sum += order_acc * n_pairs
                loss = (
                    ce_loss
                    + rank_w * rank_loss
                    + loc_w * loc_loss
                    + global_cons_w * global_cons_loss
                )

            scaler.scale(loss / max(1, args.gradient_accumulation_steps)).backward()

            sums['loss'] += float(loss.item())
            sums['ce'] += float(ce_loss.item())
            sums['rank'] += float(rank_loss.item())
            sums['loc'] += float(loc_loss.item())
            sums['global_cons'] += float(global_cons_loss.item())
            epoch_steps += 1

            epoch_iter.set_postfix({
                'ce': f"{ce_loss.item():.3f}",
                'rank': f"{rank_loss.item():.3f}",
                'loc': f"{loc_loss.item():.3f}",
                'gap': f"{mean_gap:.2f}",
            })

            if (step + 1) % args.gradient_accumulation_steps == 0:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
                old_scale = scaler.get_scale()
                scaler.step(optimizer)
                scaler.update()
                if scaler.get_scale() >= old_scale:
                    scheduler.step()
                model.zero_grad()
                global_step += 1

        if len(train_dataloader) % args.gradient_accumulation_steps != 0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
            old_scale = scaler.get_scale()
            scaler.step(optimizer)
            scaler.update()
            if scaler.get_scale() >= old_scale:
                scheduler.step()
            model.zero_grad()
            global_step += 1

        n = max(epoch_steps, 1)
        logger.info(
            f"Epoch {epoch}: loss={sums['loss']/n:.4f} ce={sums['ce']/n:.4f} "
            f"rank={sums['rank']/n:.4f} loc={sums['loc']/n:.4f} "
            f"global_cons={sums['global_cons']/n:.4f} "
            f"pairs={pair_count} pair_order={pair_order_sum/max(pair_count,1):.4f} "
            f"pair_gap={pair_gap_sum/max(pair_count,1):.4f}"
        )

        if eval_dataloader is None:
            save_checkpoint(
                args, model, optimizer, scheduler, scaler, epoch, global_step,
                best_metric_val, epochs_no_improve, is_best=False
            )
            continue

        # Training fits on the GPU, but the validation loader can have a much
        # larger effective B x paths. Release cached allocator blocks before
        # entering the no-grad validation forward.
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        eval_res = evaluate(
            args, model, eval_dataloader, is_test=False,
            task_name=f"valid_epoch_{epoch}", search_metric=args.threshold_metric
        )
        cur_threshold = float(eval_res.get("threshold", 0.5))

        pair_res = None
        best_pc = best_pc_t = None
        if valid_meta:
            pair_res, _ = pair_metrics_from_scores(
                eval_res["_ids"], eval_res["_labels"], eval_res["_probs"],
                valid_meta, cur_threshold
            )
            best_pc_t, best_pc, _ = search_best_pair_threshold(
                eval_res["_ids"], eval_res["_labels"], eval_res["_probs"], valid_meta,
                t_min=args.threshold_search_min,
                t_max=args.threshold_search_max,
                t_step=args.threshold_search_step,
            )
            logger.info(
                f"Epoch {epoch} valid-pair: n={pair_res['pairs']} "
                f"PairAcc={pair_res['PairAcc']:.4f} "
                f"P-C@{cur_threshold:.3f}={pair_res['P-C']:.4f} "
                f"bestP-C={best_pc:.4f}@{best_pc_t:.3f}"
            )

        current_metric = pick_metric(
            eval_res, args.metric_for_best_model, pair_res=pair_res, best_pc=best_pc
        )
        logger.info(
            f"Epoch {epoch} picked_metric({args.metric_for_best_model})={current_metric:.6f}"
        )

        if current_metric > best_metric_val:
            best_metric_val = current_metric
            best_epoch = epoch
            best_threshold = cur_threshold
            args.best_threshold = best_threshold
            epochs_no_improve = 0
            save_checkpoint(
                args, model, optimizer, scheduler, scaler, epoch, global_step,
                best_metric_val, epochs_no_improve, is_best=True
            )
            logger.info(
                f"new best: metric={best_metric_val:.6f}, "
                f"epoch={best_epoch}, threshold={best_threshold:.4f}"
            )
        else:
            epochs_no_improve += 1
            logger.info(
                f"no improvement: {epochs_no_improve}/{args.early_stopping_patience}"
            )

        save_checkpoint(
            args, model, optimizer, scheduler, scaler, epoch, global_step,
            best_metric_val, epochs_no_improve, is_best=False
        )
        if epochs_no_improve >= args.early_stopping_patience:
            logger.info("Early stopping.")
            break

    logger.info(
        f"Training done: best_epoch={best_epoch}, "
        f"best_{args.metric_for_best_model}={best_metric_val:.6f}"
    )
    return {
        "global_step": global_step,
        "best_epoch": best_epoch,
        "best_metric_val": best_metric_val,
        "best_threshold": best_threshold,
        "temperature": 1.0,
    }


# =========================
# Results
# =========================
def save_results_bundle(output_dir, all_results):
    safe_makedirs(output_dir)
    clean = [_strip_private(r) for r in all_results]
    json_path = os.path.join(output_dir, "test_results_all.json")
    csv_path = os.path.join(output_dir, "test_results_all.csv")
    summary_path = os.path.join(output_dir, "test_summary.json")

    dump_json(clean, json_path)
    keys = ["task", "f1", "pr_auc", "mcc", "bacc", "vds", "auc",
            "precision", "recall", "acc", "threshold", "threshold_source",
            "tp", "fp", "tn", "fn", "total"]
    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in clean:
            w.writerow({k: r.get(k, "") for k in keys})

    dump_json({"time": time.strftime("%Y-%m-%d %H:%M:%S"),
               "num_tasks": len(clean), "results": clean}, summary_path)
    logger.info(f"结果已保存: {json_path} / {csv_path} / {summary_path}")


RESULT_HEADER = "{:<22} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8}".format(
    "Task", "F1", "AUPRC", "MCC", "BAcc", "VD-S", "AUC", "P", "R", "Thresh"
)


def _result_row(r):
    return "{:<22} {:<8.2f} {:<8.2f} {:<8.2f} {:<8.2f} {:<8.2f} {:<8.4f} {:<8.4f} {:<8.4f} {:<8.4f}".format(
        r.get('task', 'N/A'), r.get('f1', 0.0) * 100, r.get('pr_auc', 0.0) * 100,
        r.get('mcc', 0.0) * 100, r.get('bacc', 0.0) * 100, r.get('vds', 100.0),
        r.get('auc', 0.0), r.get('precision', 0.0), r.get('recall', 0.0), r.get('threshold', 0.5),
    )


# =========================
# Main
# =========================
def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--output_dir", required=True, type=str)
    parser.add_argument("--data_dir", required=True, type=str)
    parser.add_argument("--pkl_dir", required=True, type=str)
    parser.add_argument("--model_name_or_path", required=True, type=str)
    parser.add_argument("--train_file_name", default="train_synced.jsonl")
    parser.add_argument("--valid_file_name", default="valid_synced.jsonl")
    parser.add_argument("--test_file_name", default="test_synced.jsonl")
    parser.add_argument("--pkl_file_name_train", default="dataflow_primevul_train.pkl")
    parser.add_argument("--pkl_file_name_valid", default="dataflow_primevul_valid.pkl")
    parser.add_argument("--pkl_file_name_test", default="dataflow_primevul_test.pkl")

    parser.add_argument("--do_train", action="store_true")
    parser.add_argument("--do_eval", action="store_true")
    parser.add_argument("--do_test", action="store_true")
    parser.add_argument("--use_cache", action="store_true")
    parser.add_argument("--fp16", action="store_true")
    parser.add_argument("--balance_test_set", action="store_true")
    parser.add_argument("--enable_gradient_checkpointing", action="store_true")
    parser.add_argument("--resume_from_checkpoint", type=str, default="")

    parser.add_argument("--model_type", default="unixcoder")
    parser.add_argument("--block_size", default=860, type=int)
    parser.add_argument("--max_paths", default=12, type=int)
    parser.add_argument("--max_paths_main", default=8, type=int)
    parser.add_argument("--max_global_lines", default=140, type=int)
    parser.add_argument("--use_global_branch", action="store_true")
    parser.add_argument("--proj_dim", default=128, type=int)
    parser.add_argument("--head_dropout", default=0.18, type=float)
    parser.add_argument("--fusion_dropout", default=0.15, type=float)
    parser.add_argument("--path_rep_dropout", default=0.10, type=float)
    parser.add_argument("--context_score_scale", default=0.50, type=float)
    parser.add_argument("--path_diversity_lambda", default=0.35, type=float)

    parser.add_argument("--pairs_per_batch", default=2, type=int)
    parser.add_argument("--keep_unpaired", action="store_true")
    parser.add_argument("--pair_margin", default=0.30, type=float)
    parser.add_argument("--pair_rank_temperature", default=1.0, type=float)
    parser.add_argument("--pair_rank_weight", default=0.10, type=float)
    parser.add_argument("--pair_rank_start_weight", default=0.05, type=float)
    parser.add_argument("--pair_rank_peak_until_epoch", default=2, type=int)
    parser.add_argument("--pair_rank_decay", default=0.75, type=float)
    parser.add_argument("--pair_rank_min_weight", default=0.02, type=float)
    parser.add_argument("--pair_close_weight", default=0.0, type=float, help="legacy; unused in v7.4")
    parser.add_argument("--pair_global_consistency_weight", default=0.02, type=float)
    parser.add_argument("--localization_weight", default=0.15, type=float)
    parser.add_argument("--localization_hold_until_epoch", default=3, type=int)
    parser.add_argument("--localization_decay", default=0.85, type=float)
    parser.add_argument("--localization_min_weight", default=0.05, type=float)

    parser.add_argument("--eval_batch_size", default=8, type=int)
    parser.add_argument(
        "--eval_path_chunk_size", default=24, type=int,
        help="Max flattened path sequences per encoder call during validation/test; training is unchanged.",
    )
    parser.add_argument("--gradient_accumulation_steps", default=6, type=int)
    parser.add_argument("--encoder_learning_rate", default=6e-6, type=float)
    parser.add_argument("--head_learning_rate", default=2e-5, type=float)
    parser.add_argument("--weight_decay", default=0.01, type=float)
    parser.add_argument("--adam_epsilon", default=1e-8, type=float)
    parser.add_argument("--max_grad_norm", default=1.0, type=float)
    parser.add_argument("--num_train_epochs", default=12, type=int)
    parser.add_argument("--warmup_ratio", default=0.10, type=float)
    parser.add_argument("--path_dropout_rate", default=0.05, type=float)
    parser.add_argument("--early_stopping_patience", default=4, type=int)
    parser.add_argument(
        "--metric_for_best_model", default="auc",
        choices=["hybrid", "pairacc", "pc", "mcc", "f1", "recall",
                 "precision", "acc", "auc", "pr_auc", "bacc"],
    )
    parser.add_argument("--use_class_weights", action="store_true")
    parser.add_argument("--class_weight_cap", default=8.0, type=float)
    parser.add_argument("--focal_gamma", default=0.0, type=float)
    parser.add_argument("--label_smoothing", default=0.01, type=float)
    parser.add_argument("--seed", default=42, type=int)

    parser.add_argument(
        "--threshold_metric", default="mcc",
        choices=["mcc", "f1", "precision", "recall"],
    )
    parser.add_argument("--threshold_search_min", type=float, default=0.05)
    parser.add_argument("--threshold_search_max", type=float, default=0.95)
    parser.add_argument("--threshold_search_step", type=float, default=0.005)

    parser.add_argument("--cache_dir_name", default="cached_features_v7_4_pmcl_diverse")
    parser.add_argument("--num_preprocessing_workers", default=8, type=int)
    parser.add_argument("--num_dataloader_workers", default=4, type=int)
    parser.add_argument("--preprocessing_chunksize", default=64, type=int)

    args = parser.parse_args()
    safe_makedirs(args.output_dir)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(
                os.path.join(args.output_dir, "run_log_v7_4_pmcl_diverse.log"),
                mode="w", encoding="utf-8"
            ),
            logging.StreamHandler(sys.stdout),
        ],
    )
    logger.info("=" * 20 + " FlowFuse v7.4 PMCL+DIVERSE GLOBAL+PATH " + "=" * 20)
    logger.info(f"args: {args}")

    args.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    args.n_gpu = torch.cuda.device_count()
    set_seed(args)

    try:
        config = MODEL_CLASSES[args.model_type][0].from_pretrained(args.model_name_or_path)
        tokenizer = MODEL_CLASSES[args.model_type][2].from_pretrained(args.model_name_or_path)
        tokenizer.add_special_tokens({
            "additional_special_tokens": [
                "[DANGER_OP]", "[POINTER_OP]", "[DEFENSE_OP]", "[DATA_FLOW]",
                "[DEFENSE_TO_DANGER]", "[UNGUARDED_DANGER]",
                "[ANCHOR_PATH]", "[CFG_PATH]"
            ]
        })
        encoder = MODEL_CLASSES[args.model_type][1].from_pretrained(
            args.model_name_or_path, config=config
        )
        encoder.resize_token_embeddings(len(tokenizer))

        logger.info(
            f"max_position_embeddings={config.max_position_embeddings}, "
            f"block_size={args.block_size}"
        )
        if args.block_size > int(getattr(config, "max_position_embeddings", 512)):
            raise ValueError(
                f"block_size={args.block_size} exceeds "
                f"max_position_embeddings={config.max_position_embeddings}"
            )

        if args.enable_gradient_checkpointing and hasattr(encoder, "gradient_checkpointing_enable"):
            encoder.gradient_checkpointing_enable()
            logger.info("Gradient checkpointing enabled.")

        model = Model(encoder, config, tokenizer, args).to(args.device)
        if args.n_gpu > 1:
            model = torch.nn.DataParallel(model)

        args.tokenizer = tokenizer
        cache_dir_base = os.path.join(args.output_dir, args.cache_dir_name)
        collate_eval = partial(
            collate_fn,
            pad_token_id=tokenizer.pad_token_id,
            max_paths_main=args.max_paths_main,
            path_dropout_rate=0.0,
        )

        train_jsonl = os.path.join(args.data_dir, args.train_file_name)
        valid_jsonl = os.path.join(args.data_dir, args.valid_file_name)
        test_jsonl = os.path.join(args.data_dir, args.test_file_name)

        if args.do_train:
            train_dataset = TextDataset(
                tokenizer, args, train_jsonl,
                os.path.join(args.pkl_dir, args.pkl_file_name_train),
                args.use_cache, os.path.join(cache_dir_base, "train"), "Train"
            )
            if not train_dataset.examples:
                raise RuntimeError("Training dataset is empty")

            counts = Counter(ex.label for ex in train_dataset.examples)
            n0, n1 = counts.get(0, 0), counts.get(1, 0)
            class_weights = None
            if args.use_class_weights and n0 > 0 and n1 > 0:
                total = n0 + n1
                w0 = max(total / (2.0 * n0), 0.5)
                w1 = min(total / (2.0 * n1), float(args.class_weight_cap))
                class_weights = torch.tensor(
                    [w0, w1], dtype=torch.float, device=args.device
                )
            args.criterion = FocalLoss(
                weight=class_weights,
                gamma=args.focal_gamma,
                label_smoothing=args.label_smoothing,
            )
            logger.info(f"Train label dist: {counts}, class_weights={class_weights}")

            train_sampler = PairBatchSampler(
                train_dataset.examples,
                pairs_per_batch=args.pairs_per_batch,
                shuffle=True, seed=args.seed,
                drop_unpaired=not args.keep_unpaired,
            )
            if train_sampler.num_pairs == 0:
                raise RuntimeError("No complete training pairs found")
            logger.info(
                f"[PAIR] complete pairs={train_sampler.num_pairs}, "
                f"batches/epoch={len(train_sampler)}"
            )

            collate_train = partial(
                collate_fn,
                pad_token_id=tokenizer.pad_token_id,
                max_paths_main=args.max_paths_main,
                path_dropout_rate=args.path_dropout_rate,
            )
            train_loader = DataLoader(
                train_dataset, batch_sampler=train_sampler,
                collate_fn=collate_train,
                num_workers=args.num_dataloader_workers, pin_memory=True
            )

            eval_loader = None
            valid_meta = None
            if args.do_eval:
                valid_dataset = TextDataset(
                    tokenizer, args, valid_jsonl,
                    os.path.join(args.pkl_dir, args.pkl_file_name_valid),
                    args.use_cache, os.path.join(cache_dir_base, "valid"), "Valid"
                )
                if valid_dataset.examples:
                    eval_loader = DataLoader(
                        valid_dataset,
                        sampler=SequentialSampler(valid_dataset),
                        batch_size=args.eval_batch_size,
                        collate_fn=collate_eval,
                        num_workers=args.num_dataloader_workers,
                        pin_memory=True,
                    )
                    valid_meta = load_primevul_pair_meta(valid_jsonl)

            train(
                args, model, tokenizer, train_loader,
                eval_dataloader=eval_loader, valid_meta=valid_meta
            )

        if args.do_test:
            best_dir = os.path.join(args.output_dir, "checkpoint-best")
            best_model_path = os.path.join(best_dir, "model.bin")
            if not os.path.exists(best_model_path):
                raise FileNotFoundError(f"Best model not found: {best_model_path}")

            model_to_load = model.module if hasattr(model, "module") else model
            model_to_load.load_state_dict(
                torch.load(best_model_path, map_location=args.device), strict=True
            )
            logger.info(f"Loaded best model: {best_model_path}")

            if not hasattr(args, "criterion") or args.criterion is None:
                args.criterion = FocalLoss(
                    gamma=args.focal_gamma,
                    label_smoothing=args.label_smoothing,
                )

            valid_dataset = TextDataset(
                tokenizer, args, valid_jsonl,
                os.path.join(args.pkl_dir, args.pkl_file_name_valid),
                args.use_cache, os.path.join(cache_dir_base, "valid"), "ValidForThreshold"
            )
            valid_loader = DataLoader(
                valid_dataset, sampler=SequentialSampler(valid_dataset),
                batch_size=args.eval_batch_size,
                collate_fn=collate_eval,
                num_workers=args.num_dataloader_workers
            )
            valid_meta = load_primevul_pair_meta(valid_jsonl)

            valid_res = evaluate(
                args, model, valid_loader, is_test=False,
                task_name="valid_scores", temperature=1.0,
                search_metric=args.threshold_metric
            )
            valid_thresh_mcc, _ = search_best_threshold(
                valid_res["_labels"], valid_res["_probs"], metric="mcc",
                t_min=args.threshold_search_min,
                t_max=args.threshold_search_max,
                t_step=args.threshold_search_step
            )
            valid_thresh_f1, _ = search_best_threshold(
                valid_res["_labels"], valid_res["_probs"], metric="f1",
                t_min=args.threshold_search_min,
                t_max=args.threshold_search_max,
                t_step=args.threshold_search_step
            )
            valid_thresh_pc, valid_best_pc, _ = search_best_pair_threshold(
                valid_res["_ids"], valid_res["_labels"], valid_res["_probs"], valid_meta,
                t_min=args.threshold_search_min,
                t_max=args.threshold_search_max,
                t_step=args.threshold_search_step
            )
            logger.info(
                f"[THRESH] valid MCC={valid_thresh_mcc:.4f}, "
                f"F1={valid_thresh_f1:.4f}, "
                f"P-C={valid_thresh_pc:.4f} (best P-C={valid_best_pc:.4f})"
            )

            test_dataset = TextDataset(
                tokenizer, args, test_jsonl,
                os.path.join(args.pkl_dir, args.pkl_file_name_test),
                args.use_cache, os.path.join(cache_dir_base, "test"), "Test"
            )
            test_loader = DataLoader(
                test_dataset, sampler=SequentialSampler(test_dataset),
                batch_size=args.eval_batch_size,
                collate_fn=collate_eval,
                num_workers=args.num_dataloader_workers
            )
            test_meta = load_primevul_pair_meta(test_jsonl)

            base = evaluate(
                args, model, test_loader, is_test=True,
                task_name="Std(valid-MCC)", error_analysis=True,
                save_preds_path=os.path.join(args.output_dir, "predictions_test.txt"),
                forced_threshold=valid_thresh_mcc, temperature=1.0
            )

            def recompute(res, thr, task):
                preds = [1 if p >= thr else 0 for p in res["_probs"]]
                y = res["_labels"]
                tn, fp, fn, tp = confusion_matrix(y, preds, labels=[0, 1]).ravel()
                out = dict(res)
                out.update({
                    "task": task,
                    "acc": accuracy_score(y, preds),
                    "precision": precision_score(y, preds, zero_division=0),
                    "recall": recall_score(y, preds, zero_division=0),
                    "f1": f1_score(y, preds, zero_division=0),
                    "mcc": matthews_corrcoef(y, preds),
                    "bacc": compute_bacc(y, preds),
                    "threshold": float(thr),
                    "threshold_source": "valid",
                    "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn),
                })
                return out

            all_results = [
                {"task": "Std(valid-MCC)", **base},
                recompute(base, 0.5, "Std(fixed-0.5)"),
                recompute(base, valid_thresh_f1, "Std(valid-F1)"),
                recompute(base, valid_thresh_pc, "Std(valid-PC)"),
            ]

            for thr, tag in [
                (0.5, "strict_t05"),
                (valid_thresh_mcc, "strict_valid_mcc"),
                (valid_thresh_f1, "strict_valid_f1"),
                (valid_thresh_pc, "strict_valid_pc"),
            ]:
                report_pair_metrics(args, base, test_meta, thr, tag)

            logger.info("\n" + "=" * 120)
            logger.info("Final Test Results — v7.4 PMCL+DIVERSE (single-function inference, pair-supervised train)")
            logger.info("=" * 120)
            logger.info(RESULT_HEADER)
            logger.info("-" * 120)
            for r in all_results:
                logger.info(_result_row(r))
            logger.info("=" * 120)
            save_results_bundle(args.output_dir, all_results)

    except Exception as e:
        logger.error(f"Fatal error: {e}")
        logger.error(traceback.format_exc())
        save_fatal_error(args.output_dir, "main", e)
        raise


if __name__ == "__main__":
    if sys.platform.startswith('linux') and multiprocessing.get_start_method(allow_none=True) != 'spawn':
        try:
            multiprocessing.set_start_method('spawn', force=True)
        except RuntimeError:
            pass
    main()
