#!/usr/bin/env bash
set -euo pipefail
ROOT="${FLOWFUSE_ROOT:-<ARTIFACT_ROOT>}"
LOG="$ROOT/output/run_v74_megavul_zeroshot_FINAL/TEST_ZEROSHOT.log"
[[ -f "$LOG" ]] || { echo "[FATAL] missing $LOG"; exit 2; }
echo "===== MODEL ====="
sha256sum "$ROOT/output/run_unixcoder_v7_4_pmcl_diverse/checkpoint-best/model.bin"
echo "===== IMPORTANT LINES ====="
grep -E 'ValidForThreshold.*完成|Test.*完成|Loaded best model|\[THRESH\]|forced_threshold|\[Std\(valid-MCC\)\]\[TEST\]|P-C=|P-V=|P-B=|P-R=|PairAcc=|Final Test Results' "$LOG" | tail -100
