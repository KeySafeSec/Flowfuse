#!/usr/bin/env bash
set -euo pipefail
H="$(cd "$(dirname "$0")" && pwd)"
bash "$H/00_BUILD_MEGAVUL_V74_TESTONLY.sh"
bash "$H/01_RUN_MEGAVUL_V74_ZEROSHOT.sh"
bash "$H/02_CHECK_MEGAVUL_ZEROSHOT.sh"
