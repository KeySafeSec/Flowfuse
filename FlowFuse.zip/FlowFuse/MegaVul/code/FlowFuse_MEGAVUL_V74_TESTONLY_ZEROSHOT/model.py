# -*- coding: utf-8 -*-
"""FlowFuse v7.4 PMCL+DIVERSE model.

Architecture
------------
1) Current-function CFG/anchor path encoder with semantic marker injection.
2) Inter-path self-attention.
3) Global-conditioned path attention (the attention is train-supervised by
   vulnerable/fixed minimal-change locations, but counterpart data never enters
   this forward pass).
4) Global + path gated fusion.
5) Separate normalized projections for pair ranking / global consistency.

The pretrained UniXcoder encoder is never reinitialized by this wrapper.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers.modeling_utils import PreTrainedModel
from transformers import RobertaConfig


_FORBIDDEN_KEYS = (
    "patch_path_ids", "patch_path_attention_mask", "patch_path_mask",
    "patch_danger_mask", "patch_pointer_mask", "patch_defense_mask", "patch_data_mask",
    "counterpart_ids", "counterpart_mask", "pair_path_ids", "func_patch",
)


class Model(PreTrainedModel):
    config_class = RobertaConfig
    base_model_prefix = "encoder"

    def __init__(self, encoder, config, tokenizer, args):
        super().__init__(config)
        self.encoder = encoder
        self.config = config
        self.args = args
        self.hidden_size = int(config.hidden_size)
        self.use_global_branch = bool(getattr(args, "use_global_branch", True))

        token_names = [
            "[DANGER_OP]", "[POINTER_OP]", "[DEFENSE_OP]", "[DATA_FLOW]",
            "[DEFENSE_TO_DANGER]", "[UNGUARDED_DANGER]",
            "[ANCHOR_PATH]", "[CFG_PATH]",
        ]
        self.token_ids = {name: tokenizer.convert_tokens_to_ids(name) for name in token_names}

        init_std = float(getattr(config, "initializer_range", 0.02))
        # Extra semantic offsets complement (not replace) normal token embeddings.
        self.semantic_offsets = nn.ParameterDict({
            "danger": nn.Parameter(torch.randn(self.hidden_size) * init_std),
            "pointer": nn.Parameter(torch.randn(self.hidden_size) * init_std),
            "defense": nn.Parameter(torch.randn(self.hidden_size) * init_std),
            "data": nn.Parameter(torch.randn(self.hidden_size) * init_std),
            "def2danger": nn.Parameter(torch.randn(self.hidden_size) * init_std),
            "unguarded": nn.Parameter(torch.randn(self.hidden_size) * init_std),
            "anchor": nn.Parameter(torch.randn(self.hidden_size) * init_std),
            "cfg": nn.Parameter(torch.randn(self.hidden_size) * init_std),
        })

        n_heads = max(1, min(int(getattr(config, "num_attention_heads", 8)), 8))
        while self.hidden_size % n_heads != 0 and n_heads > 1:
            n_heads -= 1

        self.path_attention = nn.MultiheadAttention(
            embed_dim=self.hidden_size,
            num_heads=n_heads,
            dropout=float(getattr(config, "attention_probs_dropout_prob", 0.1)),
            batch_first=True,
        )
        self.path_attention_norm = nn.LayerNorm(self.hidden_size)
        self.path_rep_dropout = nn.Dropout(float(getattr(args, "path_rep_dropout", 0.10)))

        pool_mid = max(64, self.hidden_size // 4)
        self.local_path_score = nn.Sequential(
            nn.Linear(self.hidden_size, pool_mid),
            nn.Tanh(),
            nn.Linear(pool_mid, 1),
        )
        self.path_context_key = nn.Linear(self.hidden_size, self.hidden_size, bias=False)
        self.global_context_query = nn.Linear(self.hidden_size, self.hidden_size, bias=False)
        self.context_score_scale = float(getattr(args, "context_score_scale", 0.50))
        # Evaluation/test can flatten B x paths into hundreds of long sequences.
        # Chunk only in no-grad mode so training semantics/gradients are unchanged.
        self.eval_path_chunk_size = max(1, int(getattr(args, "eval_path_chunk_size", 24)))

        self.global_norm = nn.LayerNorm(self.hidden_size)
        fusion_dropout = float(getattr(args, "fusion_dropout", 0.15))
        self.global_candidate = nn.Sequential(
            nn.Linear(self.hidden_size * 2, self.hidden_size),
            nn.GELU(),
            nn.Dropout(fusion_dropout),
        )
        self.global_gate = nn.Linear(self.hidden_size * 2, self.hidden_size)
        self.fusion_norm = nn.LayerNorm(self.hidden_size)

        head_dropout = float(getattr(args, "head_dropout", 0.18))
        self.head = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size),
            nn.GELU(),
            nn.Dropout(head_dropout),
            nn.LayerNorm(self.hidden_size),
        )
        self.classifier = nn.Linear(self.hidden_size, 2)

        proj_dim = int(getattr(args, "proj_dim", 128))
        self.fused_projector = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size),
            nn.GELU(),
            nn.Dropout(head_dropout),
            nn.Linear(self.hidden_size, proj_dim),
        )
        self.global_projector = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size),
            nn.GELU(),
            nn.Linear(self.hidden_size, proj_dim),
        )

        self._init_new_parameters(init_std)

    def _init_new_parameters(self, std):
        # Initialize FlowFuse-added modules only; never touch self.encoder.
        modules = [
            self.local_path_score, self.path_context_key, self.global_context_query,
            self.global_candidate, self.global_gate, self.head, self.classifier,
            self.fused_projector, self.global_projector,
        ]
        for root in modules:
            for m in root.modules():
                if isinstance(m, nn.Linear):
                    nn.init.normal_(m.weight, mean=0.0, std=std)
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)
                elif isinstance(m, nn.LayerNorm):
                    nn.init.ones_(m.weight)
                    nn.init.zeros_(m.bias)

    def _build_masks_from_ids(self, path_ids):
        def eq(tok):
            return (path_ids == self.token_ids[tok]).long()
        return {
            "danger": eq("[DANGER_OP]"),
            "pointer": eq("[POINTER_OP]"),
            "defense": eq("[DEFENSE_OP]"),
            "data": eq("[DATA_FLOW]"),
            "def2danger": eq("[DEFENSE_TO_DANGER]"),
            "unguarded": eq("[UNGUARDED_DANGER]"),
            "anchor": eq("[ANCHOR_PATH]"),
            "cfg": eq("[CFG_PATH]"),
        }

    def _encode_path_instances(
        self,
        path_ids,
        path_attention_mask,
        path_mask,
        danger_mask=None,
        pointer_mask=None,
        defense_mask=None,
        data_mask=None,
        def2danger_mask=None,
        unguarded_mask=None,
        anchor_mask=None,
        cfg_mask=None,
    ):
        if path_ids is None:
            raise ValueError("path_ids is required")
        B, T, L = path_ids.shape

        built = self._build_masks_from_ids(path_ids)
        masks = {
            "danger": danger_mask if danger_mask is not None else built["danger"],
            "pointer": pointer_mask if pointer_mask is not None else built["pointer"],
            "defense": defense_mask if defense_mask is not None else built["defense"],
            "data": data_mask if data_mask is not None else built["data"],
            "def2danger": def2danger_mask if def2danger_mask is not None else built["def2danger"],
            "unguarded": unguarded_mask if unguarded_mask is not None else built["unguarded"],
            "anchor": anchor_mask if anchor_mask is not None else built["anchor"],
            "cfg": cfg_mask if cfg_mask is not None else built["cfg"],
        }

        flat_ids = path_ids.reshape(B * T, L)
        flat_attn = path_attention_mask.reshape(B * T, L)
        flat_masks = {
            name: mask.reshape(B * T, L)
            for name, mask in masks.items()
        }

        # On a 24-GB RTX 4090, eval_batch_size=16 and T=12 means as many as
        # 192 sequences of length 860 enter RoBERTa at once. The attention
        # matrix alone can create a very large transient allocation. During
        # validation/test we therefore encode flattened path instances in
        # bounded chunks. Training is deliberately left unchanged.
        use_eval_chunking = (
            (not torch.is_grad_enabled())
            and self.eval_path_chunk_size > 0
            and flat_ids.size(0) > self.eval_path_chunk_size
        )

        if use_eval_chunking:
            cls_parts = []
            chunk = self.eval_path_chunk_size
            for start in range(0, flat_ids.size(0), chunk):
                end = min(start + chunk, flat_ids.size(0))
                ids_c = flat_ids[start:end]
                attn_c = flat_attn[start:end]
                word_emb = self.encoder.embeddings.word_embeddings(ids_c)

                for name, flat_mask in flat_masks.items():
                    offset = self.semantic_offsets[name]
                    word_emb = (
                        word_emb
                        + flat_mask[start:end].unsqueeze(-1).float() * offset
                    )

                out = self.encoder(inputs_embeds=word_emb, attention_mask=attn_c)
                cls_parts.append(out.last_hidden_state[:, 0, :])

            cls_flat = torch.cat(cls_parts, dim=0)
        else:
            word_emb = self.encoder.embeddings.word_embeddings(flat_ids)
            for name, flat_mask in flat_masks.items():
                offset = self.semantic_offsets[name]
                word_emb = word_emb + flat_mask.unsqueeze(-1).float() * offset

            out = self.encoder(inputs_embeds=word_emb, attention_mask=flat_attn)
            cls_flat = out.last_hidden_state[:, 0, :]

        cls_each = cls_flat.reshape(B, T, self.hidden_size)

        key_padding = (path_mask <= 0)
        all_pad = key_padding.all(dim=1)
        if all_pad.any():
            key_padding = key_padding.clone()
            key_padding[all_pad, 0] = False

        attn_out, _ = self.path_attention(
            cls_each, cls_each, cls_each, key_padding_mask=key_padding
        )
        path_rep = self.path_attention_norm(cls_each + attn_out)
        return self.path_rep_dropout(path_rep)

    def _encode_global(self, global_ids, global_attention_mask):
        out = self.encoder(input_ids=global_ids, attention_mask=global_attention_mask)
        return self.global_norm(out.last_hidden_state[:, 0, :])

    def _pool_paths(self, path_rep, path_mask, global_summary=None):
        scores = self.local_path_score(path_rep).squeeze(-1)
        if global_summary is not None:
            key = F.normalize(self.path_context_key(path_rep), dim=-1, eps=1e-8)
            query = F.normalize(self.global_context_query(global_summary), dim=-1, eps=1e-8)
            contextual = torch.sum(key * query.unsqueeze(1), dim=-1)
            scores = scores + self.context_score_scale * contextual

        valid = path_mask > 0
        scores = scores.masked_fill(~valid, -1e4)
        all_invalid = ~valid.any(dim=1)
        if all_invalid.any():
            scores = scores.clone()
            scores[all_invalid, 0] = 0.0
            valid = valid.clone()
            valid[all_invalid, 0] = True

        weights = F.softmax(scores, dim=-1)
        weights = weights * valid.float()
        weights = weights / weights.sum(dim=-1, keepdim=True).clamp(min=1e-9)
        summary = torch.sum(path_rep * weights.unsqueeze(-1), dim=1)
        return summary, weights

    def forward(
        self,
        path_ids=None,
        path_attention_mask=None,
        path_mask=None,
        danger_mask=None,
        pointer_mask=None,
        defense_mask=None,
        data_mask=None,
        def2danger_mask=None,
        unguarded_mask=None,
        anchor_mask=None,
        cfg_mask=None,
        global_ids=None,
        global_attention_mask=None,
        vuln_labels=None,
        return_embedding=False,
        return_path_weights=False,
        return_global_embedding=False,
        **kwargs,
    ):
        leaked = [k for k in _FORBIDDEN_KEYS if kwargs.get(k, None) is not None]
        if leaked:
            raise RuntimeError(
                "FlowFuse v7.4 forward received counterpart information: " + ", ".join(leaked)
            )

        path_rep = self._encode_path_instances(
            path_ids, path_attention_mask, path_mask,
            danger_mask, pointer_mask, defense_mask, data_mask,
            def2danger_mask, unguarded_mask, anchor_mask, cfg_mask,
        )

        global_summary = None
        if self.use_global_branch and global_ids is not None and global_attention_mask is not None:
            global_summary = self._encode_global(global_ids, global_attention_mask)

        path_summary, path_weights = self._pool_paths(path_rep, path_mask, global_summary)

        fused = path_summary
        if global_summary is not None:
            pg = torch.cat([path_summary, global_summary], dim=-1)
            candidate = self.global_candidate(pg)
            gate = torch.sigmoid(self.global_gate(pg))
            fused = self.fusion_norm(gate * path_summary + (1.0 - gate) * candidate)

        fused = self.head(fused)
        logits = self.classifier(fused)

        outputs = [logits]
        if return_embedding:
            outputs.append(F.normalize(self.fused_projector(fused), dim=-1, eps=1e-8))
        if return_path_weights:
            outputs.append(path_weights)
        if return_global_embedding:
            src = global_summary if global_summary is not None else path_summary
            outputs.append(F.normalize(self.global_projector(src), dim=-1, eps=1e-8))

        return logits if len(outputs) == 1 else tuple(outputs)
