# data_process_single.py
# FlowFuse v7.4 — PMCL + source-aware diversity pruning.
#
# Inference remains single-function: candidate CFG/anchor paths are built only
# from the current function.  For TRAIN only, vulnerable/fixed pairs are used
# after path generation to attach teacher attention scores.  The counterpart
# never changes candidate paths and valid/test PKLs never contain teacher data.

import sys
import json
import pickle
import logging
import time
import random
import os
import re
import statistics
import hashlib
import difflib
from collections import defaultdict
import networkx as nx
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp
from tqdm import tqdm

# parserTool lives one directory above code/ in the user project.
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_THIS_DIR)
for _p in (_PROJECT_ROOT, _THIS_DIR):
    if _p and _p not in sys.path:
        sys.path.insert(0, _p)

# --- 导入自定义模块 ---
try:
    import parserTool.parse as ps
    from c_cfg import C_CFG
    from parserTool.utils import remove_comments_and_docstrings
    from parserTool.parse import Lang
except ImportError as e:
    print(f"错误：无法导入必要模块。请确保 parserTool/c_cfg 可用。错误: {e}")
    sys.exit(1)

DATASET_BASE_DIR = os.environ.get(
    "FLOWFUSE_DATASET_BASE_DIR",
    "<ARTIFACT_ROOT>/data/primevul/data/primevul_final_datasets/paired/single_function",
)

OUTPUT_BASE_DIR = os.environ.get(
    "FLOWFUSE_OUTPUT_BASE_DIR",
    "<ARTIFACT_ROOT>/data/primevul/data/primevul_final_datasets/paired/single_function/processed_DataFlow_v7_4_pmcl_diverse",
)

DATASETS_CONFIG = [
    {"split": "train", "input": "train.jsonl", "output_pkl": "dataflow_primevul_train.pkl"},
    {"split": "valid", "input": "valid.jsonl", "output_pkl": "dataflow_primevul_valid.pkl"},
    {"split": "test",  "input": "test.jsonl",  "output_pkl": "dataflow_primevul_test.pkl"},
]

SAMPLE_RATIO = 1
MAX_WORKERS = int(os.environ.get("FLOWFUSE_MAX_WORKERS", "12"))
STRICT_MAX_PATHS = int(os.environ.get("FLOWFUSE_MAX_PATHS", "12"))
STRICT_RETRY_MAX_PATHS = int(os.environ.get("FLOWFUSE_RETRY_MAX_PATHS", "16"))
V73_MAX_ANCHOR_PATHS = int(os.environ.get("FLOWFUSE_MAX_ANCHOR_PATHS", "6"))
V73_ANCHOR_RADIUS = int(os.environ.get("FLOWFUSE_ANCHOR_RADIUS", "2"))
V73_TEACHER_MIN_JACCARD = float(os.environ.get("FLOWFUSE_TEACHER_MIN_JACCARD", "0.15"))

# v7.4: prune the source that the redundancy audit identified as problematic:
# CFG-CFG paths. Anchor paths are intentionally kept because their measured
# redundancy is very low and they provide the local minimal-change view.
V74_CFG_KEEP_MAX = int(os.environ.get("FLOWFUSE_CFG_KEEP_MAX", "3"))
V74_CFG_KEEP_MIN = int(os.environ.get("FLOWFUSE_CFG_KEEP_MIN", "2"))
V74_CFG_JACCARD_THRESHOLD = float(os.environ.get("FLOWFUSE_CFG_JACCARD", "0.75"))
V74_CFG_CONTAINMENT_THRESHOLD = float(os.environ.get("FLOWFUSE_CFG_CONTAINMENT", "0.90"))
V74_SECURITY_LINE_SCORE = float(os.environ.get("FLOWFUSE_SECURITY_LINE_SCORE", "3.0"))
STRICT_SINGLE_FUNCTION = True
LOW_COVERAGE_THRESHOLD = 0.85

ALLOW_SINGLE_FALLBACK = True
MIN_FUNCTIONS_IN_CONTEXT = 2
ENFORCE_MIN_FUNCS_ALWAYS = False

# ---- 新增：drop debug 抽样 ----
DEBUG_DUMP_DROP_SAMPLES = True
DEBUG_DUMP_MAX_PER_REASON = 200
DEBUG_DUMP_PREVIEW_CHARS = 500
# ---- 新增：是否启用跨函数调用边 ----
USE_CROSS_CALL = False  # strict single-function: must remain False

os.makedirs(OUTPUT_BASE_DIR, exist_ok=True)
os.makedirs("logs", exist_ok=True)

class CleanLogFilter(logging.Filter):
    def filter(self, record):
        if isinstance(record.msg, str):
            record.msg = record.msg.replace('\x00', '')
            record.msg = re.sub(r'[\x01-\x08\x0b\x0c\x0e-\x1f]', '', record.msg)
        return True

logger = logging.getLogger("cfg_pipeline")
logger.setLevel(logging.INFO)
logger.handlers.clear()
fmt = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")

console = logging.StreamHandler(sys.stdout)
console.setLevel(logging.INFO)
console.setFormatter(fmt)

file_log = logging.FileHandler(
    os.path.join(OUTPUT_BASE_DIR, "pipeline_run.log"),
    mode="w",
    encoding="utf-8"
)
file_log.setLevel(logging.INFO)
file_log.setFormatter(fmt)

flt = CleanLogFilter()
logger.addFilter(flt)
console.addFilter(flt)
file_log.addFilter(flt)

logger.addHandler(console)
logger.addHandler(file_log)
logger.propagate = False


def worker_init():
    pass


CPP_HINT_PATTERNS = [
    r"\bstd::", r"\bnamespace\b", r"\btemplate\s*<", r"\bclass\b", r"\bvirtual\b",
    r"\bpublic:\b|\bprivate:\b|\bprotected:\b", r"::", r"\bnew\b|\bdelete\b",
    r"\bconstexpr\b|\bnoexcept\b",
]
def _get_cpp_enum():
    for name in ("CPP", "CXX", "CPP14", "CPP17", "C_PLUS_PLUS"):
        if hasattr(Lang, name):
            return getattr(Lang, name)
    return None

def detect_lang_from_code(code: str):
    cpp_enum = _get_cpp_enum()
    c_enum = getattr(Lang, "C")
    if not code:
        return c_enum
    is_cpp = any(re.search(p, code) for p in CPP_HINT_PATTERNS)
    if is_cpp and cpp_enum is not None:
        return cpp_enum
    return c_enum


INVALID_ENTRY_TOKENS = {
    "if", "while", "for", "switch", "return", "case", "else", "do",
    "void", "int", "char", "float", "double", "short", "long", "signed", "unsigned",
    "__attribute__", "PG_FUNCTION_ARGS"
}

def normalize_func_name(name: str):
    if not name:
        return None
    n = name.strip()
    n = n.split("::")[-1]
    n = re.sub(r'<.*?>', '', n)
    n = re.sub(r'^[\*&\s]+', '', n)
    n = re.sub(r'\s+', '', n)
    return n

def is_valid_entry_name(name: str) -> bool:
    if not name:
        return False
    n = normalize_func_name(name)
    if not n:
        return False
    if n in INVALID_ENTRY_TOKENS:
        return False
    return re.match(r'^[A-Za-z_]\w*$', n) is not None


def extract_pathtoken(gcode_map, path_sequence):
    seqtoken_out = []
    if not isinstance(gcode_map, dict):
        return []
    for path in path_sequence[:15]:
        lines = [gcode_map.get(node_id, '') for node_id in path]
        seq_code = '\n'.join(line for line in lines if line)
        if seq_code:
            seqtoken_out.append(seq_code)
    if not seqtoken_out and gcode_map:
        full_code = '\n'.join(gcode_map[k] for k in sorted(gcode_map.keys()))
        seqtoken_out.append(full_code)
    return sorted(seqtoken_out, key=len)




def _norm_teacher_line(line: str) -> str:
    if not line:
        return ""
    line = re.sub(r'<\s*(?:DEF|USE)\s*:[^>]*>', ' ', line)
    line = re.sub(r'//.*$', ' ', line)
    line = re.sub(r'/\*.*?\*/', ' ', line)
    line = re.sub(r'\s+', ' ', line).strip()
    return line


def _line_tokens(line: str):
    return set(re.findall(r'[A-Za-z_]\w*|0x[0-9A-Fa-f]+|\d+|==|!=|<=|>=|->|\+\+|--',
                          _norm_teacher_line(line)))


_V73_DANGER_RE = re.compile(
    r'\b(memcpy|memmove|memset|strcpy|strncpy|strcat|strncat|sprintf|snprintf|vsprintf|'
    r'gets|fgets|read|write|recv|send|malloc|calloc|realloc|free|system|popen|exec\w*)\b',
    re.IGNORECASE,
)
_V73_DEFENSE_RE = re.compile(
    r'\b(?:if|while|assert|BUG_ON|WARN_ON)\s*\([^\n]*(?:NULL|nullptr|==|!=|<=|>=|<|>|sizeof|len|size|count|index|idx|bound)',
    re.IGNORECASE,
)
_V73_POINTER_RE = re.compile(r'(?:->|\*\s*[A-Za-z_(]|\[[^\]]+\])')
_V73_ARITH_RE = re.compile(r'(?:\+\+|--|\+=|-=|\*=|/=|%=|\b(?:len|size|count|index|idx)\b\s*[+\-*])', re.IGNORECASE)


def intrinsic_line_score(line: str) -> float:
    s = _norm_teacher_line(line)
    if not s:
        return -1.0
    score = 0.0
    if _V73_DANGER_RE.search(s): score += 4.0
    if _V73_DEFENSE_RE.search(s): score += 3.5
    if _V73_POINTER_RE.search(s): score += 1.4
    if _V73_ARITH_RE.search(s): score += 1.2
    if re.search(r'\b(return|goto|break|continue)\b', s): score += 0.5
    if '=' in s: score += 0.35
    return score


def build_anchor_paths(code: str, max_anchors=6, radius=2):
    """Current-function-only local windows around security-sensitive lines.

    This addresses the PrimeVul minimal-patch failure mode: many functions have
    only 1--3 GA paths and the decisive guard/free/bounds line can be diluted in
    a long path.  Anchors are generated identically for train/valid/test.
    """
    lines = code.splitlines()
    if not lines:
        return []
    scored = [(intrinsic_line_score(ln), i) for i, ln in enumerate(lines) if ln.strip()]
    scored.sort(key=lambda x: (x[0], -x[1]), reverse=True)

    chosen = []
    for sc, i in scored:
        if sc <= 0 and chosen:
            break
        if any(abs(i - j) <= max(1, radius) for j in chosen):
            continue
        chosen.append(i)
        if len(chosen) >= max_anchors:
            break

    # Coverage anchors keep the mechanism useful for rare vulnerability types
    # whose decisive line is not in the hand-written risky API vocabulary.
    if len(chosen) < max_anchors and len(lines) >= 6:
        for frac in (0.20, 0.40, 0.60, 0.80):
            i = min(len(lines) - 1, max(0, int(round((len(lines) - 1) * frac))))
            if lines[i].strip() and not any(abs(i - j) <= max(1, radius) for j in chosen):
                chosen.append(i)
                if len(chosen) >= max_anchors:
                    break

    out = []
    seen = set()
    for i in sorted(chosen):
        lo, hi = max(0, i - radius), min(len(lines), i + radius + 1)
        text = '\n'.join(ln for ln in lines[lo:hi] if ln.strip()).strip()
        key = re.sub(r'\s+', ' ', text)
        if text and key not in seen:
            seen.add(key)
            out.append(text)
    return out


def _v74_norm_path_line(line: str) -> str:
    return re.sub(r'\s+', ' ', _norm_teacher_line(line)).strip()


def _v74_path_line_set(text: str):
    return {
        x for x in (_v74_norm_path_line(ln) for ln in (text or '').splitlines())
        if x
    }


def _v74_line_jaccard(a, b) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / float(len(a | b))


def _v74_line_containment(a, b) -> float:
    """Intersection divided by the smaller path.

    This catches the dominant v7.3 failure mode where two CFG paths share
    nearly the whole prefix/suffix but differ by only one short branch.
    """
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / float(min(len(a), len(b)))


def _v74_security_line_set(text: str):
    """Only strong danger/defense lines can override a redundancy prune.

    Pointer-only or generic assignment differences are deliberately not enough
    to keep another highly overlapping CFG path; otherwise the 80%+ CFG-CFG
    redundancy observed in v7.3 would survive.
    """
    out = set()
    for ln in (text or '').splitlines():
        if intrinsic_line_score(ln) >= V74_SECURITY_LINE_SCORE:
            norm = _v74_norm_path_line(ln)
            if norm:
                out.add(norm)
    return out


def _v74_cfg_relation_bonus(text: str) -> float:
    lines = [x for x in (text or '').splitlines() if x.strip()]
    danger_idx = [i for i, x in enumerate(lines) if _V73_DANGER_RE.search(_norm_teacher_line(x))]
    defense_idx = [i for i, x in enumerate(lines) if _V73_DEFENSE_RE.search(_norm_teacher_line(x))]
    if not danger_idx:
        return 0.0

    protected = any(d < g for g in danger_idx for d in defense_idx)
    if protected:
        return 1.25
    # An unguarded dangerous operation is itself an important structural case.
    return 0.85


def _v74_cfg_base_score(text: str) -> float:
    line_scores = [intrinsic_line_score(x) for x in (text or '').splitlines()]
    strong = [x for x in line_scores if x >= V74_SECURITY_LINE_SCORE]
    max_score = max(line_scores) if line_scores else 0.0
    # The score is intentionally current-function-only. No teacher/diff data is
    # read here, so train/valid/test candidate selection uses the same protocol.
    return (
        float(max_score)
        + _v74_cfg_relation_bonus(text)
        + 0.15 * min(4, len(strong))
    )


def _v74_cfg_near_duplicate(candidate, selected) -> bool:
    a = candidate['lines']
    b = selected['lines']
    jac = _v74_line_jaccard(a, b)
    cont = _v74_line_containment(a, b)
    return (
        jac >= V74_CFG_JACCARD_THRESHOLD
        or cont >= V74_CFG_CONTAINMENT_THRESHOLD
    )


def prune_cfg_paths_v74(cfg_paths):
    """Source-aware CFG diversity pruning.

    The v7.3 audit showed:
      - exact duplicate ratio = 0%;
      - CFG-CFG near-duplicate rate ~80-91%;
      - Anchor-Anchor redundancy ~0-2%.

    Therefore v7.4 prunes CFG paths aggressively while leaving Anchor paths
    untouched. A highly overlapping CFG path survives only when it introduces
    a *new strong security line* (danger/defense) not present in the selected
    representatives.

    Returns
    -------
    kept_paths, stats
    """
    raw = [x for x in (cfg_paths or []) if isinstance(x, str) and x.strip()]
    if not raw:
        return [], {
            'cfg_before': 0, 'cfg_after': 0, 'cfg_pruned': 0,
            'cfg_security_override': 0,
        }

    # Exact text dedup first.
    uniq, seen = [], set()
    for text in raw:
        key = re.sub(r'\s+', ' ', text).strip()
        if key and key not in seen:
            seen.add(key)
            uniq.append(text)

    infos = []
    for order, text in enumerate(uniq):
        lines = _v74_path_line_set(text)
        infos.append({
            'text': text,
            'lines': lines,
            'security': _v74_security_line_set(text),
            'base': _v74_cfg_base_score(text),
            'order': order,
        })

    # Risk/defense-rich representative first; shorter path wins a tie because
    # it concentrates the same signal in fewer tokens.
    infos.sort(
        key=lambda r: (r['base'], -len(r['lines']), -r['order']),
        reverse=True
    )

    selected = []
    security_override = 0

    for cand in infos:
        if len(selected) >= max(1, V74_CFG_KEEP_MAX):
            break

        redundant_with = [
            q for q in selected if _v74_cfg_near_duplicate(cand, q)
        ]
        if not redundant_with:
            selected.append(cand)
            continue

        represented_security = set()
        for q in redundant_with:
            represented_security.update(q['security'])
        novel_security = cand['security'] - represented_security

        if novel_security:
            selected.append(cand)
            security_override += 1

    # If pruning was extremely aggressive, retain the farthest structural
    # alternative(s). This keeps at least two CFG views when two existed.
    target_min = min(len(infos), max(1, V74_CFG_KEEP_MIN), max(1, V74_CFG_KEEP_MAX))
    while len(selected) < target_min:
        remaining = [r for r in infos if r not in selected]
        if not remaining:
            break

        def novelty_score(r):
            if not selected:
                return 1.0
            max_sim = 0.0
            for q in selected:
                jac = _v74_line_jaccard(r['lines'], q['lines'])
                max_sim = max(max_sim, jac)
            return 1.0 - max_sim

        best = max(
            remaining,
            key=lambda r: (novelty_score(r), r['base'], -len(r['lines']))
        )
        selected.append(best)

    # Preserve deterministic order by original candidate order. Path attention
    # should not depend on an arbitrary risk-sorting permutation.
    selected.sort(key=lambda r: r['order'])
    kept = [r['text'] for r in selected[:max(1, V74_CFG_KEEP_MAX)]]

    return kept, {
        'cfg_before': len(uniq),
        'cfg_after': len(kept),
        'cfg_pruned': max(0, len(uniq) - len(kept)),
        'cfg_security_override': int(security_override),
    }


def merge_cfg_and_anchor_paths(cfg_paths, anchor_paths):
    """v7.4 source-aware merge.

    1) prune near-duplicate CFG paths;
    2) keep Anchor paths (only exact dedup);
    3) do NOT drop an Anchor merely because it is contained in a CFG path:
       local and structural paths play different roles in PMCL.
    """
    cfg_keep, prune_stats = prune_cfg_paths_v74(cfg_paths)

    texts, sources, scores, seen = [], [], [], set()
    for source, seq in (("cfg", cfg_keep or []), ("anchor", anchor_paths or [])):
        for text in seq:
            if not isinstance(text, str) or not text.strip():
                continue
            key = re.sub(r'\s+', ' ', text).strip()
            if key in seen:
                continue
            seen.add(key)
            texts.append(text)
            sources.append(source)
            line_scores = [intrinsic_line_score(x) for x in text.splitlines()]
            score = float(max(line_scores) if line_scores else 0.0)
            if source == 'cfg':
                score += _v74_cfg_relation_bonus(text)
            else:
                # Small source prior: anchors are the non-redundant local view
                # found by the v7.3 audit and are useful for minimal changes.
                score += 0.20
            scores.append(score)

    prune_stats['anchor_after'] = sum(1 for x in sources if x == 'anchor')
    prune_stats['final_paths'] = len(texts)
    return texts, sources, scores, prune_stats


def _pair_changed_lines(lines_a, lines_b):
    """Return train-only changed/context lines on each side of a minimal pair."""
    raw_a, raw_b = lines_a.splitlines(), lines_b.splitlines()
    sig_a = [_norm_teacher_line(x) for x in raw_a]
    sig_b = [_norm_teacher_line(x) for x in raw_b]
    sm = difflib.SequenceMatcher(a=sig_a, b=sig_b, autojunk=False)
    a_pos, b_pos = set(), set()

    def add_context(pos_set, n, start, end):
        for k in range(max(0, start), min(n, end)):
            if _norm_teacher_line((raw_a if pos_set is a_pos else raw_b)[k]):
                pos_set.add(k)

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal':
            continue
        a_pos.update(range(i1, i2))
        b_pos.update(range(j1, j2))
        # If one side has no changed line (pure insertion/deletion), supervise
        # the boundary neighborhood on that side rather than inventing a line.
        if i1 == i2:
            add_context(a_pos, len(raw_a), i1 - 1, i1 + 2)
        if j1 == j2:
            add_context(b_pos, len(raw_b), j1 - 1, j1 + 2)

    a_lines = [_norm_teacher_line(raw_a[i]) for i in sorted(a_pos)
               if 0 <= i < len(raw_a) and _norm_teacher_line(raw_a[i])]
    b_lines = [_norm_teacher_line(raw_b[i]) for i in sorted(b_pos)
               if 0 <= i < len(raw_b) and _norm_teacher_line(raw_b[i])]
    return a_lines, b_lines


def build_train_teacher_map(raw_lines):
    groups = defaultdict(dict)
    for raw in raw_lines:
        try:
            j = json.loads(raw)
        except Exception:
            continue
        pid = j.get('pair_id')
        lab = j.get('target')
        idx = j.get('idx')
        code = j.get('func_main') or j.get('func') or ''
        if pid is None or lab not in (0, 1) or idx is None or not code:
            continue
        groups[str(pid)][int(lab)] = (str(idx), code)

    teacher = {}
    for pair in groups.values():
        if 0 not in pair or 1 not in pair:
            continue
        vid, vcode = pair[1]
        sid, scode = pair[0]
        vlines, slines = _pair_changed_lines(vcode, scode)
        teacher[vid] = vlines
        teacher[sid] = slines
    return teacher


def _teacher_score_path(path_text, changed_lines):
    if not changed_lines:
        return 0.0
    path_norm_lines = [_norm_teacher_line(x) for x in (path_text or '').splitlines()]
    path_norm_lines = [x for x in path_norm_lines if x]
    if not path_norm_lines:
        return 0.0
    path_tokens = _line_tokens(' '.join(path_norm_lines))
    best = 0.0
    for ch in changed_lines:
        chn = _norm_teacher_line(ch)
        if not chn:
            continue
        if any(chn == pl or chn in pl or pl in chn for pl in path_norm_lines if len(pl) >= 6):
            best = max(best, 1.0)
            continue
        ct = _line_tokens(chn)
        if ct and path_tokens:
            jac = len(ct & path_tokens) / max(1, len(ct | path_tokens))
            best = max(best, float(jac))
    return best


def annotate_train_teacher_metadata(results, raw_lines):
    teacher_map = build_train_teacher_map(raw_lines)
    available = exactish = 0
    for idx, rec in results.items():
        changed = teacher_map.get(str(idx), [])
        paths = rec.get('path_token', []) if isinstance(rec, dict) else []
        scores = [_teacher_score_path(p, changed) for p in paths]
        if changed and scores and max(scores) < V73_TEACHER_MIN_JACCARD:
            # No exact path hit: keep a weak soft teacher on the closest current-
            # function path.  This does not add counterpart text to the input.
            m = max(range(len(scores)), key=lambda k: scores[k])
            if scores[m] > 0:
                scores[m] = max(scores[m], 0.35)
        teacher_available = bool(changed and scores and max(scores) > 0)
        if teacher_available:
            available += 1
            if max(scores) >= 0.99:
                exactish += 1
        rec['teacher_path_scores'] = [float(x) for x in scores]
        rec['teacher_changed_count'] = int(len(changed))
        rec['teacher_available'] = bool(teacher_available)
        rec['teacher_train_only'] = True
    return {
        'paired_teacher_entries': len(teacher_map),
        'teacher_available_records': available,
        'teacher_exact_path_records': exactish,
    }



# ---------- 新增：AST门控 ----------
def ast_parse_ok(code: str, lang) -> bool:
    try:
        tree = ps.tree_sitter_ast(code, lang)
        return tree is not None and getattr(tree, "root_node", None) is not None
    except Exception:
        return False


# ---------- 新增：函数提取正则兜底 ----------
def _fallback_extract_functions_by_regex(clean_code: str):
    out = []
    if not clean_code:
        return out

    text = clean_code
    n = len(text)

    header_pat = re.compile(
        r'(?<![\w:])([A-Za-z_]\w*)\s*\([^;{}]*\)\s*\{',
        re.MULTILINE
    )

    seen = set()

    for m in header_pat.finditer(text):
        name = m.group(1)
        if not is_valid_entry_name(name):
            continue
        if name in {"if", "for", "while", "switch", "catch"}:
            continue

        open_brace = m.end() - 1
        depth = 0
        end_pos = None

        i = open_brace
        while i < n:
            ch = text[i]
            if ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    end_pos = i
                    break
            i += 1

        if end_pos is None:
            continue

        snippet = text[m.start(): end_pos + 1]
        s_line = text.count('\n', 0, m.start())
        e_line = text.count('\n', 0, end_pos)

        key = (name, s_line, e_line)
        if key in seen:
            continue
        seen.add(key)
        out.append((name, snippet, s_line, e_line))

    return out


def _find_function_name(func_node, lang=None):
    def _find_first_by_type(node, tname):
        if node is None:
            return None
        if getattr(node, "type", None) == tname:
            return node
        for ch in getattr(node, "children", []):
            got = _find_first_by_type(ch, tname)
            if got is not None:
                return got
        return None

    # 1) 优先从 function_declarator 的直接子节点找 identifier
    #    不递归进 parameter_list
    decl = _find_first_by_type(func_node, "function_declarator")
    if decl is not None:
        for ch in decl.children:
            # 只看直接子节点，跳过 parameter_list / argument_list
            if ch.type == "identifier":
                try:
                    cand = ch.text.decode("utf8", errors="ignore").strip()
                    if is_valid_entry_name(cand):
                        return cand
                except Exception:
                    pass
            # C++ qualified name: namespace::ClassName::method
            elif ch.type in ("qualified_identifier", "scoped_identifier",
                             "field_identifier", "destructor_name"):
                ids = []
                def _collect(n):
                    if getattr(n, "type", None) in ("identifier", "field_identifier"):
                        try:
                            ids.append(n.text.decode("utf8", errors="ignore").strip())
                        except Exception:
                            pass
                    for sub in getattr(n, "children", []):
                        _collect(sub)
                _collect(ch)
                if ids:
                    cand = ids[-1]  # 取最后一个（方法名）
                    if is_valid_entry_name(cand):
                        return cand

    # 2) 回退：递归找第一个 identifier（兜底）
    if getattr(func_node, "type", None) == "identifier":
        try:
            cand = func_node.text.decode('utf8', errors='ignore')
            if is_valid_entry_name(cand):
                return cand
        except Exception:
            pass

    for c in getattr(func_node, "children", []):
        # 跳过 compound_statement 避免进入函数体
        if c.type in ("compound_statement", "parameter_list", "argument_list"):
            continue
        name = _find_function_name(c, lang=lang)
        if name:
            return name

    return None



def get_function_definitions(clean_code: str, lang):
    func_list = []
    ast_ok = False
    try:
        ast = ps.tree_sitter_ast(clean_code, lang)
        ast_ok = ast is not None and getattr(ast, "root_node", None) is not None
        if ast_ok:
            root = ast.root_node
            lines = clean_code.splitlines()

            def recurse(node):
                if node.type == "function_definition":
                    # 这里改为传 lang，启用 C++增强提取
                    name = _find_function_name(node, lang=lang)
                    if name:
                        s, e = node.start_point[0], node.end_point[0]
                        snippet = "\n".join(lines[s:e + 1])
                        func_list.append((name, snippet, s, e))
                    return
                for c in node.children:
                    recurse(c)

            recurse(root)
    except Exception:
        ast_ok = False

    if func_list:
        return func_list

    # AST成功但没抓到函数定义时，走正则兜底
    if ast_ok:
        return _fallback_extract_functions_by_regex(clean_code)

    return []
def get_single_function_name(code: str, lang):
    """单函数文件：提取唯一的函数名"""
    defs = get_function_definitions(code, lang)
    if not defs:
        return None
    if len(defs) == 1:
        return defs[0][0]
    # 多函数时返回 None，让调用方走其他逻辑
    return None


def process_single_line(line_content: str):
    """Build paths from the CURRENT function only.

    Strict protocol guarantees:
      * never reads func_patch or the paired sample's source code;
      * never computes vulnerable-vs-patched diff lines;
      * never sends diff nodes to the GA path sampler;
      * pair_id is metadata only and has no effect on path construction.
    """
    try:
        j = json.loads(line_content)
        raw_idx = j.get("idx", None)
        idx = str(raw_idx) if raw_idx is not None else (
            "noidx_" + hashlib.md5(line_content.encode("utf-8", errors="ignore")).hexdigest()[:12]
        )
        target = j.get("target")
        func_main = j.get("func_main") or j.get("func") or j.get("code") or ""

        if not isinstance(func_main, str) or not func_main.strip():
            return None, "missing_func_main", {"idx": idx, "raw_idx": raw_idx, "reason": "missing_func_main"}
        if len(func_main.strip()) < 30:
            return None, "func_too_short", {
                "idx": idx, "raw_idx": raw_idx, "reason": "func_too_short",
                "func_len": len(func_main.strip()), "target": target,
            }

        vul_type = (j.get("vul_type") or "").strip().lower()
        if target == 1 and vul_type == "nonvuln":
            return None, "label_conflict_target1_nonvuln", {
                "idx": idx, "raw_idx": raw_idx,
                "reason": "label_conflict_target1_nonvuln",
                "target": target, "vul_type": vul_type,
            }

        pair_id = j.get("pair_id", "")  # metadata only; never dereferenced
        file_path = j.get("file_path", "") or j.get("local_file_path", "")
        lang = detect_lang_from_meta_and_code(func_main, pair_id, file_path)

        cpp_enum = _get_cpp_enum()
        c_enum = getattr(Lang, "C")
        is_cpp = (cpp_enum is not None and lang == cpp_enum)
        lang_tag = "cpp" if is_cpp else "c"

        clean_main, _ = remove_comments_and_docstrings(func_main, lang_tag)
        if not clean_main or len(clean_main.strip()) < 20:
            clean_main = func_main

        def _switch_lang(cur_lang):
            if cpp_enum is None:
                return cur_lang
            return c_enum if cur_lang == cpp_enum else cpp_enum

        if not ast_parse_ok(clean_main, lang):
            alt_lang = _switch_lang(lang)
            if alt_lang != lang and ast_parse_ok(clean_main, alt_lang):
                lang = alt_lang
                is_cpp = (cpp_enum is not None and lang == cpp_enum)
                lang_tag = "cpp" if is_cpp else "c"
                clean_alt, _ = remove_comments_and_docstrings(func_main, lang_tag)
                if clean_alt and len(clean_alt.strip()) >= 20:
                    clean_main = clean_alt
            else:
                return None, "drop_ast_parse_fail", {
                    "idx": idx, "raw_idx": raw_idx, "reason": "drop_ast_parse_fail",
                    "lang": lang_tag, "pair_id": pair_id, "file_path": file_path,
                }

        preferred_entry = get_single_function_name(clean_main, lang)
        if not is_valid_entry_name(preferred_entry):
            preferred_entry = None

        # Make GA stochastic operations reproducible per sample, independent of
        # multiprocessing completion order.
        seed_src = f"{idx}|{target}|{len(clean_main)}"
        sample_seed = int(hashlib.md5(seed_src.encode("utf-8")).hexdigest()[:8], 16)
        random.seed(sample_seed)

        try:
            mpaths, gcode_map, real_entry = process_content_to_combined_cfg(
                clean_code=clean_main,
                lang=lang,
                max_call_depth=1,
                preferred_entry=preferred_entry,
                min_functions_in_context=1,
                use_cross_call=False,
                diff_lines=None,
            )
            build_mode = "strict_single"
        except ValueError as e:
            return None, f"strict_single_drop::{e}", {
                "idx": idx, "raw_idx": raw_idx, "reason": str(e),
                "lang": lang_tag, "pair_id": pair_id, "file_path": file_path,
            }

        cfg_allpath = mpaths.get("paths", [])
        cfg_path_tokens = extract_pathtoken(gcode_map, cfg_allpath)
        anchor_path_tokens = build_anchor_paths(
            clean_main, max_anchors=V73_MAX_ANCHOR_PATHS, radius=V73_ANCHOR_RADIUS
        )
        path_tokens, path_sources, path_intrinsic_scores, prune_stats = merge_cfg_and_anchor_paths(
            cfg_path_tokens, anchor_path_tokens
        )
        if not path_tokens:
            return None, "no_path_tokens", {
                "idx": idx, "raw_idx": raw_idx, "reason": "no_path_tokens",
                "lang": lang_tag,
            }

        coverage_ratio = float(mpaths.get("coverage_ratio", 0.0))
        dfg_coverage_ratio = float(mpaths.get("dfg_coverage_ratio", 0.0))
        num_paths = int(mpaths.get("num_paths", len(cfg_allpath)))
        retry_used = bool(mpaths.get("retry_used", False))
        token_lines_max = int(mpaths.get("token_lines_max", 0))

        logger.info(
            f"[strict] idx={idx} mode={build_mode} paths={len(path_tokens)} "
            f"cfg_cov={coverage_ratio:.3f} dfg_cov={dfg_coverage_ratio:.3f} "
            f"num_paths={num_paths} retry={retry_used} token_max={token_lines_max} lang={lang_tag}"
        )

        # Deliberately omit patch_path_token / has_patch / diff_coverage_ratio /
        # diff_nodes_detail. run.py rejects PKLs containing those legacy fields.
        return {
            "idx": idx,
            "raw_idx": raw_idx,
            "target": target,
            "vul_type": j.get("vul_type", "unknown"),
            "vul_content": j.get("vul_content", "unknown"),
            "code": clean_main,
            "path_token": path_tokens,
            "path_source": path_sources,
            "path_intrinsic_score": path_intrinsic_scores,
            "cfg_path_count_before_prune": int(prune_stats.get("cfg_before", len(cfg_path_tokens))),
            "cfg_path_count": int(prune_stats.get("cfg_after", 0)),
            "cfg_path_pruned": int(prune_stats.get("cfg_pruned", 0)),
            "cfg_security_override": int(prune_stats.get("cfg_security_override", 0)),
            "anchor_path_count": int(prune_stats.get("anchor_after", len(anchor_path_tokens))),
            "final_path_count": int(prune_stats.get("final_paths", len(path_tokens))),
            "coverage_ratio": coverage_ratio,
            "dfg_coverage_ratio": dfg_coverage_ratio,
            "num_paths": num_paths,
            "retry_used": retry_used,
            "token_lines_max": token_lines_max,
            "entry_func": real_entry,
            "lang": lang_tag,
            "build_mode": build_mode,
            "strict_single_function": True,
            "v73_pmcl": True,
            "v74_diverse": True,
        }, None, None

    except Exception as e:
        import traceback
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc(limit=2)}"
        return None, f"other_exception::{err}", {"reason": "other_exception", "error": err[:1000]}

def find_call_sites_and_callees(func_code: str, lang):
    result = []
    try:
        ast = ps.tree_sitter_ast(func_code, lang)
        root = ast.root_node

        def pick_call_name(call_node):
            for c in call_node.children:
                if c.type in ("identifier", "field_identifier", "qualified_identifier"):
                    txt = c.text.decode("utf8", errors="ignore")
                    n = normalize_func_name(txt)
                    if n:
                        return n
            stack = [call_node]
            while stack:
                cur = stack.pop()
                if getattr(cur, "type", None) in ("identifier", "field_identifier", "qualified_identifier"):
                    txt = cur.text.decode("utf8", errors="ignore")
                    n = normalize_func_name(txt)
                    if n:
                        return n
                stack.extend(getattr(cur, "children", [])[::-1])
            return None

        def recurse(node):
            if node.type == "call_expression":
                callee = pick_call_name(node)
                if callee:
                    result.append((node.start_point[0] + 1, callee))
                for c in node.children:
                    recurse(c)
                return
            for c in node.children:
                recurse(c)

        recurse(root)
    except Exception:
        pass
    return result


def select_allowed_functions(func_defs, all_call_sites, max_depth=4, preferred_entry=None, use_cross_call=True):
    if not func_defs:
        return set(), None

    names = {d[0] for d in func_defs}
    norm2raw = defaultdict(list)
    for n in names:
        norm2raw[normalize_func_name(n)].append(n)

    # 入口选择逻辑保持
    entry = None
    if preferred_entry:
        pe_norm = normalize_func_name(preferred_entry)
        if preferred_entry in names:
            entry = preferred_entry
        else:
            cands = norm2raw.get(pe_norm, [])
            if cands:
                entry = cands[0]
            if not entry and pe_norm:
                pe_low = pe_norm.lower()
                for raw in names:
                    rn = normalize_func_name(raw)
                    if rn and rn.lower() == pe_low:
                        entry = raw
                        break

    if not entry:
        # 原兜底：按入度最小选入口
        call_graph_tmp = {
            n: {callee for _, callee in all_call_sites.get(n, []) if callee in names}
            for n in names
        }
        indeg = {n: 0 for n in names}
        for u, cs in call_graph_tmp.items():
            for v in cs:
                if v in indeg:
                    indeg[v] += 1
        cands = sorted(names, key=lambda x: (indeg.get(x, 0), x))
        entry = cands[0] if cands else (next(iter(names)) if names else None)

    if not entry:
        return set(), None

    # 关键分支：关闭跨函数时，只用入口函数
    if not use_cross_call:
        return {entry}, entry

    # 开启跨函数时：BFS扩展调用图
    call_graph = {
        n: {callee for _, callee in all_call_sites.get(n, []) if callee in names}
        for n in names
    }

    allowed, queue, visited = set(), [(entry, 0)], set()
    while queue:
        fname, d = queue.pop(0)
        if fname in visited or d > max_depth:
            continue
        visited.add(fname)
        allowed.add(fname)
        for callee in call_graph.get(fname, []):
            queue.append((callee, d + 1))

    if not allowed:
        allowed = {entry}

    return allowed, entry


def process_content_to_combined_cfg(
        clean_code,
        lang,
        max_call_depth=4,
        preferred_entry=None,
        min_functions_in_context=1,
        use_cross_call=False,
        diff_lines: set = None
):
    """
    Build CFG/DFG paths from one function only.

    ``diff_lines`` exists only for backward-compatible calling syntax. Any
    non-empty value is rejected because counterpart-derived diffs violate the
    strict single-function protocol.
    """
    if diff_lines:
        raise RuntimeError(
            "STRICT PROTOCOL VIOLATION: diff_lines were supplied to path preprocessing"
        )
    func_defs = get_function_definitions(clean_code, lang)
    if not func_defs:
        raise ValueError("No function definitions found in context code.")
    if len(func_defs) < min_functions_in_context:
        raise ValueError(f"strict_multi_requires_at_least_{min_functions_in_context}_functions")

    all_call_sites = {name: find_call_sites_and_callees(code, lang) for name, code, _, _ in func_defs}

    allowed_funcs, entry_func = select_allowed_functions(
        func_defs, all_call_sites,
        max_depth=max_call_depth,
        preferred_entry=preferred_entry,
        use_cross_call=use_cross_call
    )
    if not entry_func:
        raise ValueError("func_main entry not found in context functions.")

    cfgs, entry_local, local_fin = {}, {}, {}
    for name, code_snippet, _, _ in func_defs:
        if name in allowed_funcs:
            cfg = C_CFG(source_code=code_snippet)
            ast = ps.tree_sitter_ast(code_snippet, lang)
            if ast is None or getattr(ast, "root_node", None) is None:
                continue
            cfg.parse_ast_file(ast.root_node)
            cfg.validate_graph()
            cfgs[name] = cfg
            entry_local[name] = cfg.firstlineno
            local_fin[name] = set(cfg.finlineno)

    if entry_func not in cfgs:
        raise ValueError(f"Entry function '{entry_func}' CFG build failed.")

    combined = nx.DiGraph()
    mapping, counter = {}, 1
    final_order = sorted(list(cfgs.keys()), key=lambda x: (x != entry_func, x))
    for fname in final_order:
        local_nodes = sorted(cfgs[fname].G.nodes())
        mapping[fname] = {ln: i + counter for i, ln in enumerate(local_nodes)}
        counter += len(local_nodes)

    for gid in range(1, counter):
        combined.add_node(gid)

    for fname in final_order:
        for u, v, d in cfgs[fname].G.edges(data=True):
            gu, gv = mapping[fname].get(u), mapping[fname].get(v)
            if gu and gv:
                combined.add_edge(gu, gv, **(d if d else {}))

    cross_call_edges = set()
    if use_cross_call:
        for caller, sites in all_call_sites.items():
            if caller in cfgs:
                for line, callee in sites:
                    if callee in cfgs and callee in entry_local:
                        gu = mapping[caller].get(line)
                        gv = mapping[callee].get(entry_local[callee])
                        if gu and gv:
                            combined.add_edge(gu, gv, weight=1, label="cross_call")
                            cross_call_edges.add((gu, gv))

    combined_dfg_edges = set()
    for fname in final_order:
        cfg_obj = cfgs[fname]
        m = mapping[fname]
        for def_ln, use_ln, var in getattr(cfg_obj, 'dfg_edges', set()):
            gdef = m.get(def_ln)
            guse = m.get(use_ln)
            if gdef is not None and guse is not None:
                combined_dfg_edges.add((gdef, guse, var))

    merged = C_CFG(source_code="")
    merged.G = combined

    entry_ln = entry_local.get(entry_func, None)
    entry_gid = mapping.get(entry_func, {}).get(entry_ln, None)
    if entry_gid is None:
        vals = list(mapping.get(entry_func, {}).values())
        if not vals:
            raise ValueError(f"entry mapping missing for {entry_func}")
        entry_gid = min(vals)
    merged.firstlineno = entry_gid

    merged.finlineno = sorted(
        mapping[fn].get(ln)
        for fn, fins in local_fin.items()
        if fn in mapping
        for ln in fins
        if mapping[fn].get(ln) is not None
    )
    merged.cross_call_edges = cross_call_edges if use_cross_call else set()
    merged.dfg_edges = combined_dfg_edges

    max_gid = counter - 1
    merged_source_lines = [""] * max_gid
    for fname, m in mapping.items():
        cfg_obj = cfgs[fname]
        for ln, gid in m.items():
            if 1 <= ln <= len(cfg_obj.source_lines):
                merged_source_lines[gid - 1] = cfg_obj.source_lines[ln - 1]
    merged.source_lines = merged_source_lines

    gcode_map = {}
    for fname, m in mapping.items():
        cfg_obj = cfgs[fname]
        for ln, gid in m.items():
            if 1 <= ln <= len(cfg_obj.source_lines):
                raw = cfg_obj.source_lines[ln - 1].strip()
                if hasattr(cfg_obj, "annotate_code_line_with_du"):
                    gcode_map[gid] = cfg_obj.annotate_code_line_with_du(ln, raw)
                else:
                    gcode_map[gid] = raw

    # Strict GA sampling: coverage + DFG + intrinsic risk only.
    _, all_paths, _, ratio = merged.get_allpath(
        max_paths=STRICT_MAX_PATHS,
        generations=12,
        population_size=36,
        diff_nodes=None,
    )

    if not all_paths and ratio == 0.0:
        raise ValueError("Path generation failed (no paths, zero coverage).")

    dfg_cov = float(getattr(merged, "dfg_coverage_ratio", 0.0))

    def _token_lines_max(paths, gmap):
        mx = 0
        for p in paths[:STRICT_RETRY_MAX_PATHS]:
            seq = "\n".join(gmap.get(n, "") for n in p if gmap.get(n, ""))
            ln = len([x for x in seq.splitlines() if x.strip()])
            mx = max(mx, ln)
        return mx

    token_lines_max = _token_lines_max(all_paths, gcode_map)
    num_paths = len(all_paths)
    retry_used = False

    need_retry = (ratio < 0.20) or (token_lines_max <= 6) or (num_paths <= 1)
    if need_retry:
        retry_used = True
        _, all_paths2, _, ratio2 = merged.get_allpath(
            max_paths=STRICT_RETRY_MAX_PATHS,
            generations=16,
            population_size=44,
            diff_nodes=None,
        )
        dfg_cov2 = float(getattr(merged, "dfg_coverage_ratio", dfg_cov))
        token_lines_max2 = _token_lines_max(all_paths2, gcode_map)
        num_paths2 = len(all_paths2)

        better = (
            ratio2 > ratio
            or (ratio2 == ratio and num_paths2 > num_paths)
            or (ratio2 == ratio and num_paths2 == num_paths and token_lines_max2 > token_lines_max)
        )
        if better and all_paths2:
            all_paths = all_paths2
            ratio = ratio2
            dfg_cov = dfg_cov2
            token_lines_max = token_lines_max2
            num_paths = num_paths2

    return {
        "paths": all_paths,
        "coverage_ratio": float(ratio),
        "dfg_coverage_ratio": float(dfg_cov),
        "num_paths": int(num_paths),
        "retry_used": bool(retry_used),
        "token_lines_max": int(token_lines_max),
        "strict_single_function": True,
    }, gcode_map, entry_func

def detect_lang_from_meta_and_code(code: str, pair_id: str = "", file_path: str = ""):
    """
    语言判定优先级：
    1) pair_id/file_path 后缀（最可靠）
    2) 代码特征
    3) 默认 C
    """
    cpp_enum = _get_cpp_enum()
    c_enum = getattr(Lang, "C")

    meta = f"{pair_id or ''} {file_path or ''}".lower()

    # 后缀优先
    cpp_exts = (".cc", ".cpp", ".cxx", ".c++", ".hpp", ".hh", ".hxx")
    c_exts = (".c",)

    if any(ext in meta for ext in cpp_exts):
        return cpp_enum if cpp_enum is not None else c_enum
    if any(ext in meta for ext in c_exts):
        return c_enum

    # 代码特征兜底
    if code:
        cpp_hint = re.search(
            r"\bstd::|\bnamespace\b|\btemplate\s*<|::|\bclass\b|\bvirtual\b|\bnew\b|\bdelete\b|"
            r"\bconstexpr\b|\bnoexcept\b|\bnullptr\b",
            code
        )
        if cpp_hint and cpp_enum is not None:
            return cpp_enum

    return c_enum







def process_lines_multiprocess(lines_to_process, output_file, max_workers):
    total_path_dict = {}
    drop_reasons = defaultdict(int)
    printed_err = 0
    max_print = 30

    drop_debug_samples = defaultdict(list)

    with ProcessPoolExecutor(max_workers=max_workers, initializer=worker_init) as executor:
        futures = {executor.submit(process_single_line, line): line for line in lines_to_process}

        for future in tqdm(as_completed(futures), total=len(lines_to_process), desc=f"Processing {os.path.basename(output_file)}"):
            try:
                ret = future.result()

                if isinstance(ret, tuple) and len(ret) == 3:
                    res, reason, debug_item = ret
                elif isinstance(ret, tuple) and len(ret) == 2:
                    res, reason = ret
                    debug_item = None
                else:
                    res, reason, debug_item = None, "worker_return_format_error", None

                if res is not None:
                    total_path_dict[str(res["idx"])] = res
                else:
                    r = reason if reason else "unknown"
                    drop_reasons[r] += 1

                    if DEBUG_DUMP_DROP_SAMPLES and debug_item is not None:
                        if len(drop_debug_samples[r]) < DEBUG_DUMP_MAX_PER_REASON:
                            drop_debug_samples[r].append(debug_item)

                    if r.startswith("other_exception::") and printed_err < max_print:
                        print("\n[REAL-ERROR]", r[len("other_exception::"):])
                        printed_err += 1
            except Exception as e:
                drop_reasons["worker_unhandled_exception"] += 1
                if DEBUG_DUMP_DROP_SAMPLES:
                    if len(drop_debug_samples["worker_unhandled_exception"]) < DEBUG_DUMP_MAX_PER_REASON:
                        drop_debug_samples["worker_unhandled_exception"].append({"error": repr(e)})
                print("[MAIN-WORKER-ERR]", repr(e))

    with open(output_file, "wb") as outf:
        pickle.dump(total_path_dict, outf)

    # 落盘 drop debug 抽样
    if DEBUG_DUMP_DROP_SAMPLES:
        drop_debug_path = os.path.splitext(output_file)[0] + "_drop_debug_samples.jsonl"
        with open(drop_debug_path, "w", encoding="utf-8") as f:
            for reason, items in drop_debug_samples.items():
                for it in items:
                    row = {"drop_reason": reason, **(it if isinstance(it, dict) else {"value": str(it)})}
                    f.write(json.dumps(row, ensure_ascii=False) + "\n")

    return total_path_dict, dict(drop_reasons)


def summarize_coverages(covs):
    if not covs:
        return {"count": 0, "avg": 0.0, "median": 0.0, "min": 0.0, "max": 0.0, "p90": 0.0}
    s = sorted(covs)
    p90_idx = int(0.9 * (len(s) - 1))
    return {
        "count": len(covs),
        "avg": sum(covs) / len(covs),
        "median": statistics.median(covs),
        "min": s[0],
        "max": s[-1],
        "p90": s[p90_idx]
    }


# ===== 在文件顶部，import 语句之后添加 =====

def main():
    if SAMPLE_RATIO and 0 < SAMPLE_RATIO < 1.0:
        random.seed(42)
        logger.info(f"Sampling enabled: {SAMPLE_RATIO:.0%}")

    if USE_CROSS_CALL:
        raise RuntimeError("STRICT v7 requires USE_CROSS_CALL=False")

    logger.info("=" * 80)
    logger.info("FlowFuse v7.4 PMCL+DIVERSE preprocessing")
    logger.info("Current-function paths for all splits; TRAIN-only pair diff teacher after path generation.")
    logger.info("=" * 80)

    t0 = time.time()
    final_report = {
        "config": {
            "dataset_base_dir": DATASET_BASE_DIR,
            "output_base_dir": OUTPUT_BASE_DIR,
            "sample_ratio": SAMPLE_RATIO,
            "max_workers": MAX_WORKERS,
            "strict_single_function": True,
            "max_paths": STRICT_MAX_PATHS,
            "retry_max_paths": STRICT_RETRY_MAX_PATHS,
            "use_cross_call": False,
        },
        "splits": {},
        "overall": {},
    }

    overall_input = overall_success = overall_drop = 0
    overall_cov = []
    overall_drop_reasons = defaultdict(int)
    overall_low_items = []
    overall_retry_used = 0
    overall_num_paths_sum = 0
    overall_num_paths_cnt = 0

    for cfg in DATASETS_CONFIG:
        split = cfg["split"]
        input_file = os.path.join(DATASET_BASE_DIR, cfg["input"])
        output_pkl = os.path.join(OUTPUT_BASE_DIR, cfg["output_pkl"])

        logger.info(f"\n{'='*24} {split} {'='*24}")
        if not os.path.exists(input_file):
            logger.warning(f"Missing input: {input_file}")
            final_report["splits"][split] = {"error": "input_missing"}
            continue

        with open(input_file, "r", encoding="utf-8") as f:
            all_lines = f.readlines()

        lines = all_lines
        sampled = False
        if SAMPLE_RATIO and 0 < SAMPLE_RATIO < 1.0:
            n = int(len(all_lines) * SAMPLE_RATIO)
            if n > 0:
                lines = random.sample(all_lines, n)
                sampled = True

        if sampled:
            name, ext = os.path.splitext(cfg["output_pkl"])
            output_pkl = os.path.join(
                OUTPUT_BASE_DIR, f"{name}_sample{int(SAMPLE_RATIO*100)}pct{ext}"
            )

        logger.info(f"[{split}] strict processing {len(lines)} -> {output_pkl}")
        results, drop_reasons = process_lines_multiprocess(
            lines, output_pkl, max_workers=MAX_WORKERS
        )

        teacher_stats = {}
        if split == "train":
            teacher_stats = annotate_train_teacher_metadata(results, lines)
            # process_lines_multiprocess wrote the initial PKL; overwrite it only
            # after train-only teacher metadata has been attached.
            with open(output_pkl, "wb") as outf:
                pickle.dump(results, outf)
            logger.info(f"[train teacher] {teacher_stats}")
        else:
            # Explicit invariant: validation/test records contain no pair teacher.
            for _rec in results.values():
                for _k in ("teacher_path_scores", "teacher_changed_count",
                           "teacher_available", "teacher_train_only"):
                    _rec.pop(_k, None)
            with open(output_pkl, "wb") as outf:
                pickle.dump(results, outf)

        # Keep the ORIGINAL split intact. Samples whose CFG extraction failed are
        # retained; run.py will use a current-function-only raw-code fallback.
        base, _ = os.path.splitext(cfg["input"])
        synced_name = (
            f"{base}_synced.jsonl" if not sampled
            else f"{base}_sample{int(SAMPLE_RATIO*100)}pct_synced.jsonl"
        )
        synced_path = os.path.join(OUTPUT_BASE_DIR, synced_name)
        with open(synced_path, "w", encoding="utf-8") as f:
            f.writelines(lines)

        input_cnt = len(lines)
        success_cnt = len(results)
        drop_cnt = input_cnt - success_cnt
        drop_rate = (drop_cnt / input_cnt) if input_cnt else 0.0
        covs = [float(v.get("coverage_ratio", 0.0)) for v in results.values()]
        cov_stat = summarize_coverages(covs)
        low_items = [
            {"split": split, "idx": idx, "coverage": item.get("coverage_ratio", 0.0)}
            for idx, item in results.items()
            if float(item.get("coverage_ratio", 0.0)) < LOW_COVERAGE_THRESHOLD
        ]
        retry_used_count = sum(bool(v.get("retry_used", False)) for v in results.values())
        num_paths_list = [
            int(v.get("num_paths", 0)) for v in results.values()
            if int(v.get("num_paths", 0)) > 0
        ]
        avg_num_paths = sum(num_paths_list) / len(num_paths_list) if num_paths_list else 0.0

        final_path_counts = [int(v.get("final_path_count", len(v.get("path_token", []) or [])))
                             for v in results.values()]
        cfg_before_counts = [int(v.get("cfg_path_count_before_prune", v.get("cfg_path_count", 0)))
                             for v in results.values()]
        cfg_after_counts = [int(v.get("cfg_path_count", 0)) for v in results.values()]
        cfg_pruned_counts = [int(v.get("cfg_path_pruned", 0)) for v in results.values()]
        anchor_after_counts = [int(v.get("anchor_path_count", 0)) for v in results.values()]
        def _avg_v74(xs):
            return sum(xs) / len(xs) if xs else 0.0

        final_report["splits"][split] = {
            "input_count": input_cnt,
            "cfg_success_count": success_cnt,
            "cfg_fallback_needed": drop_cnt,
            "cfg_fallback_rate": drop_rate,
            "drop_reasons": drop_reasons,
            "coverage": cov_stat,
            "retry_used_count": retry_used_count,
            "avg_num_paths": avg_num_paths,
            "avg_final_paths": _avg_v74(final_path_counts),
            "avg_cfg_before_prune": _avg_v74(cfg_before_counts),
            "avg_cfg_after_prune": _avg_v74(cfg_after_counts),
            "avg_cfg_pruned": _avg_v74(cfg_pruned_counts),
            "avg_anchor_after": _avg_v74(anchor_after_counts),
            "low_coverage_count": len(low_items),
            "output_pkl": output_pkl,
            "output_synced_jsonl": synced_path,
            "strict_single_function": True,
            "v73_pmcl": True,
            "v74_diverse": True,
            "teacher_stats": teacher_stats,
        }

        logger.info(
            f"[{split}] input={input_cnt}, cfg_success={success_cnt}, "
            f"raw_fallback_needed={drop_cnt} ({drop_rate:.2%}), "
            f"retry={retry_used_count}, ga_paths={avg_num_paths:.2f}, "
            f"final_paths={_avg_v74(final_path_counts):.2f}, "
            f"cfg={_avg_v74(cfg_before_counts):.2f}->{_avg_v74(cfg_after_counts):.2f}, "
            f"anchor={_avg_v74(anchor_after_counts):.2f}, "
            f"cov_avg={cov_stat['avg']:.2%}, cov_med={cov_stat['median']:.2%}"
        )

        overall_input += input_cnt
        overall_success += success_cnt
        overall_drop += drop_cnt
        overall_cov.extend(covs)
        overall_low_items.extend(low_items)
        overall_retry_used += retry_used_count
        overall_num_paths_sum += sum(num_paths_list)
        overall_num_paths_cnt += len(num_paths_list)
        for k, v in drop_reasons.items():
            overall_drop_reasons[k] += v

    final_report["overall"] = {
        "input_total": overall_input,
        "cfg_success_total": overall_success,
        "raw_fallback_needed_total": overall_drop,
        "raw_fallback_rate": (overall_drop / overall_input) if overall_input else 0.0,
        "drop_reasons": dict(overall_drop_reasons),
        "coverage": summarize_coverages(overall_cov),
        "retry_used_count": overall_retry_used,
        "avg_num_paths": (
            overall_num_paths_sum / overall_num_paths_cnt if overall_num_paths_cnt else 0.0
        ),
        "low_coverage_threshold": LOW_COVERAGE_THRESHOLD,
        "low_coverage_count": len(overall_low_items),
        "strict_single_function": True,
    }

    report_json = os.path.join(OUTPUT_BASE_DIR, "full_pipeline_report_v7_4_pmcl_diverse.json")
    with open(report_json, "w", encoding="utf-8") as f:
        json.dump(final_report, f, ensure_ascii=False, indent=2)

    low_csv = os.path.join(OUTPUT_BASE_DIR, "low_coverage_idx_v7_4_pmcl_diverse.csv")
    with open(low_csv, "w", encoding="utf-8") as f:
        f.write("split,idx,coverage\n")
        for x in overall_low_items:
            f.write(f"{x['split']},{x['idx']},{float(x['coverage']):.6f}\n")

    logger.info(
        f"[overall] input={overall_input}, cfg_success={overall_success}, "
        f"raw_fallback_needed={overall_drop} "
        f"({(overall_drop/overall_input if overall_input else 0):.2%}), "
        f"elapsed={time.time()-t0:.2f}s"
    )
    logger.info(f"report_json={report_json}")


if __name__ == "__main__":
    if sys.platform.startswith("linux"):
        try:
            mp.set_start_method("spawn", force=True)
        except RuntimeError:
            pass
    main()
