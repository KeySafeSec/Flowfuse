# FlowFuse v7.3 — current-function vulnerability-aware GA path sampling.
# Counterpart-derived diff nodes remain forbidden; PMCL supervision is attached
# only after candidate path generation by data_process_single.py.

# c_cfg.py (FlowFuse - DFG-Guided Optimization)

import networkx as nx
import random
from typing import List, Tuple, Optional, Set, Dict
import logging
import sys
import tree_sitter
import os
import re
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.animation import FuncAnimation
from matplotlib.patches import FancyArrowPatch
import matplotlib.animation as animation
from graphviz import Digraph

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('genetic_path_finder.log', mode='w'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


DEEPFA_PATTERNS = {
    'pointers': re.compile(r'(\*|->|&)'),
    'arrays': re.compile(r'\[[^\]]*\]'),
    'arithmetic': re.compile(r'(\+\+|--|\+=|-=|\*=|/=|%=)'),
    'sensitive_calls': {
        'strcpy', 'strcat', 'sprintf', 'vsprintf', 'gets', 'scanf',
        'sscanf', 'fscanf', 'vscanf', 'vsscanf', 'vfscanf', 'memcpy',
        'memmove', 'malloc', 'calloc', 'realloc', 'free', 'system',
        'exec', 'execl', 'execlp', 'execv', 'execvp', 'popen', 'access',
        'read', 'recv', 'fgets', 'getenv'
    },
    'dangerous_write': re.compile(r'\b(memcpy|memmove|strcpy|strcat|sprintf|vsprintf)\b'),
    'taint_source': re.compile(r'\b(gets|scanf|recv|read|fgets|getenv|argv)\b'),
    'taint_sink': re.compile(r'\b(system|popen|exec\w*|strcpy|memcpy|sprintf)\b'),
    'size_hint': re.compile(r'\b(sizeof\s*\(|strlen\s*\(|strn?cpy|snprintf)\b'),
    'defense_guard': re.compile(
        r'\b(?:if|while|assert|BUG_ON|WARN_ON)\s*\([^\n]*(?:NULL|nullptr|==|!=|<=|>=|<|>|sizeof|len|size|count|index|idx|bound)',
        re.IGNORECASE
    ),
    'lifecycle': re.compile(r'\b(malloc|calloc|realloc|free|delete|new)\b', re.IGNORECASE),
}
sensitive_calls_regex = re.compile(r'\b(' + '|'.join(DEEPFA_PATTERNS['sensitive_calls']) + r')\b')
NUM_HEURISTIC_FEATURES = 8


def score_line_risk(line: str) -> float:
    if not line:
        return 0.0
    s = line.strip()
    score = 0.0
    if DEEPFA_PATTERNS['pointers'].search(s): score += 1.0
    if DEEPFA_PATTERNS['arrays'].search(s): score += 0.8
    if DEEPFA_PATTERNS['arithmetic'].search(s): score += 0.5
    if sensitive_calls_regex.search(s): score += 2.0
    if DEEPFA_PATTERNS['dangerous_write'].search(s): score += 2.2
    if DEEPFA_PATTERNS['taint_source'].search(s): score += 1.6
    if DEEPFA_PATTERNS['taint_sink'].search(s): score += 1.8
    if DEEPFA_PATTERNS['size_hint'].search(s): score += 0.7
    if DEEPFA_PATTERNS['defense_guard'].search(s): score += 2.4
    if DEEPFA_PATTERNS['lifecycle'].search(s): score += 1.4
    if re.search(r'\b(?:len|size|count|index|idx)\b[^;]*(?:\+|-|\*|/|<<|>>)', s, re.IGNORECASE):
        score += 1.0
    return score


def analyze_path_for_features(path_as_code_strings: List[str]) -> List[int]:
    if not path_as_code_strings:
        return [0] * NUM_HEURISTIC_FEATURES
    full_path_code = "\n".join(path_as_code_strings)
    return [
        1 if DEEPFA_PATTERNS['pointers'].search(full_path_code) else 0,
        1 if DEEPFA_PATTERNS['arrays'].search(full_path_code) else 0,
        1 if DEEPFA_PATTERNS['arithmetic'].search(full_path_code) else 0,
        1 if sensitive_calls_regex.search(full_path_code) else 0,
        1 if DEEPFA_PATTERNS['dangerous_write'].search(full_path_code) else 0,
        1 if DEEPFA_PATTERNS['taint_source'].search(full_path_code) else 0,
        1 if DEEPFA_PATTERNS['taint_sink'].search(full_path_code) else 0,
        1 if DEEPFA_PATTERNS['size_hint'].search(full_path_code) else 0,
    ]


def _normalize_symbol(name: str) -> str:
    if not name:
        return ""
    n = name.strip()
    n = n.split("::")[-1]
    n = re.sub(r'<.*?>', '', n)
    n = re.sub(r'^[\*&\s]+', '', n)
    n = re.sub(r'\s+', '', n)
    return n


def _get_identifier_text(node):
    if node is None:
        return None
    if getattr(node, "type", None) == "identifier":
        try:
            return node.text.decode("utf8", errors="ignore").strip()
        except Exception:
            return None
    for c in getattr(node, "children", []):
        name = _get_identifier_text(c)
        if name:
            return name
    return None


# ==============================================================================
# GeneticPathFinder - 【FlowFuse核心】DFG感知的遗传算法路径采样
# ==============================================================================
class GeneticPathFinder:
    def __init__(
        self,
        graph: nx.DiGraph,
        start_node: int,
        end_nodes: list,
        cross_call_edges: set,
        source_lines: list,
        dfg_edges: set = None,
        diff_nodes: set = None,  # ← 新增参数
    ):
        self.graph = graph
        self.start_node = start_node
        self.end_nodes = end_nodes if end_nodes else []
        self.cross_call_edges = cross_call_edges
        self.source_lines = source_lines

        self.dfg_edges_full = dfg_edges if dfg_edges else set()
        self.dfg_edge_pairs = {(d, u) for d, u, _ in self.dfg_edges_full} if self.dfg_edges_full else set()
        self.dfg_by_var: dict = {}
        if self.dfg_edges_full:
            for d, u, v in self.dfg_edges_full:
                self.dfg_by_var.setdefault(v, []).append((d, u))

        # Strict protocol: counterpart-derived diff nodes are forbidden.
        if diff_nodes:
            raise RuntimeError(
                "STRICT PROTOCOL VIOLATION: GeneticPathFinder received diff_nodes"
            )

        self.all_nodes = set(self.graph.nodes())
        self.covered_global = set()
        self.covered_dfg_global = set()
        self.population = []
        self.population_tuples = set()
        self.current_mutation_rate = 0.25
        self.logger = logging.getLogger("GeneticPathFinder")
        self.logger.setLevel(logging.INFO)

        self.fitness_cache = {}
        self.node_risk_cache = {}
        self.path_risk_cache = {}


    def _calculate_heuristic_risk_score(self, path: list) -> float:
        if not path:
            return 0.0
        t = tuple(path)
        if t in self.path_risk_cache:
            return self.path_risk_cache[t]

        total = 0.0
        codes = []
        for node_id in path:
            if node_id in self.node_risk_cache:
                total += self.node_risk_cache[node_id]
                if 1 <= node_id <= len(self.source_lines):
                    codes.append(self.source_lines[node_id - 1])
                continue
            line = self.source_lines[node_id - 1] if 1 <= node_id <= len(self.source_lines) else ""
            r = score_line_risk(line)
            self.node_risk_cache[node_id] = r
            total += r
            codes.append(line)

        full = "\n".join(codes)
        if DEEPFA_PATTERNS['taint_source'].search(full) and DEEPFA_PATTERNS['taint_sink'].search(full):
            total += 4.0

        # Path-level interaction is more informative than isolated keywords.
        danger_pos = [i for i, c in enumerate(codes)
                      if DEEPFA_PATTERNS['dangerous_write'].search(c)
                      or DEEPFA_PATTERNS['lifecycle'].search(c)
                      or DEEPFA_PATTERNS['taint_sink'].search(c)]
        guard_pos = [i for i, c in enumerate(codes) if DEEPFA_PATTERNS['defense_guard'].search(c)]
        if danger_pos:
            if any(g < d for g in guard_pos for d in danger_pos):
                total += 3.5  # guarded-danger relation: discriminative safety evidence
            elif not guard_pos:
                total += 2.0  # unguarded danger: discriminative vulnerability evidence

        self.path_risk_cache[t] = total
        return total

    def calculate_fitness(self, individual: list) -> float:
        """Single-function path fitness: CFG novelty + DFG + intrinsic risk.

        No vulnerable/patch diff information is permitted here. The scales are
        explicit because the three component scores have different magnitudes.
        """
        path_tuple = tuple(individual)
        if path_tuple in self.fitness_cache:
            return self.fitness_cache[path_tuple]
        if not individual:
            return -1000.0

        path_node_set = set(individual)

        # 1) Prefer paths that add previously unseen CFG nodes.
        new_nodes = path_node_set - self.covered_global
        coverage_score = len(new_nodes) * 30.0

        # 2) Reward real inter-procedural calls when the caller enabled them.
        path_edges = set(zip(individual[:-1], individual[1:]))
        cross_hits = len(self.cross_call_edges.intersection(path_edges)) if self.cross_call_edges else 0
        cross_call_bonus = 40.0 * cross_hits

        # 3) Reward newly covered Def-Use relations; repeated DFG edges get only
        # a small diversity-maintenance score.
        dfg_hits = 0
        new_dfg_hits = 0
        if self.dfg_edge_pairs:
            for d, u in self.dfg_edge_pairs:
                if d in path_node_set and u in path_node_set:
                    dfg_hits += 1
                    if (d, u) not in self.covered_dfg_global:
                        new_dfg_hits += 1
        dfg_score = new_dfg_hits * 50.0 + (dfg_hits - new_dfg_hits) * 5.0

        # 4) Penalize redundant/needlessly long paths.
        redundancy_penalty = sum(1 for n in individual if n in self.covered_global) * 1.5
        length_penalty = len(individual) * 0.35

        # 5) Intrinsic source-code risk is allowed: it depends only on the
        # current function (e.g., risky APIs / pointer-memory patterns).
        heuristic_risk_score = self._calculate_heuristic_risk_score(individual)

        final_fitness = (
            0.75 * coverage_score
            + cross_call_bonus
            + 0.90 * dfg_score
            + 11.0 * heuristic_risk_score
            - redundancy_penalty
            - length_penalty
        )
        self.fitness_cache[path_tuple] = final_fitness
        return final_fitness

    def evolve(self, generations=10, elite_size=2):
        if not self.population:
            return

        self.fitness_cache.clear()

        pop_with_fitness = sorted(
            [(p, self.calculate_fitness(p)) for p in self.population],
            key=lambda x: x[1], reverse=True
        )

        for gen in range(generations):
            elites = [p for p, f in pop_with_fitness[:elite_size]]

            children = []
            while len(children) < len(self.population) - len(elites):
                parents = self.roulette_wheel_selection(pop_with_fitness, 2)
                if not parents:
                    continue
                p1, p2 = parents[0], parents[1]

                child = self.crossover(p1, p2)
                if not child:
                    continue

                child = self.mutate(child)
                child = self.local_search(child)

                if child and self.validate_path(child):
                    children.append(child)

            next_pop = elites + children
            pop_with_fitness = []
            for ind in next_pop:
                fitness = self.calculate_fitness(ind)
                pop_with_fitness.append((ind, fitness))

            pop_with_fitness.sort(key=lambda x: x[1], reverse=True)
            self.population = [p for p, f in pop_with_fitness]

    def roulette_wheel_selection(self, pop_with_fitness, num_to_select):
        total_fitness = sum(f for p, f in pop_with_fitness if f > 0)
        if total_fitness <= 0:
            return [p for p, f in random.sample(pop_with_fitness, min(num_to_select, len(pop_with_fitness)))]

        selected = []
        for _ in range(num_to_select):
            pick = random.uniform(0, total_fitness)
            current = 0
            for p, f in pop_with_fitness:
                if f > 0:
                    current += f
                    if current > pick:
                        selected.append(p)
                        break
        return selected if selected else [pop_with_fitness[0][0]] * num_to_select

    def initialize_population(self, population_size=50):
        """
        初始化种群，优先级：
        1. 跨函数调用种子（如启用）
        2. 出口最短路径种子
        3. 当前函数内的高风险语句种子
        4. DFG Def-Use 链种子
        5. 随机补齐
        """
        size = population_size
        self.population = []
        self.population_tuples = set()

        # B) 跨函数种子
        cross_call_paths_to_try = list(self.cross_call_edges)[:2]
        for u_call, v_entry in cross_call_paths_to_try:
            if len(self.population) >= size:
                break
            try:
                path_to_call = nx.shortest_path(self.graph, self.start_node, u_call)
                if self.end_nodes:
                    paths_to_ends = [
                        nx.shortest_path(self.graph, v_entry, end)
                        for end in self.end_nodes
                        if nx.has_path(self.graph, v_entry, end)
                    ]
                    if paths_to_ends:
                        path_from_callee = min(paths_to_ends, key=len)
                        candidate = path_to_call[:-1] + path_from_callee
                        if self.validate_path(candidate) and tuple(candidate) not in self.population_tuples:
                            self.population.append(candidate)
                            self.population_tuples.add(tuple(candidate))
            except nx.NetworkXNoPath:
                continue

        # C) 出口最短路径种子
        endpoints_to_try = random.sample(self.end_nodes, min(len(self.end_nodes), 2)) if self.end_nodes else []
        for end_node in endpoints_to_try:
            if len(self.population) >= size:
                break
            try:
                candidate = nx.shortest_path(self.graph, self.start_node, end_node)
                if self.validate_path(candidate) and tuple(candidate) not in self.population_tuples:
                    self.population.append(candidate)
                    self.population_tuples.add(tuple(candidate))
            except nx.NetworkXNoPath:
                continue

        # D) 高风险种子
        risk_nodes = []
        for n in self.graph.nodes():
            if 1 <= n <= len(self.source_lines):
                r = score_line_risk(self.source_lines[n - 1])
                if r >= 2.0:
                    risk_nodes.append((n, r))
        risk_nodes = [n for n, _ in sorted(risk_nodes, key=lambda x: -x[1])[:10]]

        for rn in risk_nodes:
            if len(self.population) >= size:
                break
            try:
                if not nx.has_path(self.graph, self.start_node, rn):
                    continue
                p1 = nx.shortest_path(self.graph, self.start_node, rn)
                candidate = p1
                if self.end_nodes:
                    reachable_ends = [e for e in self.end_nodes if nx.has_path(self.graph, rn, e)]
                    if reachable_ends:
                        p2 = min(
                            (nx.shortest_path(self.graph, rn, e) for e in reachable_ends),
                            key=len
                        )
                        candidate = p1[:-1] + p2
                if self.validate_path(candidate) and tuple(candidate) not in self.population_tuples:
                    self.population.append(candidate)
                    self.population_tuples.add(tuple(candidate))
            except Exception:
                pass

        # E) DFG Def-Use 链种子
        dfg_vars_sorted = sorted(
            self.dfg_by_var.keys(),
            key=lambda v: len(self.dfg_by_var[v]),
            reverse=True
        )[:10]

        for var in dfg_vars_sorted:
            def_use_pairs = self.dfg_by_var[var]
            for def_line, use_line in def_use_pairs:
                if len(self.population) >= size:
                    break
                if not (self.graph.has_node(def_line) and self.graph.has_node(use_line)):
                    continue
                try:
                    path1 = nx.shortest_path(self.graph, self.start_node, def_line)
                    path2 = nx.shortest_path(self.graph, def_line, use_line)
                    tail = []
                    if self.end_nodes:
                        ends_ok = [e for e in self.end_nodes if nx.has_path(self.graph, use_line, e)]
                        if ends_ok:
                            tail = nx.shortest_path(
                                self.graph, use_line,
                                min(ends_ok, key=lambda e: nx.shortest_path_length(self.graph, use_line, e))
                            )
                    candidate = path1[:-1] + path2[:-1] + tail
                    if candidate and self.validate_path(candidate) and tuple(candidate) not in self.population_tuples:
                        self.population.append(candidate)
                        self.population_tuples.add(tuple(candidate))
                except (nx.NetworkXNoPath, nx.NodeNotFound):
                    continue
            if len(self.population) >= size:
                break

        # F) 随机补齐
        attempts = 0
        max_attempts = size * 5
        while len(self.population) < size and attempts < max_attempts:
            candidate = self.random_dfs_optimized(self.start_node, max_depth=50)
            if candidate and tuple(candidate) not in self.population_tuples:
                self.population.append(candidate)
                self.population_tuples.add(tuple(candidate))
            attempts += 1

        self.logger.info(f"种群初始化完成，共 {len(self.population)} 条路径")

    def random_dfs_optimized(self, start_node: int, max_depth: int = 50) -> Optional[List[int]]:
        path = [start_node]
        visited_on_path = {start_node}
        for _ in range(max_depth):
            current_node = path[-1]
            if self.end_nodes and current_node in self.end_nodes:
                break
            successors = list(self.graph.successors(current_node))
            if not successors:
                break
            unvisited_successors = [n for n in successors if n not in visited_on_path]
            if unvisited_successors:
                next_node = random.choice(unvisited_successors)
            else:
                if random.random() < 0.1 and len(path) > 1:
                    popped = path.pop()
                    visited_on_path.remove(popped)
                    continue
                else:
                    next_node = random.choice(successors)
            path.append(next_node)
            visited_on_path.add(next_node)
        if self.validate_path(path):
            return path
        return None

    def validate_path(self, path: List[int]) -> bool:
        if not path or not isinstance(path, list):
            return False
        for i in range(len(path) - 1):
            if not self.graph.has_edge(path[i], path[i + 1]):
                return False
        return True

    def crossover(self, parent1: List[int], parent2: List[int]) -> Optional[List[int]]:
        common_nodes = list(set(parent1) & set(parent2))
        if len(common_nodes) < 2:
            return random.choice([parent1, parent2])
        crossover_point = random.choice(common_nodes)
        try:
            idx1 = parent1.index(crossover_point)
            idx2 = parent2.index(crossover_point)
            child = parent1[:idx1] + parent2[idx2:]
            return child if self.validate_path(child) else None
        except ValueError:
            return None

    def mutate(self, path: List[int]) -> List[int]:
        if not path or random.random() > self.current_mutation_rate:
            return path
        uncovered = list(self.all_nodes - self.covered_global - set(path))
        if uncovered and random.random() < 0.5:
            try:
                mutation_point_idx = random.randint(0, len(path) - 1)
                start_node = path[mutation_point_idx]
                target_node = random.choice(uncovered)
                bridge = nx.shortest_path(self.graph, start_node, target_node)
                new_path = path[:mutation_point_idx] + bridge
                for _ in range(10):
                    successors = list(self.graph.successors(new_path[-1]))
                    if not successors:
                        break
                    new_path.append(random.choice(successors))
                if self.validate_path(new_path):
                    return new_path
            except (nx.NetworkXNoPath, nx.NodeNotFound):
                pass
        if len(path) > 2:
            idx = random.randint(1, len(path) - 1)
            u, v = path[idx - 1], path[idx]
            successors_of_u = list(self.graph.successors(u))
            if len(successors_of_u) > 1:
                options = [n for n in successors_of_u if n != v]
                if options:
                    inserted_node = random.choice(options)
                    try:
                        bridge_to_v = nx.shortest_path(self.graph, inserted_node, v)
                        mutated_path = path[:idx] + bridge_to_v
                        if self.validate_path(mutated_path):
                            return mutated_path
                    except (nx.NetworkXNoPath, nx.NodeNotFound):
                        pass
        return path

    def local_search(self, path: List[int]) -> List[int]:
        if not path:
            return []
        optimized_path = path.copy()
        for _ in range(15):
            current_tip = optimized_path[-1]
            try:
                bfs_tree = nx.bfs_tree(self.graph, current_tip, depth_limit=5)
                found_target = False
                for node in bfs_tree:
                    if node not in self.covered_global and node not in optimized_path:
                        bridge = nx.shortest_path(self.graph, current_tip, node)
                        optimized_path.extend(bridge[1:])
                        found_target = True
                        break
                if not found_target:
                    break
            except nx.NodeNotFound:
                break
        return optimized_path



# ==============================================================================
# ---  C_CFG CLASS: Your original code, with get_allpath tuned for speed ---
# ==============================================================================
class C_CFG:
    def __init__(self, source_code=None):
        # ... (您的 __init__ 函数保持不变) ...
        self.finlineno = []
        self.firstlineno = 1
        self.G = nx.DiGraph()
        self.coverage_threshold = 0.98
        self.edge_penalty = 1.5
        self.all_paths = []
        self.finder = None
        self.dece_node = []
        self.circle = []
        self.line_number = []
        self.current_scope = []
        self.logger = logging.getLogger(self.__class__.__name__)
        self.source_lines = source_code.splitlines() if source_code else []
        self.max_line = 0
        self.current_loop = None
        self.loop_stack = []
        self.loop_optimization = {
            'min_self_loops': True,
            'allow_types': {'while', 'do'},
            'infinite_loop_marks': {'conditions': ["1", "true", "!0"], 'update_clause': None}
        }
        self.func_entry_map: dict[str, int] = {}
        self.cross_call_edges: set[Tuple[int, int]] = set()
        # ===== DFG: Intra-procedural Def-Use =====
        self.last_def: dict[str, int] = {}           # var -> last def line
        self.var_defs: dict[int, set] = {}           # line -> {vars}
        self.var_uses: dict[int, set] = {}           # line -> {vars}
        self.dfg_edges: set[Tuple[int, int, str]] = set()

    # ✨✨✨ START OF SPEED OPTIMIZATIONS ✨✨✨
    def get_allpath(self,
                    max_paths=10,
                    generations=10,
                    population_size=25,
                    coverage_threshold=0.98,
                    diff_nodes: set = None
                    ) -> Tuple[int, List[List[int]], int, float]:
        """Generate diverse GA paths using current-function information only.

        ``diff_nodes`` is retained only so old callers fail loudly instead of
        silently leaking pair information.
        """
        if diff_nodes:
            raise RuntimeError(
                "STRICT PROTOCOL VIOLATION: C_CFG.get_allpath received diff_nodes"
            )

        all_paths = []
        unique_paths_set = set()
        covered_nodes = {self.firstlineno} if self.G.has_node(self.firstlineno) else set()
        covered_dfg_edges = set()
        all_nodes_in_graph = {n for n in self.G.nodes() if n != 0}
        total_nodes = len(all_nodes_in_graph)

        if not total_nodes or not self.G.has_node(self.firstlineno):
            self.logger.warning("CFG为空或缺少起始节点，无法生成路径。")
            return 0, [], total_nodes, 0.0

        self.logger.info("Initializing STRICT GeneticPathFinder for iterative search...")
        finder = GeneticPathFinder(
            self.G, self.firstlineno, self.finlineno,
            self.cross_call_edges, self.source_lines,
            dfg_edges=self.dfg_edges,
            diff_nodes=None,
        )

        finder.initialize_population(population_size=population_size)
        if not finder.population:
            self.logger.error("Failed to initialize a diverse population.")
            return 0, [], total_nodes, 0.0

        no_progress_count = 0
        max_no_progress = 5

        while len(all_paths) < max_paths:
            coverage_ratio = len(covered_nodes) / total_nodes if total_nodes > 0 else 0.0
            dfg_coverage_ratio = (
                len(covered_dfg_edges) / len(self.dfg_edges) if self.dfg_edges else 0.0
            )
            self.logger.info(
                f"--- Path {len(all_paths) + 1}/{max_paths} | "
                f"CFG: {coverage_ratio:.2%} | DFG: {dfg_coverage_ratio:.2%} ---"
            )

            if coverage_ratio >= coverage_threshold or no_progress_count >= max_no_progress:
                self.logger.info(
                    f"Terminating. Reason: "
                    f"{'Coverage met' if coverage_ratio >= coverage_threshold else 'Stalled'}."
                )
                break

            finder.covered_global = covered_nodes.copy()
            finder.covered_dfg_global = covered_dfg_edges.copy()
            finder.fitness_cache.clear()
            finder.evolve(
                generations=generations,
                elite_size=max(2, int(population_size * 0.1)),
            )

            if not finder.population:
                self.logger.error("Population collapsed during evolution.")
                break

            best_path = max(finder.population, key=lambda p: finder.calculate_fitness(p))
            newly_covered = set(best_path) - covered_nodes
            new_covered_dfg = set()
            path_node_set = set(best_path)
            for d, u, _ in self.dfg_edges:
                if d in path_node_set and u in path_node_set and (d, u) not in covered_dfg_edges:
                    new_covered_dfg.add((d, u))

            if not newly_covered and not new_covered_dfg:
                no_progress_count += 1
                self.logger.warning(
                    f"No new CFG/DFG coverage. Stall: {no_progress_count}/{max_no_progress}."
                )
                finder.current_mutation_rate = min(0.5, finder.current_mutation_rate * 1.2)
            else:
                no_progress_count = 0
                finder.current_mutation_rate = 0.25

            if tuple(best_path) not in unique_paths_set:
                self.logger.info(
                    f"New path: len={len(best_path)}, "
                    f"new_CFG={len(newly_covered)}, new_DFG={len(new_covered_dfg)}"
                )
                all_paths.append(best_path)
                unique_paths_set.add(tuple(best_path))
                covered_nodes.update(newly_covered)
                covered_dfg_edges.update(new_covered_dfg)
            else:
                self.logger.info("Duplicate path, forcing mutation.")
                for i in range(len(finder.population)):
                    if random.random() < 0.8:
                        finder.population[i] = finder.mutate(finder.population[i])

        final_coverage = len(covered_nodes) / total_nodes if total_nodes > 0 else 0.0
        final_dfg_coverage = (
            len(covered_dfg_edges) / len(self.dfg_edges) if self.dfg_edges else 0.0
        )
        self.all_paths = all_paths
        self.dfg_coverage_ratio = final_dfg_coverage
        self.logger.info(
            f"Path generation complete. Found {len(all_paths)} paths with "
            f"CFG coverage {final_coverage:.2%}, DFG coverage {final_dfg_coverage:.2%}"
        )
        return len(all_paths), all_paths, total_nodes - len(covered_nodes), final_coverage

    # ✨✨✨ END OF SPEED OPTIMIZATIONS ✨✨✨
    def _is_effective_code_line(self, line_no: int) -> bool:
        """判断该行是否是可执行语句候选行"""
        if line_no <= 0 or line_no > len(self.source_lines):
            return False
        s = self.source_lines[line_no - 1].strip()
        if not s:
            return False

        # 纯符号行
        if s in {"{", "}", ";", "(", ")", ","}:
            return False

        # 预处理行（可按需求保留）
        if s.startswith("#"):
            return False

        # 只有括号/分号组合
        if re.fullmatch(r"[\{\}\(\);\s]+", s):
            return False

        # 仅标签行（可选）
        if re.fullmatch(r"[A-Za-z_]\w*\s*:\s*", s):
            return False

        return True

    def _prune_non_effective_nodes(self):
        """删除无意义节点并重连前后继"""
        to_remove = []
        for n in list(self.G.nodes()):
            if n == 0:
                to_remove.append(n)
                continue
            if not self._is_effective_code_line(n):
                to_remove.append(n)

        for n in to_remove:
            if n not in self.G:
                continue
            preds = list(self.G.predecessors(n))
            succs = list(self.G.successors(n))
            # 旁路重连
            for p in preds:
                for s in succs:
                    if p != s and not self.G.has_edge(p, s):
                        self.G.add_edge(p, s, weight=1, label="bypass_non_effective")
            self.G.remove_node(n)

    def _finalize_function_exit(self):
        """统一函数出口：return/自然落空都汇聚到单一exit节点"""
        if len(self.G.nodes()) == 0:
            self.finlineno = []
            return

        exit_node = max(self.G.nodes()) + 1
        self.G.add_node(exit_node)

        # 取已标注return出口的源节点
        return_src = [u for u, v, d in self.G.edges(data=True) if d.get("label") == "return_exit"]

        # 清旧 return_exit
        for u, v, d in list(self.G.edges(data=True)):
            if d.get("label") == "return_exit":
                self.G.remove_edge(u, v)

        if return_src:
            for u in return_src:
                self.G.add_edge(u, exit_node, weight=1, label="return_exit")
        else:
            # 无return：所有尾节点连到exit
            tails = [n for n in self.G.nodes() if n != exit_node and self.G.out_degree(n) == 0]
            for t in tails:
                self.G.add_edge(t, exit_node, weight=1, label="implicit_exit")

        self.finlineno = [exit_node]

    # --- 以下为您原来的代码，保持不变 ---
    def run(self, root):
        code_text = root.text.decode('utf8')
        self.max_line = len(code_text.split('\n'))
        self.clean_code = root
        self.ast = root  # <- 加这个
        self.finlineno.append(root.end_point[0] + 1)
        self.ast_visit(root)

    def parse_ast_file(self, ast_code):
        self.run(ast_code)
        self._prune_non_effective_nodes()
        self._finalize_function_exit()
        return ast_code

    def parse_ast(self, source_ast):
        self.run(source_ast)
        self._prune_non_effective_nodes()
        self._finalize_function_exit()
        return source_ast

    def get_source(self, fn):
        ''' Return the entire contents of the file whose name is给定. '''
        try:
            f = open(fn, 'r')
            s = f.read()
            f.close()
            return s
        except IOError:
            return ''

    def ast_visit(self, node):
        method = getattr(self, "visit_" + node.type, None)
        if method:
            return method(node)
        else:
            # 如果没有专门的 visit_* 方法，就继续遍历子节点
            return self.visit_piece(node)
    # =========================
    # DFG helpers
    # =========================
    def extract_identifiers(self, node):
        ids = set()
        if node is None: return ids
        ntype = getattr(node, "type", "")

        # --- 1. 处理成员访问 (a.b.c) ---
        # 在你的基础上增加：把完整路径也存进去
        if ntype in ("field_expression", "member_expression"):
            try:
                full_path = node.text.decode("utf8", errors="ignore").strip()
                # 同样经过你的清洗逻辑
                full_path = _normalize_symbol(full_path)
                if full_path: ids.add(full_path)
            except:
                pass
            # 继续向下递归，确保提取出底层的变量名 (如 'a')
            for c in node.children:
                if c.type not in (".", "->", "field_identifier"):
                    ids |= self.extract_identifiers(c)
            return ids

        # --- 2. 处理函数调用 (保留你的过滤逻辑) ---
        if ntype == "call_expression":
            for c in node.children:
                if c.type == "argument_list":
                    ids |= self.extract_identifiers(c)
                elif c.type in ("field_expression", "member_expression"):
                    # 提取对象，跳过方法名
                    obj_node = c.child_by_field_name('argument') or c.child_by_field_name('object')
                    if obj_node:
                        ids |= self.extract_identifiers(obj_node)
                elif c.type == "pointer_expression":
                    ids |= self.extract_identifiers(c)
            return ids

        # --- 3. 基础标识符 (保留你的清洗逻辑) ---
        if ntype in ("identifier", "field_identifier"):
            try:
                name = node.text.decode("utf8", errors="ignore").strip()
                name = _normalize_symbol(name)
                if name and re.match(r'^[A-Za-z_]\w*$', name):
                    ids.add(name)
            except Exception:
                pass
            return ids

        # 4. 通用递归
        for c in node.children:
            ids |= self.extract_identifiers(c)
        return ids

    def add_dfg_edge(self, var_name: str, current_line: int):
        """从最近定义连到当前使用：Def -> Use"""
        if not var_name:
            return
        v = _normalize_symbol(var_name)
        if not v:
            return

        self.var_uses.setdefault(current_line, set()).add(v)

        if v in self.last_def:
            dline = self.last_def[v]
            if dline != current_line and self.G.has_node(dline) and self.G.has_node(current_line):
                self.G.add_edge(dline, current_line, weight=0, label='DFG', var=v)
                self.dfg_edges.add((dline, current_line, v))

    def record_def(self, var_name: str, line_no: int):
        v = _normalize_symbol(var_name)
        if not v:
            return
        self.var_defs.setdefault(line_no, set()).add(v)
        self.last_def[v] = line_no

    def annotate_code_line_with_du(self, line_no: int, raw: str):
        defs = sorted(self.var_defs.get(line_no, set()))
        uses = sorted(self.var_uses.get(line_no, set()))
        tags = []
        if defs:
            tags.append(f"<DEF:{','.join(defs)}>")
        if uses:
            tags.append(f"<USE:{','.join(uses)}>")
        return f"{raw} {' '.join(tags)}".strip() if tags else raw

    def visit_program(self, node):
        self.finlineno.append(node.children[-1].end_point[0] + 1)
        for index, z in enumerate(node.children):
            start = z.start_point[0] + 1
            end = min(z.end_point[0] + 2, self.max_line)  # 确保不超过实际行数
            for i in range(start, end):
                self.G.add_node(i)
            if self.firstlineno > z.start_point[0] + 1:
                self.firstlineno = z.start_point[0] + 1

            if z.type == "compound_statement":
                if index == len(node.children) - 1:
                    self.finlineno.append(z.end_point[0] + 1)
                self.ast_visit(z)
            elif z.type == "local_variable_declaration":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_translation_unit(self, node):
        self.finlineno.append(node.children[-1].end_point[0] + 1)
        last_child = node.children[-1]
        termination_line = min(last_child.end_point[0] + 1, self.max_line)
        self.finlineno.append(termination_line)
        self.G.add_node(termination_line)
        for index, z in enumerate(node.children):
            for i in range(z.start_point[0] + 1, z.end_point[0] + 2):
                self.G.add_node(i)
            if self.firstlineno > z.start_point[0] + 1:
                self.firstlineno = z.start_point[0] + 1
            if z.type == "function_definition":
                if index == len(node.children) - 1:
                    self.finlineno.append(z.end_point[0] + 1)
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_function_definition(self, node):
        try:
            declarator = next((c for c in node.children if c.type == "function_declarator"), None)
            func_name_raw = _get_identifier_text(declarator) or f"<anon@L{node.start_point[0] + 1}>"
            func_name = _normalize_symbol(func_name_raw)
            entry_line = node.start_point[0] + 1

            if func_name:
                self.func_entry_map[func_name] = entry_line
                self.logger.debug(f"记录函数定义: {func_name} @ 行 {entry_line}")
        except Exception as e:
            self.logger.warning(f"提取函数名失败: {e}")

        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_compound_statement(self, node):
        for index, z in enumerate(node.children):
            if z.type == "for_statement":
                self.ast_visit(z)
            elif z.type == "enhanced_for_statement":
                self.ast_visit(z)
            elif z.type == "while_statement":
                self.ast_visit(z)
            elif z.type == "do_statement":
                self.ast_visit(z)
            elif z.type == "try_with_resources_statement":
                self.ast_visit(z)
            elif z.type == "assert_statement":
                self.ast_visit(z)
            elif z.type == "switch_statement":
                self.ast_visit(z)
            elif z.type == "case_statement":
                # case 是在 switch 里特殊处理
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.ast_visit(z)
            elif z.type == "switch_block":
                self.ast_visit(z)
            elif z.type == "switch_block_statement_group":
                self.ast_visit(z)
            elif z.type == "labeled_statement":
                self.ast_visit(z)
            elif z.type == "continue_statement":
                self.ast_visit(z)
            elif z.type == "try_statement":
                self.ast_visit(z)
            elif z.type == "throw_statement":
                self.ast_visit(z)
            elif z.type == "if_statement":
                self.ast_visit(z)
            elif z.type == "synchronized_statement":
                self.ast_visit(z)
            elif z.type == "expression_statement":
                self.ast_visit(z)
            elif z.type == "local_variable_declaration":
                self.ast_visit(z)
            elif z.type == "return_statement":
                self.ast_visit(z)
            elif z.type == "compound_statement":
                self.ast_visit(z)
            elif z.type == "parenthesized_expression":
                self.ast_visit(z)
            elif z.type == "ERROR":
                self.ast_visit(z)
            elif z.type == "break_statement":
                self.ast_visit(z)
            elif z.type == "class_declaration":
                self.ast_visit(z)
            elif z.type == "declaration":
                self.ast_visit(z)
            elif z.type == "function_declarator":
                self.ast_visit(z)
            elif z.type == "}":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == "{":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == ";":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            else:
                self.visit_piece(z)

        if len(node.children) > 0 and node.children[0].type == "{":
            self.G.add_edge(node.children[0].start_point[0] + 1, node.children[0].start_point[0] + 2, weight=1)
        if len(node.children) > 0 and node.children[-1].type == "}":
            self.G.add_edge(node.children[-1].start_point[0], node.children[-1].start_point[0] + 1, weight=1)

    # ===== 新增：统一名字提取与归一化 =====

    def visit_piece(self, node):
        # ---- DFG优先分发 ----
        if node.type in {"assignment_expression", "init_declarator", "update_expression"}:
            self.ast_visit(node)
            return

        if node.type == "call_expression":
            try:
                caller_line = node.start_point[0] + 1
                call_name_raw = _get_identifier_text(node)
                call_name = _normalize_symbol(call_name_raw) if call_name_raw else None

                # 跨函数调用边
                if call_name and call_name in self.func_entry_map:
                    callee_entry = self.func_entry_map[call_name]
                    self.cross_call_edges.add((caller_line, callee_entry))
                    self.logger.debug(
                        f"探测到跨函数调用: {call_name} @ 调用行 {caller_line} → 入口行 {callee_entry}"
                    )

                # 修复：用统一的 extract_identifiers 提取参数 + 接收者对象的 USE
                used = self.extract_identifiers(node)
                for v in used:
                    self.add_dfg_edge(v, caller_line)

                for c in node.children:
                    self.visit_piece(c)
            except Exception as e:
                self.logger.warning(f"探测函数调用失败: {e}")
            return

        # ---- 原有分发逻辑保留（以下不变） ----
        if node.type == "for_statement":
            self.ast_visit(node)
        elif node.type == "enhanced_for_statement":
            self.ast_visit(node)
        elif node.type == "while_statement":
            self.ast_visit(node)
        elif node.type == "do_statement":
            self.ast_visit(node)
        elif node.type == "try_with_resources_statement":
            self.ast_visit(node)
        elif node.type == "assert_statement":
            self.ast_visit(node)
        elif node.type == "switch_statement":
            self.ast_visit(node)
        elif node.type == "switch_block":
            self.ast_visit(node)
        elif node.type == "switch_block_statement_group":
            self.ast_visit(node)
        elif node.type == "labeled_statement":
            self.ast_visit(node)
        elif node.type == "continue_statement":
            self.ast_visit(node)
        elif node.type == "try_statement":
            self.ast_visit(node)
        elif node.type == "throw_statement":
            self.ast_visit(node)
        elif node.type == "if_statement":
            self.ast_visit(node)
        elif node.type == "synchronized_statement":
            self.ast_visit(node)
        elif node.type == "expression_statement":
            self.ast_visit(node)
        elif node.type == "local_variable_declaration":
            self.ast_visit(node)
        elif node.type == "parenthesized_expression":
            self.ast_visit(node)
        elif node.type == "return_statement":
            self.ast_visit(node)
        elif node.type == "ERROR":
            self.ast_visit(node)
        elif node.type == "break_statement":
            self.ast_visit(node)
        elif node.type == "class_declaration":
            self.ast_visit(node)
        elif node.type == "declaration":
            self.ast_visit(node)
        elif node.type == "function_declarator":
            self.ast_visit(node)
        elif node.type == "compound_statement":
            self.ast_visit(node)
        elif node.type == "goto_statement":
            self.ast_visit(node)
        elif node.type == "preproc_if":
            self.ast_visit(node)
        elif node.type == "preproc_params":
            self.ast_visit(node)
        elif node.type == "pointer_declarator":
            self.ast_visit(node)
        elif node.type == "preproc_ifdef":
            self.ast_visit(node)
        elif node.type == "preproc_elif":
            self.ast_visit(node)
        elif node.type == "preproc_function_def":
            self.ast_visit(node)
        elif node.type == "preproc_call":
            self.ast_visit(node)
        elif node.type == "preproc_else":
            self.ast_visit(node)
        elif node.type == "preproc_def":
            self.ast_visit(node)
        elif node.type == "preproc_include":
            self.ast_visit(node)
        elif node.type == "preproc_defined":
            self.ast_visit(node)
        elif node.type == "function_definition":
            self.ast_visit(node)
        elif node.type == "}":
            self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        elif node.type == "{":
            self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        elif node.type == ";":
            self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        elif node.type == "\n":
            self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        else:
            pass

    def visit_function_declarator(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] + 1 > node.start_point[0] + 1:
            for i in range(node.start_point[0] + 1, node.end_point[0] + 1):
                self.G.add_edge(i, i + 1, weight=1)

    def visit_class_declaration(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] + 1 > node.start_point[0] + 1:
            for i in range(node.start_point[0] + 1, node.end_point[0] + 1):
                self.G.add_edge(i, i + 1, weight=1)

    def visit_pointer_declarator(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] + 1 > node.start_point[0] + 1:
            for i in range(node.start_point[0] + 1, node.end_point[0] + 1):
                self.G.add_edge(i, i + 1, weight=1)

    def visit_enhanced_for_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.next_sibling is not None:
            self.G.add_edge(node.start_point[0] + 1, node.next_sibling.start_point[0] + 1, weight=1)
        else:
            self.G.add_edge(node.start_point[0] + 1, node.end_point[0] + 1, weight=1)
        self.circle.append((node.start_point[0] + 1, node.end_point[0] + 1))
        self.dece_node.append(node.start_point[0] + 1)
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
            elif z.type == "if_statement":
                for j in z.children:
                    if j.type == "compound_statement":
                        self.G.add_edge(j.end_point[0] + 1, node.start_point[0] + 1, weight=1)
            elif z.type == "try_statement":
                for j in z.children:
                    if j.type == "compound_statement":
                        self.G.add_edge(j.end_point[0] + 1, node.start_point[0] + 1, weight=1)
            elif z.type == "switch_statement":
                for j in z.children:
                    if j.type == "switch_block":
                        self.G.add_edge(j.end_point[0] + 1, node.start_point[0] + 1, weight=1)
                    elif j.type == "compound_statement":
                        self.G.add_edge(j.end_point[0] + 1, node.start_point[0] + 1, weight=1)
            else:
                self.visit_piece(z)
                self.G.add_edge(z.end_point[0] + 1, node.start_point[0] + 1, weight=1)
        self.loopflag = node.end_point[0] + 1

    def visit_try_with_resources_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        body_node = {}
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
                body_node['bs'] = z.start_point[0] + 1
                body_node['be'] = z.end_point[0] + 1
            elif z.type == "finally_clause":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.dece_node.append(z.start_point[0] + 1)
                body_node['fs'] = z.start_point[0] + 1
                body_node['fe'] = z.end_point[0] + 1
                self.ast_visit(z)
            elif z.type == "catch_clause":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.dece_node.append(z.start_point[0] + 1)
                body_node['cs'] = z.start_point[0] + 1
                body_node['ce'] = z.end_point[0] + 1
                self.ast_visit(z)
            else:
                self.visit_piece(z)
        if 'be' in body_node and 'cs' in body_node:
            self.G.add_edge(body_node['be'], body_node['cs'], weight=1)
        if 'ce' in body_node and 'fs' in body_node:
            self.G.add_edge(body_node['ce'], body_node['fs'], weight=1)

    def visit_assert_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] + 1 > node.start_point[0] + 1:
            for i in range(node.start_point[0] + 1, node.end_point[0] + 1):
                self.G.add_edge(i, i + 1, weight=1)
        if node.end_point[0] + 1 not in self.finlineno:
            self.finlineno.append(node.end_point[0] + 1)

    def visit_switch_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.circle.append((node.start_point[0] + 1, node.end_point[0] + 1))
        if node.next_sibling is not None:  # named_child_count
            self.G.add_edge(node.start_point[0] + 1, node.next_sibling.start_point[0] + 1, weight=1)
        else:
            self.G.add_edge(node.start_point[0] + 1, node.end_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        if node.end_point[0] + 1 != self.finlineno[0]:
            self.G.add_edge(node.children[-1].end_point[0] + 1, node.end_point[0] + 2, weight=1)
        for z in node.children:
            if z.type == "switch_block":
                self.dece_node.append(z.start_point[0] + 1)
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                for i in range(len(z.children)):
                    if node.start_point[0] != z.children[i].start_point[0]:
                        self.G.add_edge(node.start_point[0] + 1, z.children[i].start_point[0] + 1, weight=1)
                self.ast_visit(z)
            elif z.type == "compound_statement":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_case_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_switch_block(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            if z.type == "switch_block_statement_group":
                self.ast_visit(z)

    def visit_switch_block_statement_group(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.ast_visit(z)

    def visit_labeled_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_goto_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_try_statement(self, node):
        """精准连接 try -> catch -> finally 流向"""
        start_line = node.start_point[0] + 1
        self.G.add_edge(start_line, start_line + 1, weight=1)

        if not hasattr(self, 'dece_node'): self.dece_node = []
        self.dece_node.append(start_line)

        try_end, catch_ends, finally_start = None, [], None

        for z in node.children:
            if z.type == "compound_statement":  # 对应 Try block
                self.ast_visit(z)
                try_end = self.get_last_child_line(z) + 1
            elif z.type == "catch_clause":
                catch_start = z.start_point[0] + 1
                self.G.add_edge(start_line, catch_start, weight=1, label="throw_to_catch")
                self.dece_node.append(catch_start)
                self.ast_visit(z)
                catch_ends.append(self.get_last_child_line(z) + 1)
            elif z.type == "finally_clause":
                finally_start = z.start_point[0] + 1
                self.G.add_edge(start_line, finally_start, weight=1, label="try_to_finally")
                self.dece_node.append(finally_start)
                self.ast_visit(z)
            else:
                self.visit_piece(z)

        # 构建标准的异常流转图
        if finally_start:
            if try_end:
                self.G.add_edge(try_end, finally_start, weight=1, label="try_exit_to_finally")
            for ce in catch_ends:
                self.G.add_edge(ce, finally_start, weight=1, label="catch_exit_to_finally")

    def visit_catch_clause(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_finally_clause(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_throw_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        for z in node.children:
            if z.type == "object_creation_expression":
                self.ast_visit(z)
        if node.end_point[0] + 1 not in self.finlineno:
            self.finlineno.append(node.end_point[0] + 1)

    def visit_object_creation_expression(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_argument_list(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_params(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            if z.type == "#define":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == "preproc_arg":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
                if node.start_point[0] != node.end_point[0]:
                    for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                        self.G.add_edge(j, j + 1, weight=1)
            else:
                self.visit_piece(z)

    def visit_preproc_function_def(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_call(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_def(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_defined(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_include(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_ternary_expression(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.start_point[0] != node.end_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_synchronized_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for index, z in enumerate(node.children):
            if z.type == "compound_statement":
                self.ast_visit(z)

    def visit_expression_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)

        # 关键：让 assignment/update/call 触发 DFG 逻辑
        for c in node.children:
            if c.type in {"assignment_expression", "update_expression", "call_expression"}:
                self.ast_visit(c)
            else:
                self.visit_piece(c)

        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_local_variable_declaration(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)

        current_line = node.start_point[0] + 1
        for ch in node.children:
            if ch.type == "init_declarator":
                self.ast_visit(ch)  # 走 visit_init_declarator
            else:
                # 无初始化声明时，也尝试把声明变量记为 DEF
                if ch.type in {"identifier", "pointer_declarator"}:
                    for v in self.extract_identifiers(ch):
                        self.record_def(v, current_line)
                self.visit_piece(ch)

        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_declaration(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)

        current_line = node.start_point[0] + 1
        for ch in node.children:
            if ch.type == "init_declarator":
                self.ast_visit(ch)  # 走 visit_init_declarator
            else:
                if ch.type in {"identifier", "pointer_declarator"}:
                    for v in self.extract_identifiers(ch):
                        self.record_def(v, current_line)
                self.visit_piece(ch)

        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)
    def visit_init_declarator(self, node):
        """int a = b + c;  左边DEF，右边USE"""
        current_line = node.start_point[0] + 1
        children = node.children
        if not children:
            return

        lhs = children[0]
        rhs = children[-1] if len(children) > 1 else None

        if rhs is not None and rhs is not lhs:
            used = self.extract_identifiers(rhs)
            for v in used:
                self.add_dfg_edge(v, current_line)

        defs = self.extract_identifiers(lhs)
        for v in defs:
            self.record_def(v, current_line)

        for ch in children:
            self.visit_piece(ch)

    def visit_assignment_expression(self, node):
        """处理赋值：区分 = 和 +=/-= 等复合操作"""
        current_line = node.start_point[0] + 1

        # Tree-sitter 结构通常是: [lhs, operator, rhs]
        lhs = node.children[0]
        operator = node.children[1].type if len(node.children) > 1 else "="
        rhs = node.children[-1]

        # 1. 提取右侧的使用变量
        used_vars = self.extract_identifiers(rhs)

        # 2. 关键逻辑：如果是复合赋值 (如 x += 5)，x 也是被使用的
        if operator != "=":
            used_vars |= self.extract_identifiers(lhs)  # 或 used_vars.update(...)

        # 记录所有 USE 关系
        for v in set(used_vars):  # 去重处理
            self.add_dfg_edge(v, current_line)

        # 3. 记录左侧的 DEF 关系
        def_vars = self.extract_identifiers(lhs)
        for v in def_vars:
            self.record_def(v, current_line)

        # 继续向下遍历
        self.ast_visit(rhs)

    def visit_update_expression(self, node):
        """处理 i++, --j 等：既是数据的使用者，也是定义的产生者"""
        current_line = node.start_point[0] + 1
        # 获取涉及的标识符（例如 'i'）
        vars_involved = self.extract_identifiers(node)

        for v in vars_involved:
            # 1. DFG: 这一行读取了 v 的旧值
            self.add_dfg_edge(v, current_line)
            # 2. DFG: 这一行重新定义了 v (产生了新值)
            self.record_def(v, current_line)

        # 递归访问子节点（以防有更复杂的嵌套）
        for child in node.children:
            self.ast_visit(child)

    def visit_ERROR(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.start_point[0] != node.end_point[0]:
            for j in range(node.start_point[0], node.end_point[0] + 1):
                self.G.add_edge(j, j + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_parenthesized_expression(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.start_point[0] != node.end_point[0]:
            for j in range(node.start_point[0], node.end_point[0] + 1):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_generic_type(self, node):
        pass

    def visit_identifier(self, node):
        pass

    def visit_if(self, node):
        pass

    def visit_for(self, node):
        pass

    def visit_binary_expression(self, node):
        """处理 a + b, x > y 等表达式中的数据流"""
        current_line = node.start_point[0] + 1

        # 提取表达式中涉及的所有标识符（变量名）
        # 比如 (a + b) * c 会提取出 a, b, c
        used_vars = self.extract_identifiers(node)
        for v in used_vars:
            # 将这些变量标记为在当前行被“使用”
            self.add_dfg_edge(v, current_line)

        # 继续向下遍历，以防有更复杂的嵌套（如函数调用作为操作数）
        for child in node.children:
            self.visit_piece(child)

    def print_isolated_nodes(self):
        isolated = list(nx.isolates(self.G))
        if isolated:
            print(f"孤立节点: {sorted(isolated)}")
            for node in isolated:
                if hasattr(self, 'source_lines') and 1 <= node <= len(self.source_lines):
                    context = self.source_lines[node - 1].strip()
                    print(f"行号 {node} 的AST上下文: {context}")
                    self.logger.debug(f"行号 {node} 的AST上下文: {context}")
                else:
                    print(f"行号 {node} 的AST上下文: [无法获取]")
                    self.logger.debug(f"行号 {node} 的AST上下文: [无法获取]")
        else:
            print("无孤立节点")

    def ast_visit_children(self, node):
        """递归处理所有子节点"""
        for child in node.children:
            self.ast_visit(child)

    def get_node_code(self, node):
        """提取指定AST节点对应的源代码（带行号校验）"""
        start_line = node.start_point[0]
        end_line = node.end_point[0]

        # 行号边界保护
        if start_line < 0 or end_line >= len(self.source_lines):
            return ""

        # 提取多行代码片段
        code_snippet = []
        for line_num in range(start_line, end_line + 1):
            if line_num < len(self.source_lines):
                code_snippet.append(f"Line {line_num + 1}: {self.source_lines[line_num]}")
        return '\n'.join(code_snippet)

    def _is_infinite_for_loop(self, node):
        """检测无限循环模式（如 for(;;)）"""
        condition = next((c for c in node.children if c.type == "condition"), None)
        if not condition:
            return True
        condition_code = self.get_node_code(condition).strip()
        return condition_code in self.loop_optimization['infinite_loop_marks']['conditions']

    def validate_graph(self):
        """校验并修复 CFG/DFG 图结构，确保连通性和合法性"""
        # 1. 删除非法节点 0
        if 0 in self.G.nodes:
            self.G.remove_node(0)
            self.logger.warning("删除了非法节点 0")

        # 2. 修复孤立节点（注意：真正的孤立节点通常意味着解析死角）
        isolated = list(nx.isolates(self.G))
        if isolated:
            for line in sorted(isolated):
                # 如果是 return 后的空行或注释，不强制修复，否则会产生伪路径
                prev_line = line - 1
                if prev_line in self.G.nodes and not self.G.nodes[prev_line].get('is_terminator', False):
                    self.G.add_edge(prev_line, line, weight=1, label="fix_isolated")

        # 3. 验证并强制补充终止节点
        for end in getattr(self, 'finlineno', []):
            if not self.G.has_node(end):
                self.G.add_node(end, shape='ellipse', label="EXIT")

        # 4. 移除非循环节点的自环边
        loop_heads = {loop[0] for loop in getattr(self, "circle", [])}
        to_remove = [(u, v) for u, v in self.G.edges() if u == v and u not in loop_heads]
        self.G.remove_edges_from(to_remove)

        # 5. 补充安全的顺序执行边 (关键修正区)
        def is_control_flow_keyword(line):
            if not hasattr(self, 'source_lines') or line > len(self.source_lines) or line <= 0:
                return False
            text = self.source_lines[line - 1].strip()
            # 补充了更多可能中断顺序执行的关键字
            return bool(re.match(r'^(else|case|default:|catch|finally|elif|#else|#endif)\b', text))

        all_nodes = sorted(self.G.nodes)
        for i in range(len(all_nodes) - 1):
            curr, next_ = all_nodes[i], all_nodes[i + 1]

            # 只有满足以下条件才补边：
            # a. 行号连续
            # b. 当前节点不是终止符 (如 return, break, continue, throw)
            # c. 两者之间还没有边
            # d. 下一行不是 ELSE/CATCH 等分支起始关键字
            if next_ == curr + 1:
                is_term = self.G.nodes[curr].get('is_terminator', False)
                has_edge = self.G.has_edge(curr, next_)

                if not is_term and not has_edge:
                    if not self._has_non_sequential_exit(curr) and not is_control_flow_keyword(next_):
                        self.G.add_edge(curr, next_, weight=1, label="seq_fallback")
                        self.logger.debug(f"补充顺序边: {curr} -> {next_}")

        # 6. 连通性兜底：确保入口点能到达至少一个出口
        if hasattr(self, 'finlineno') and self.finlineno and hasattr(self, 'firstlineno'):
            exits = [e for e in self.finlineno if self.G.has_node(e)]
            if exits and self.G.has_node(self.firstlineno):
                try:
                    reachable_exit = any(nx.has_path(self.G, self.firstlineno, e) for e in exits)
                    if not reachable_exit:
                        # 强行将图的末尾节点连向出口
                        reachable = nx.descendants(self.G, self.firstlineno) | {self.firstlineno}
                        tail = max(reachable)
                        self.G.add_edge(tail, exits[0], weight=1, label="force_reach_exit")
                except nx.NetworkXError:
                    pass

    def _find_ast_node(self, line):
        def traverse(node):
            start = node.start_point[0] + 1
            end = node.end_point[0] + 1
            if line < start or line > end:
                return None
            for child in node.children:
                result = traverse(child)
                if result is not None:
                    return result
            return node

        return traverse(self.ast)

    def _has_non_sequential_exit(self, line):
        """判断当前行是否存在非顺序出口（非line+1的边）"""
        for _, v in self.G.out_edges(line):
            if v != line + 1:
                return True
        return False

    def is_non_statement_line(self, line_text):
        stripped = line_text.strip()
        # 简单匹配 else 和 else if
        if re.match(r'^else(\s+if)?$', stripped):
            return True
        return stripped in ["{", "}", ";", ""]

    def visit_preproc_if(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)  # 连接预处理行
        for z in node.children:
            if z.type == "#if":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == "preproc_else":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.visit_piece(z)
            elif z.type == "#endif":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
                # 连接到 #endif 后的下一行
                next_line = z.start_point[0] + 2  # 假设 #endif 的下一行
                if next_line <= self.max_line:
                    self.G.add_edge(z.start_point[0] + 1, next_line, weight=1)
            elif z.type == "preproc_elif":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_preproc_else(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_preproc_elif(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_preproc_ifdef(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            if z.type == "#ifdef":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == "#endif":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)

                # 连接到 #endif 后的下一行
                next_line = z.start_point[0] + 2  # 假设 #endif 的下一行
                if next_line <= self.max_line:
                    self.G.add_edge(z.start_point[0] + 1, next_line, weight=1)
            else:
                self.visit_piece(z)

    def get_if_else_exit_line(self, node):
        parent = getattr(node, 'parent', None)
        if not parent:
            return node.end_point[0] + 2

        siblings = parent.children
        idx = siblings.index(node)
        if idx + 1 < len(siblings):
            next_stmt = siblings[idx + 1]
            return next_stmt.start_point[0] + 1
        return parent.end_point[0] + 2

    def visit_if_statement(self, node):
        cond_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        self.G.add_node(cond_line, shape='diamond', label=f"IF@L{cond_line}")

        # 关键：访问条件节点，以触发 if() 内部所用变量的数据流（DFG）逻辑
        condition_node = next((c for c in node.children if c.type in ("condition", "parenthesized_expression")), None)
        if condition_node:
            self.ast_visit(condition_node)

        # 识别 THEN 和 ELSE 块
        then_node = next((c for c in node.children if c.type == "compound_statement"), None)
        else_node = next((c for c in node.children if c.type == "else_clause"), None)

        # 1. 处理 THEN 分支
        if then_node:
            then_start = then_node.start_point[0] + 1
            self.G.add_edge(cond_line, then_start, weight=1, label='then')
            self.ast_visit(then_node)

            then_end = self.get_last_child_line(then_node) + 1
            self.G.add_edge(then_end, end_line, weight=1, label='then_end')
        else:
            # 处理单语句 THEN 分支（无大括号）
            then_stmts = [c for c in node.children if
                          c.type not in ("else_clause", "condition", "parenthesized_expression", "if", "else")]
            if then_stmts:
                first_then = then_stmts[0]
                self.G.add_edge(cond_line, first_then.start_point[0] + 1, weight=1, label='then')
                for idx, stmt in enumerate(then_stmts):
                    self.ast_visit(stmt)
                    if idx + 1 < len(then_stmts):
                        self.G.add_edge(stmt.end_point[0] + 1, then_stmts[idx + 1].start_point[0] + 1, weight=1)
                self.G.add_edge(then_stmts[-1].end_point[0] + 1, end_line, weight=1, label='then_end')
            else:
                self.G.add_edge(cond_line, end_line, weight=1, style='dashed')

        # 2. 处理 ELSE 分支
        if else_node:
            else_line = else_node.start_point[0] + 1
            self.G.add_node(else_line, shape='box', label=f"ELSE@L{else_line}")
            self.G.add_edge(cond_line, else_line, weight=1, label='else')

            else_body = next((c for c in else_node.children if c.type in ("compound_statement", "if_statement")), None)

            if else_body:
                else_start = else_body.start_point[0] + 1
                self.G.add_edge(else_line, else_start, weight=1)
                self.ast_visit(else_body)
                else_end = self.get_last_child_line(else_body) + 1
                self.G.add_edge(else_end, end_line, weight=1, label='else_exit')
            else:
                # 针对意外 else 结构的后备兜底处理
                for child in else_node.children:
                    if child.type != "else":
                        self.ast_visit(child)
                self.G.add_edge(else_line, end_line, weight=1)
        else:
            # 如果没有 else 块，直接将条件链接到结束节点
            self.G.add_edge(cond_line, end_line, weight=1, style='dashed', label='no_else')

    def visit_while_statement(self, node):
        cond_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        # DFG 修复：确保捕获 while 条件中的变量
        condition = next((c for c in node.children if c.type in ("condition", "parenthesized_expression")), None)
        if condition:
            self.ast_visit(condition)

        self.G.add_edge(cond_line, cond_line + 1, weight=1, label='while_cond')
        self.loop_stack.append({'head': cond_line, 'exit': end_line})

        # 安全追加可能未初始化的属性
        if not hasattr(self, 'circle'): self.circle = []
        if not hasattr(self, 'dece_node'): self.dece_node = []

        self.circle.append((cond_line, end_line))
        self.dece_node.append(cond_line)

        body_node = next((c for c in node.children if c.type == "compound_statement"), None)

        if body_node:
            body_start = body_node.start_point[0] + 1
            self.G.add_edge(cond_line, body_start, weight=1, label='while_body')
            self.ast_visit(body_node)
            body_end = self.get_last_child_line(body_node) + 1
            self.G.add_edge(body_end, cond_line, weight=1, label='while_back')
        else:
            self.G.add_edge(cond_line, end_line, weight=1, label='while_empty')

        self.G.add_edge(cond_line, end_line, weight=1, label='while_exit')
        self.loop_stack.pop()

    def visit_for_statement(self, node):
        """精确区分 Init -> Cond -> Body -> Update -> Cond 路径"""
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        # 1. 提取关键组成部分 (根据 tree-sitter 类型过滤)
        # 注意：不同语言的 node.type 略有不同，这里做了通用兼容处理
        init = next((c for c in node.children if c.type in ["declaration", "assignment_expression"]), None)
        cond = next(
            (c for c in node.children if c.type in ["condition", "binary_expression", "parenthesized_expression"]),
            None)
        update = next((c for c in node.children if c.type == "update_expression"), None)
        body = next((c for c in node.children if c.type == "compound_statement"), None)

        # 确定各部分的行号
        cond_line = cond.start_point[0] + 1 if cond else start_line
        update_line = update.start_point[0] + 1 if update else cond_line

        # 2. CFG: 连边逻辑
        # 如果有 init，先执行 init (这一步通常在父节点或通过顺序边完成，这里确保 head 存在)
        self.G.add_node(cond_line, shape='diamond', label=f"FOR_COND@L{cond_line}")

        # 关键：Continue 应该跳转到 update 表达式，而不是直接跳回条件
        self.loop_stack.append({'head': update_line, 'exit': end_line})

        # 3. 访问子节点触发 DFG 捕获
        if init: self.ast_visit(init)
        if cond: self.ast_visit(cond)
        if update: self.ast_visit(update)

        # 4. 循环体连边
        if body:
            body_start = body.start_point[0] + 1
            self.G.add_edge(cond_line, body_start, weight=1, label='true')
            self.ast_visit(body)

            # 循环体末尾 -> Update 表达式
            body_end = self.get_last_child_line(body) + 1
            self.G.add_edge(body_end, update_line, weight=1)

            # Update 表达式 -> 条件判断
            if update:
                self.G.add_edge(update_line, cond_line, weight=1, label='loop_back')
        else:
            # 空循环体
            self.G.add_edge(cond_line, update_line, weight=1)
            if update: self.G.add_edge(update_line, cond_line, weight=1)

        # 条件失败 -> 退出循环
        self.G.add_edge(cond_line, end_line, weight=1, label='false')
        self.loop_stack.pop()

    def visit_do_statement(self, node):
        cond_node = node.children[-1]
        cond_line = cond_node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        # DFG 修复：捕获条件变量
        self.ast_visit(cond_node)

        self.loop_stack.append({'head': cond_line, 'exit': end_line})
        if not hasattr(self, 'circle'): self.circle = []
        if not hasattr(self, 'dece_node'): self.dece_node = []
        self.circle.append((cond_line, end_line))
        self.dece_node.append(cond_line)

        body_node = next((c for c in node.children if c.type == "compound_statement"), None)

        if body_node:
            body_start = body_node.start_point[0] + 1
            self.G.add_edge(cond_line, body_start, weight=1, label='do_body')
            self.ast_visit(body_node)
            body_end = self.get_last_child_line(body_node) + 1
            self.G.add_edge(body_end, cond_line, weight=1, label='do_back')
        else:
            self.G.add_edge(cond_line, end_line, weight=1, label='do_empty')

        self.G.add_edge(cond_line, end_line, weight=1, label='do_exit')
        self.loop_stack.pop()

    def visit_break_statement(self, node):
        start = node.start_point[0] + 1
        self.G.add_edge(start - 1, start, weight=1, label='break_entry')  # 保证前一行连到 break 行
        if self.loop_stack:
            exit_line = self.loop_stack[-1]['exit']
            self.G.add_edge(start, exit_line, weight=1, label='break')
        else:
            # 没有循环上下文，跳转到函数出口或下一行
            next_line = start + 1
            if next_line <= self.max_line:
                self.G.add_edge(start, next_line, weight=1, label='break_weak')
            else:
                for fin in self.finlineno:
                    self.G.add_edge(start, fin, weight=1, label='break_exit')

    def visit_continue_statement(self, node):
        start = node.start_point[0] + 1
        self.G.add_edge(start - 1, start, weight=1, label='continue_entry')
        if self.loop_stack:
            head_line = self.loop_stack[-1]['head']
            self.G.add_edge(start, head_line, weight=1, label='continue')
        else:
            # 没有循环上下文，跳转到下一行或函数末尾
            next_line = start + 1
            if next_line <= self.max_line:
                self.G.add_edge(start, next_line, weight=1, label='continue_weak')
            else:
                for fin in self.finlineno:
                    self.G.add_edge(start, fin, weight=1, label='continue_exit')

    def visit_return_statement(self, node):
        """处理返回语句：确保它是控制流的绝对终点"""
        start = node.start_point[0] + 1
        end = node.end_point[0] + 1

        # DFG 捕获
        for child in node.children:
            if child.type not in ("return", ";"):
                self.ast_visit(child)

        # CFG: 标记该行为终止节点
        self.G.add_node(end, is_terminator=True)

        # 将 return 连接到所有预设的函数出口 (finlineno)
        if hasattr(self, 'finlineno') and self.finlineno:
            for fin in self.finlineno:
                self.G.add_edge(end, fin, weight=1, label='return_exit')

    # --- 对应修改 validate_graph 中的逻辑 ---
    # 在遍历所有节点补充顺序边时，增加一个判断：
    # if not self.G.nodes[curr].get('is_terminator', False):
    #     self.G.add_edge(curr, next_, ...)

    def get_last_child_line(self, node):
        """安全、递归地获取代码块真正执行的最后一行（跳过括号和注释）"""
        if not node or not hasattr(node, 'children') or not node.children:
            return node.end_point[0] if node else -1

        # 过滤掉非执行的语法符号
        valid_children = [
            c for c in node.children
            if c.type not in {'{', '}', ';', 'comment', 'whitespace', '\n'}
        ]

        if not valid_children:
            return node.end_point[0]

        last_child = valid_children[-1]

        # 如果最后一个子节点也有自己的 children (如嵌套的 if/for)，递归深入
        if getattr(last_child, 'children', None):
            return self.get_last_child_line(last_child)

        return last_child.end_point[0]


