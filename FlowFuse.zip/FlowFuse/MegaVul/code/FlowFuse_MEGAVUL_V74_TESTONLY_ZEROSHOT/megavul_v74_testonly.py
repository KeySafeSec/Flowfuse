#!/usr/bin/env python3
"""
MegaVul TEST-only entry for the exact FlowFuse v7.4 preprocessing implementation.

No preprocessing algorithm is copied or reimplemented here. We import the
original data_process_single.py and replace only:
  DATASET_BASE_DIR
  OUTPUT_BASE_DIR
  DATASETS_CONFIG
Then call its original main().
"""
import argparse, os, shutil, json
from pathlib import Path

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="MegaVul test_paired_synced.jsonl")
    ap.add_argument("--output-dir", required=True)
    args=ap.parse_args()

    inp=Path(args.input).resolve()
    out=Path(args.output_dir).resolve()
    if not inp.is_file():
        raise SystemExit(f"[FATAL] missing input: {inp}")
    out.mkdir(parents=True, exist_ok=True)

    # Audit raw population before preprocessing.
    rows=[]
    with inp.open(encoding="utf-8") as f:
        for line in f:
            if line.strip(): rows.append(json.loads(line))
    pos=sum(int(x.get("target",0))==1 for x in rows)
    neg=sum(int(x.get("target",0))==0 for x in rows)
    pairs={}
    for x in rows:
        pairs.setdefault(str(x.get("pair_id")),[]).append(x)
    complete=sum(len(v)==2 and {int(x.get("target",0)) for x in v}=={0,1}
                 for v in pairs.values())
    if (len(rows),pos,neg,complete)!=(1086,543,543,543):
        raise SystemExit(
            f"[FATAL] unexpected MegaVul TEST population: "
            f"rows={len(rows)} pos={pos} neg={neg} complete_pairs={complete}"
        )

    # Original preprocessor constructs synced output as <input-base>_synced.jsonl.
    # Use test.jsonl as a staging alias so output is exactly test_synced.jsonl.
    stage=out/"_input"
    stage.mkdir(exist_ok=True)
    shutil.copy2(inp, stage/"test.jsonl")

    import data_process_single as dp
    dp.DATASET_BASE_DIR=str(stage)
    dp.OUTPUT_BASE_DIR=str(out)
    dp.DATASETS_CONFIG=[
        {"split":"test","input":"test.jsonl","output_pkl":"dataflow_megavul_test.pkl"}
    ]

    # Its FileHandler was created at import time using the default output path.
    # Algorithm/results are unaffected; main() writes report/PKL to overridden dir.
    print("[MegaVul v7.4 TEST-only]")
    print("input =", inp)
    print("output=", out)
    print("rows=1086 pos=543 neg=543 complete_pairs=543")
    dp.main()

if __name__=="__main__":
    main()
