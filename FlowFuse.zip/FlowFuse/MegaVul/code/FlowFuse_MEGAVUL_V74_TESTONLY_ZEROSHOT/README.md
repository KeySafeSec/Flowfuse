# MegaVul v7.4 TEST-only + zero-shot

This package uses the uploaded historical FlowFuse v7.4 implementation directly.

## Preprocessing
`megavul_v74_testonly.py` imports the original `data_process_single.py`.
It changes only dataset/output locations and `DATASETS_CONFIG` to a single TEST split.
The v7.4 CFG/anchor/diversity algorithms are not reimplemented.

Input:
`<HISTORICAL_PROJECT_ROOT>/data/megal/processed_DataFlow_final/test_paired_synced.jsonl`

Expected population:
1086 rows = 543 vulnerable + 543 fixed = 543 complete pairs.

Output:
`<ARTIFACT_ROOT>/data/megal/processed_DataFlow_v7_4_pmcl_diverse/dataflow_megavul_test.pkl`

## Zero-shot
Model:
`output/run_unixcoder_v7_4_pmcl_diverse/checkpoint-best/model.bin`
SHA256: `5f3edde87f8f898b3e2db4af9ad30405ac7e2854e4a4204473aed3e3c6de7738`

The runner uses PrimeVul-Pair VALID for threshold selection and MegaVul only as TEST.
No MegaVul training and no MegaVul threshold selection.

## Run
```bash
conda activate MCCOVC
cd <ARTIFACT_ROOT>
unzip -o FlowFuse_MEGAVUL_V74_TESTONLY_ZEROSHOT.zip
mkdir -p code/FlowFuse_MEGAVUL_V74_TESTONLY_ZEROSHOT
cp -r FlowFuse_MEGAVUL_V74_TESTONLY_ZEROSHOT/* code/FlowFuse_MEGAVUL_V74_TESTONLY_ZEROSHOT/
chmod +x code/FlowFuse_MEGAVUL_V74_TESTONLY_ZEROSHOT/*.sh

bash code/FlowFuse_MEGAVUL_V74_TESTONLY_ZEROSHOT/00_BUILD_MEGAVUL_V74_TESTONLY.sh \
  2>&1 | tee megavul_v74_preprocess.log

bash code/FlowFuse_MEGAVUL_V74_TESTONLY_ZEROSHOT/01_RUN_MEGAVUL_V74_ZEROSHOT.sh \
  2>&1 | tee megavul_v74_zeroshot.log

bash code/FlowFuse_MEGAVUL_V74_TESTONLY_ZEROSHOT/02_CHECK_MEGAVUL_ZEROSHOT.sh
```
