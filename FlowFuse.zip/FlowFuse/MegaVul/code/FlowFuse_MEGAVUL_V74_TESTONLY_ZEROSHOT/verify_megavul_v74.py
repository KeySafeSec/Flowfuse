#!/usr/bin/env python3
import argparse,json,pickle,re
from pathlib import Path
from collections import Counter,defaultdict

FORBIDDEN={
 'patch_path_token','has_patch','diff_coverage_ratio','diff_nodes_detail',
 'func_patch','counterpart_path_token',
 'teacher_path_scores','teacher_changed_count','teacher_available','teacher_train_only',
}
def norm(x): return re.sub(r'\s+',' ',str(x or '')).strip()

ap=argparse.ArgumentParser()
ap.add_argument("--raw",required=True)
ap.add_argument("--dir",required=True)
a=ap.parse_args()
raw=Path(a.raw); d=Path(a.dir)
pkl=d/"dataflow_megavul_test.pkl"; synced=d/"test_synced.jsonl"
if not pkl.is_file(): raise SystemExit(f"[FATAL] missing {pkl}")
if not synced.is_file(): raise SystemExit(f"[FATAL] missing {synced}")

def rows(p):
    with p.open(encoding="utf8") as f:return [json.loads(x) for x in f if x.strip()]
rr=rows(raw); sr=rows(synced)
if len(rr)!=1086 or len(sr)!=1086:
    raise SystemExit(f"[FATAL] row count raw={len(rr)} synced={len(sr)} expected=1086")
ridx=[str(x.get("idx")) for x in rr]; sidx=[str(x.get("idx")) for x in sr]
if ridx!=sidx: raise SystemExit("[FATAL] synced TEST changed raw order/membership")
if len(set(ridx))!=1086: raise SystemExit("[FATAL] duplicate idx in MegaVul TEST")
pos=sum(int(x.get("target",0))==1 for x in rr); neg=len(rr)-pos
P=defaultdict(list)
for x in rr:P[str(x.get("pair_id"))].append(x)
complete=sum(len(v)==2 and {int(x.get("target",0)) for x in v}=={0,1} for v in P.values())
if (pos,neg,complete)!=(543,543,543):raise SystemExit("[FATAL] target/pair audit failed")

with pkl.open("rb") as f:data=pickle.load(f)
if not isinstance(data,dict):raise SystemExit(f"[FATAL] PKL expected dict, got {type(data)}")
# Dropped CFG extraction records are allowed by v7.4; run.py raw-code fallback handles them.
extra=set(map(str,data))-set(ridx)
if extra:raise SystemExit(f"[FATAL] PKL contains idx outside TEST: {list(extra)[:10]}")
src=Counter(); exact_dup=0; cfgmax=0
for idx,rec in data.items():
    if not isinstance(rec,dict):raise SystemExit(f"[FATAL] {idx}: non-dict record")
    bad=FORBIDDEN.intersection(rec)
    if bad:raise SystemExit(f"[FATAL] {idx}: forbidden/leaked fields {sorted(bad)}")
    if rec.get("strict_single_function") is not True:raise SystemExit(f"[FATAL] {idx}: strict_single_function != True")
    if rec.get("v74_diverse") is not True:raise SystemExit(f"[FATAL] {idx}: v74_diverse missing")
    paths=rec.get("path_token",[]) or []; sources=rec.get("path_source",[]) or []
    if len(paths)!=len(sources):raise SystemExit(f"[FATAL] {idx}: path/source mismatch")
    keys=[norm(x) for x in paths if norm(x)]
    exact_dup += max(0,len(keys)-len(set(keys)))
    src.update(sources)
    ncfg=int(rec.get("cfg_path_count",0));cfgmax=max(cfgmax,ncfg)
    if ncfg>3:raise SystemExit(f"[FATAL] {idx}: cfg_path_count={ncfg}>3")
if exact_dup:raise SystemExit(f"[FATAL] exact duplicate paths remain: {exact_dup}")
print("[PASS] MegaVul raw/synced = 1086 rows, 543 complete pairs")
print(f"[PASS] v7.4 PKL records={len(data)} missing_for_raw_fallback={1086-len(data)}")
print(f"[PASS] strict single-function + v74_diverse + no teacher leakage; cfg_max={cfgmax}")
print("[INFO] path_source =",dict(src))
