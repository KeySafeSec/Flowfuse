#!/usr/bin/env bash
set -euo pipefail
ROOT="${FLOWFUSE_ROOT:-<ARTIFACT_ROOT>}"
MEGA_RAW="${MEGAVUL_RAW_DIR:-<HISTORICAL_PROJECT_ROOT>/data/megal/processed_DataFlow_final}"
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/data/megal/processed_DataFlow_v7_4_pmcl_diverse"
INPUT="$MEGA_RAW/test_paired_synced.jsonl"

export PYTHONPATH="$ROOT:$ROOT/code:$HERE:${PYTHONPATH:-}"
export FLOWFUSE_MAX_WORKERS="${PREPROCESS_WORKERS:-12}"
export FLOWFUSE_MAX_PATHS="${CFG_MAX_PATHS:-12}"
export FLOWFUSE_RETRY_MAX_PATHS="${CFG_RETRY_PATHS:-16}"
export FLOWFUSE_MAX_ANCHOR_PATHS="${ANCHOR_PATHS:-6}"
export FLOWFUSE_ANCHOR_RADIUS="${ANCHOR_RADIUS:-2}"
export FLOWFUSE_CFG_KEEP_MAX="${CFG_KEEP_MAX:-3}"
export FLOWFUSE_CFG_KEEP_MIN="${CFG_KEEP_MIN:-2}"
export FLOWFUSE_CFG_JACCARD="${CFG_JACCARD:-0.75}"
export FLOWFUSE_CFG_CONTAINMENT="${CFG_CONTAINMENT:-0.90}"
export FLOWFUSE_SECURITY_LINE_SCORE="${SECURITY_LINE_SCORE:-3.0}"

[[ -f "$INPUT" ]] || { echo "[FATAL] missing $INPUT"; exit 2; }
mkdir -p "$OUT"
rm -f "$OUT/dataflow_megavul_test.pkl" "$OUT/test_synced.jsonl"       "$OUT/dataflow_megavul_test_drop_debug_samples.jsonl"       "$OUT/full_pipeline_report.json" "$OUT/low_coverage_idx.csv"

cd "$HERE"
python -m py_compile data_process_single.py c_cfg.py megavul_v74_testonly.py verify_megavul_v74.py
python megavul_v74_testonly.py --input "$INPUT" --output-dir "$OUT" 2>&1 | tee "$OUT/preprocess_v7_4_console.log"
python verify_megavul_v74.py --raw "$INPUT" --dir "$OUT"
echo "[DONE] MegaVul v7.4 TEST-only PKL built: $OUT/dataflow_megavul_test.pkl"
