#!/usr/bin/env python3

import csv
import json
import math
import statistics
from pathlib import Path

ROOT = Path(
    "<ARTIFACT_ROOT>"
)

OUT = ROOT / "7.4版本所有文件，论文用/上传/primevul-pair/three_seed_summary"
OUT.mkdir(parents=True, exist_ok=True)

RUNS = {
    42: ROOT / "output/run_v74_bprd_full_relhead_seed42_protocol",
    123: ROOT / "output/run_v74_bprd_full_relhead_seed123_protocol",
    2026: ROOT / "output/run_v74_bprd_full_relhead_seed2026_protocol",
}

rows = []
configs = []

for seed, run_dir in RUNS.items():
    report_path = run_dir / "TEST_REPORT_FROZEN.json"
    config_path = run_dir / "selected_config.json"

    if not report_path.is_file():
        raise FileNotFoundError(report_path)
    if not config_path.is_file():
        raise FileNotFoundError(config_path)

    with report_path.open("r", encoding="utf-8") as f:
        report = json.load(f)

    with config_path.open("r", encoding="utf-8") as f:
        config = json.load(f)

    # Protocol safety checks.
    if report.get("test_used_for_selection") is not False:
        raise RuntimeError(
            f"Seed {seed}: TEST_REPORT_FROZEN.json does not state "
            "test_used_for_selection=false"
        )

    if config.get("test_opened") is not False:
        raise RuntimeError(
            f"Seed {seed}: selected_config.json is not a pre-TEST frozen config"
        )

    retrieval = report["retrieval_test"]
    base = report["base_test"]
    bprd = report["bprd_test"]

    rconf = config["retrieval"]
    oconf = config["orientation"]

    # Ensure the frozen config embedded in the TEST report matches the
    # standalone selected_config.json.
    embedded = report["selected_on_valid"]

    if embedded["retrieval"]["threshold"] != rconf["threshold"]:
        raise RuntimeError(f"Seed {seed}: retrieval threshold mismatch")
    if embedded["retrieval"]["margin"] != rconf["margin"]:
        raise RuntimeError(f"Seed {seed}: retrieval margin mismatch")
    if embedded["orientation"] != oconf:
        raise RuntimeError(f"Seed {seed}: orientation config mismatch")
    if embedded["v74_threshold"] != config["v74_threshold"]:
        raise RuntimeError(f"Seed {seed}: v74 threshold mismatch")

    rows.append({
        "Seed": seed,
        "Protocol": "seed-specific VALID -> freeze -> TEST",
        "PairPrec": retrieval["precision"],
        "PairRec": retrieval["recall"],
        "PairF1": retrieval["f1"],
        "AcceptedPairs": retrieval["pred_pairs"],
        "TruePairsAccepted": retrieval["tp"],
        "FalsePairsAccepted": retrieval["fp"],

        # NOTE:
        # These are the base-test scores embedded in the BPRD protocol.
        # They are NOT the separate random-seed Single protocol reported
        # elsewhere in the paper.
        "BPRDProtocolBase_F1": base["f1"],
        "BPRDProtocolBase_MCC": base["mcc"],
        "BPRDProtocolBase_AUC": base["AUC"],
        "BPRDProtocolBase_PR_AUC": base["PR_AUC"],

        "BPRD_F1": bprd["f1"],
        "BPRD_MCC": bprd["mcc"],
        "BPRD_AUC": bprd["AUC"],
        "BPRD_PR_AUC": bprd["PR_AUC"],
        "BPRD_PC": bprd["P-C_rate"],
        "BPRD_PairAcc": bprd["PairAcc_rate"],

        "v74_threshold": config["v74_threshold"],
        "retrieval_threshold": rconf["threshold"],
        "retrieval_margin": rconf["margin"],
        "head_alpha": oconf["head_alpha"],
        "v74_weight": oconf["v74_weight"],
        "head_weight": oconf["head_weight"],
        "scale": oconf["scale"],
        "mode": oconf["mode"],
    })

    configs.append({
        "Seed": seed,
        "v74_threshold": config["v74_threshold"],
        "retrieval_threshold": rconf["threshold"],
        "retrieval_margin": rconf["margin"],
        "head_alpha": oconf["head_alpha"],
        "v74_weight": oconf["v74_weight"],
        "head_weight": oconf["head_weight"],
        "scale": oconf["scale"],
        "mode": oconf["mode"],
        "VALID_AUC_gain": config["valid_auc_gain"],
        "VALID_PC_absolute_gain": config["valid_pc_absolute_gain"],
        "VALID_gate_passed": config["valid_gate_passed"],
    })


def sample_stats(key):
    values = [float(r[key]) for r in rows]
    return {
        "mean": statistics.mean(values),
        "std_sample": statistics.stdev(values),
        "n": len(values),
    }


stats = {
    key: sample_stats(key)
    for key in [
        "BPRD_F1",
        "BPRD_MCC",
        "BPRD_AUC",
        "BPRD_PR_AUC",
        "BPRD_PC",
        "BPRD_PairAcc",
    ]
}

payload = {
    "version": "FlowFuse-FSE2027-FINAL3-current-audited",
    "source": "current frozen TEST_REPORT_FROZEN.json + selected_config.json",
    "important_note": (
        "BPRDProtocolBase_* fields are the base scores embedded in each BPRD "
        "protocol run. They are not the separate random-seed Single protocol."
    ),
    "rows": rows,
    "configs": configs,
    "stats": stats,
}

json_path = OUT / "bprd_three_seed_metrics_FINAL3.json"
with json_path.open("w", encoding="utf-8") as f:
    json.dump(payload, f, indent=2, ensure_ascii=False)
    f.write("\n")

csv_path = OUT / "bprd_three_seed_metrics_FINAL3.csv"
with csv_path.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

config_csv = OUT / "selected_configs_FINAL3.csv"
with config_csv.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(configs[0].keys()))
    writer.writeheader()
    writer.writerows(configs)

audit_path = OUT / "THREE_SEED_FINAL3_AUDIT.txt"
with audit_path.open("w", encoding="utf-8") as f:
    f.write("FlowFuse FSE 2027 FINAL3 -- current three-seed audit\n")
    f.write("=" * 72 + "\n\n")

    for r in rows:
        f.write(
            f"seed={r['Seed']:4d}  "
            f"accepted={r['AcceptedPairs']:3d} "
            f"(true={r['TruePairsAccepted']:3d}, false={r['FalsePairsAccepted']:d})  "
            f"F1={100*r['BPRD_F1']:.2f}  "
            f"MCC={100*r['BPRD_MCC']:.2f}  "
            f"AUC={100*r['BPRD_AUC']:.2f}  "
            f"P-C={100*r['BPRD_PC']:.2f}  "
            f"PairAcc={100*r['BPRD_PairAcc']:.2f}\n"
        )

    f.write("\nSample mean +/- sample SD (n=3)\n")
    for key in ["BPRD_F1", "BPRD_MCC", "BPRD_AUC"]:
        s = stats[key]
        f.write(
            f"{key}: {100*s['mean']:.2f} +/- "
            f"{100*s['std_sample']:.2f}\n"
        )

print("[OK] Wrote:")
print(" ", csv_path)
print(" ", json_path)
print(" ", config_csv)
print(" ", audit_path)

print("\nCurrent BPRD three-seed results:")
for r in rows:
    print(
        f"seed {r['Seed']:4d}: "
        f"F1={100*r['BPRD_F1']:.2f} "
        f"MCC={100*r['BPRD_MCC']:.2f} "
        f"AUC={100*r['BPRD_AUC']:.2f} "
        f"accepted={r['AcceptedPairs']} "
        f"({r['TruePairsAccepted']} true + {r['FalsePairsAccepted']} false)"
    )

print("\nMean +/- sample SD:")
for key in ["BPRD_F1", "BPRD_MCC", "BPRD_AUC"]:
    s = stats[key]
    print(
        f"{key}: "
        f"{100*s['mean']:.2f} +/- {100*s['std_sample']:.2f}"
    )
