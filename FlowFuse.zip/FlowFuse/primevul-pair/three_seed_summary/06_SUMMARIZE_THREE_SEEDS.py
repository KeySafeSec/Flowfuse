#!/usr/bin/env python3
from pathlib import Path
import csv,json,re,statistics,math,hashlib

ROOT=Path("<ARTIFACT_ROOT>")
HERE=Path(__file__).resolve().parent
OUT=HERE/"paper_results"; OUT.mkdir(exist_ok=True)

BPRD_LINE=re.compile(
 r"BPRD_FROZEN_TEST\s+AUC=(?P<AUC>[0-9.]+)\s+PR=(?P<PR_AUC>[0-9.]+)\s+"
 r"MCC=(?P<MCC>[-0-9.]+)\s+F1=(?P<F1>[0-9.]+)\s+"
 r"P-C=(?P<PCN>\d+)/(?P<PCD>\d+)=(?P<PC>[0-9.]+)\s+"
 r"PairAcc=(?P<PAN>\d+)/(?P<PAD>\d+)=(?P<PairAcc>[0-9.]+)"
)
SINGLE_LINE=re.compile(
 r"V74_SINGLE_TEST\s+AUC=(?P<AUC>[0-9.]+)\s+PR=(?P<PR_AUC>[0-9.]+)\s+"
 r"MCC=(?P<MCC>[-0-9.]+)\s+F1=(?P<F1>[0-9.]+)\s+"
 r"P-C=(?P<PCN>\d+)/(?P<PCD>\d+)=(?P<PC>[0-9.]+)\s+"
 r"PairAcc=(?P<PAN>\d+)/(?P<PAD>\d+)=(?P<PairAcc>[0-9.]+)"
)
RET_LINE=re.compile(
 r"TEST retrieval precision=(?P<PairPrec>[0-9.]+)\s+recall=(?P<PairRec>[0-9.]+)\s+"
 r"F1=(?P<PairF1>[0-9.]+)\s+pairs=(?P<AcceptedPairs>\d+)"
)

def parse_log(path):
    s=Path(path).read_text(encoding="utf-8",errors="ignore")
    b=BPRD_LINE.search(s); q=SINGLE_LINE.search(s); r=RET_LINE.search(s)
    if not b: raise RuntimeError(f"Cannot find BPRD_FROZEN_TEST line in {path}")
    def dct(m):
        if not m:return {}
        d={}
        for k,v in m.groupdict().items():
            if k in {"PCN","PCD","PAN","PAD","AcceptedPairs"}: d[k]=int(v)
            else:d[k]=float(v)
        return d
    return dct(q),dct(b),dct(r)

def load_selected(out):
    return json.load(open(out/"selected_config.json",encoding="utf-8"))

def load_valid(out):
    return json.load(open(out/"VALID_REPORT.json",encoding="utf-8"))

specs={
  42:{
    "out":ROOT/"output/run_v74_bprd_full_relhead",
    "log":ROOT/"output/run_v74_bprd_full_relhead/TEST_FROZEN_RUN.log",
    "protocol":"canonical historical final run",
  },
  123:{
    "out":ROOT/"output/run_v74_bprd_full_relhead_seed123_protocol",
    "log":ROOT/"output/run_v74_bprd_full_relhead_seed123_protocol/TEST_FROZEN_SEED123.log",
    "protocol":"seed-specific VALID -> freeze -> TEST",
  },
  2026:{
    "out":ROOT/"output/run_v74_bprd_full_relhead_seed2026_protocol",
    "log":ROOT/"output/run_v74_bprd_full_relhead_seed2026_protocol/TEST_FROZEN_SEED2026.log",
    "protocol":"seed-specific VALID -> freeze -> TEST",
  }
}
rows=[]; configs=[]
for seed,x in specs.items():
    out=x["out"]; log=x["log"]
    for p in (out/"VALID_REPORT.json",out/"selected_config.json",log):
        if not p.exists(): raise SystemExit(f"Missing {p}")
    single,bprd,ret=parse_log(log)
    sc=load_selected(out); vr=load_valid(out)
    orient=sc.get("orientation",{})
    rr=sc.get("retrieval",{})
    row={
      "Seed":seed,
      "Protocol":x["protocol"],
      "PairPrec":ret.get("PairPrec"),"PairRec":ret.get("PairRec"),"PairF1":ret.get("PairF1"),
      "AcceptedPairs":ret.get("AcceptedPairs"),
      "Single_F1":single.get("F1"),"Single_MCC":single.get("MCC"),
      "Single_AUC":single.get("AUC"),"Single_PR_AUC":single.get("PR_AUC"),
      "BPRD_F1":bprd.get("F1"),"BPRD_MCC":bprd.get("MCC"),
      "BPRD_AUC":bprd.get("AUC"),"BPRD_PR_AUC":bprd.get("PR_AUC"),
      "BPRD_PC":bprd.get("PC"),"BPRD_PairAcc":bprd.get("PairAcc"),
      "v74_threshold":sc.get("v74_threshold"),
      "retrieval_threshold":rr.get("threshold"),"retrieval_margin":rr.get("margin"),
      "head_alpha":orient.get("head_alpha"),"v74_weight":orient.get("v74_weight"),
      "head_weight":orient.get("head_weight"),"scale":orient.get("scale"),"mode":orient.get("mode"),
    }
    rows.append(row)
    configs.append({
      "Seed":seed,"v74_threshold":sc.get("v74_threshold"),
      "retrieval_threshold":rr.get("threshold"),"retrieval_margin":rr.get("margin"),
      "head_alpha":orient.get("head_alpha"),"v74_weight":orient.get("v74_weight"),
      "head_weight":orient.get("head_weight"),"scale":orient.get("scale"),"mode":orient.get("mode"),
      "VALID_AUC":(vr.get("best") or {}).get("AUC"),
      "VALID_MCC":(vr.get("best") or {}).get("mcc"),
      "VALID_PC":(vr.get("best") or {}).get("P-C_rate"),
      "VALID_PairAcc":(vr.get("best") or {}).get("PairAcc_rate"),
    })

fields=list(rows[0].keys())
with open(OUT/"bprd_three_seed_metrics.csv","w",newline="",encoding="utf-8") as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
with open(OUT/"selected_configs.csv","w",newline="",encoding="utf-8") as f:
    w=csv.DictWriter(f,fieldnames=list(configs[0].keys()));w.writeheader();w.writerows(configs)

metric_cols=["BPRD_F1","BPRD_MCC","BPRD_AUC","BPRD_PR_AUC","BPRD_PC","BPRD_PairAcc"]
stats={}
for c in metric_cols:
    vals=[float(r[c]) for r in rows]
    stats[c]={"mean":statistics.mean(vals),"std":statistics.stdev(vals)}
payload={"rows":rows,"configs":configs,"stats":stats}
(OUT/"bprd_three_seed_metrics.json").write_text(json.dumps(payload,indent=2),encoding="utf-8")

def P(x): return f"{100*float(x):.2f}"
tex=[
r"\begin{table}[t]",
r"\centering",
r"\caption{Random-seed stability of the complete BPRD pipeline on PrimeVul-Pair. Each backbone seed follows the same VALID$\rightarrow$freeze$\rightarrow$TEST protocol; TEST is not used for configuration selection.}",
r"\label{tab:bprd-three-seed}",
r"\scriptsize",
r"\setlength{\tabcolsep}{3.6pt}",
r"\begin{tabular}{lrrrrrr}",
r"\toprule",
r"Seed & F1 & MCC & AUC & PR-AUC & \pc & PairAcc \\",
r"\midrule",
]
for r in rows:
    tex.append(f"{r['Seed']} & {P(r['BPRD_F1'])} & {P(r['BPRD_MCC'])} & {P(r['BPRD_AUC'])} & {P(r['BPRD_PR_AUC'])} & {P(r['BPRD_PC'])} & {P(r['BPRD_PairAcc'])} \\\\")
tex.append(r"\midrule")
tex.append(
  "Mean $\\pm$ SD & " +
  " & ".join(f"{100*stats[c]['mean']:.2f}$\\pm${100*stats[c]['std']:.2f}" for c in metric_cols)
  + r" \\"
)
tex += [r"\bottomrule",r"\end{tabular}",r"\end{table}"]
(OUT/"table_bprd_three_seed.tex").write_text("\n".join(tex),encoding="utf-8")

print("===== FINAL BPRD THREE-SEED TEST SUMMARY =====")
for r in rows:
    print(r["Seed"],{
      "F1":P(r["BPRD_F1"]),"MCC":P(r["BPRD_MCC"]),"AUC":P(r["BPRD_AUC"]),
      "PR_AUC":P(r["BPRD_PR_AUC"]),"P-C":P(r["BPRD_PC"]),"PairAcc":P(r["BPRD_PairAcc"]),
      "v74_threshold":r["v74_threshold"]
    })
print("Mean +/- SD:")
for c in metric_cols:
    print(c,f"{100*stats[c]['mean']:.2f} +/- {100*stats[c]['std']:.2f}")
print("[WROTE]",OUT)
