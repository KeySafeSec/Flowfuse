#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,re,csv

ROOT=Path("<ARTIFACT_ROOT>")
HERE=Path(__file__).resolve().parent
PAPER=HERE/"paper_results"; PAPER.mkdir(exist_ok=True)

def sha(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
    return h.hexdigest()

lines=["# Final three-seed BPRD protocol audit",""]
ok=True
for seed in (123,2026):
    out=ROOT/f"output/run_v74_bprd_full_relhead_seed{seed}_protocol"
    man=out/"PRE_TEST_SEED_PROTOCOL_MANIFEST.json"
    if not man.exists():
        lines.append(f"- seed {seed}: **FAIL** missing pre-TEST manifest")
        ok=False; continue
    m=json.load(open(man,encoding="utf-8"))
    checks=[
      ("selected_config_FROZEN_BEFORE_TEST.json","frozen_selected_config_sha256"),
      ("relative_head.joblib","relative_head_sha256"),
    ]
    good=True
    for fn,k in checks:
        p=out/fn
        if not p.exists() or sha(p)!=m[k]:
            good=False
            lines.append(f"- seed {seed}: **FAIL** hash mismatch `{fn}`")
    tr=out/"TEST_REPORT_FROZEN.json"
    if not tr.exists():
        good=False; lines.append(f"- seed {seed}: **FAIL** missing TEST report")
    if good:
        lines.append(f"- seed {seed}: PASS; pre-TEST frozen hashes still match after TEST.")

# Verify seed42 canonical exists.
for p in [
 ROOT/"output/run_v74_bprd_full_relhead/VALID_REPORT.json",
 ROOT/"output/run_v74_bprd_full_relhead/selected_config.json",
 ROOT/"output/run_v74_bprd_full_relhead/TEST_REPORT_FROZEN.json",
]:
    if not p.exists():
        ok=False; lines.append(f"- seed42 canonical: **FAIL** missing `{p}`")
if ok:
    lines.append("")
    lines.append("**Overall: PASS.** Seed42 is the canonical historical final run; seeds 123/2026 were frozen after seed-specific VALID selection and tested only afterward.")
else:
    lines.append("")
    lines.append("**Overall: FAIL / incomplete.** Do not use the three-seed table yet.")

(PAPER/"FINAL_PROTOCOL_AUDIT.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
print("\n".join(lines))
