# Frozen results for paper

## Closed-world paired benchmark

| Split | Method | AUC | MCC | F1 | P-C | PairAcc |
|---|---|---:|---:|---:|---:|---:|
| VALID | V74_SINGLE | 0.5788 | 0.1451 | 0.5125 | 16.08% | 64.10% |
| TEST | V74_SINGLE | 0.5747 | 0.1102 | 0.4629 | 12.87% | 64.85% |
| VALID | ORACLE_PAIR_EXCLUSIVE_V74_DIRECTION | 0.7226 | 0.2908 | 0.6469 | 64.10% | 64.10% |
| TEST | ORACLE_PAIR_EXCLUSIVE_V74_DIRECTION | 0.7271 | 0.3219 | 0.6650 | 64.85% | 64.85% |
| VALID | BLIND_VERIFIER_EXCLUSIVE_V74_DIRECTION | 0.7137 | 0.2819 | 0.6425 | 61.89% | 64.10% |
| TEST | BLIND_VERIFIER_EXCLUSIVE_V74_DIRECTION | 0.6991 | 0.2823 | 0.6455 | 59.65% | 64.85% |
| VALID | ORACLE_PAIR_EXCLUSIVE_LEARNED_HEAD | 0.8572 | 0.5485 | 0.7750 | 77.09% | 77.09% |
| TEST | ORACLE_PAIR_EXCLUSIVE_LEARNED_HEAD | 0.8753 | 0.5644 | 0.7827 | 77.97% | 77.97% |
| VALID | FULL_BLIND_VERIFIER_LEARNED_HEAD | 0.8487 | 0.5176 | 0.7596 | 73.79% | 75.99% |
| TEST | FULL_BLIND_VERIFIER_LEARNED_HEAD | 0.8606 | 0.5372 | 0.7700 | 73.02% | 78.22% |

## Blind counterpart retrieval

| Split | Precision | Recall | FP pairs |
|---|---:|---:|---:|
| VALID | 100.00% | 94.71% | 0 |
| TEST | 100.00% | 91.58% | 0 |

## Controlled open-world

| Split | Pair precision | Pair recall | Singleton reject | Worst reject | MCC gain |
|---|---:|---:|---:|---:|---:|
| VALID | 99.12% | 94.18% | 99.05% | 97.06% | +0.2267 |
| TEST | 97.68% | 91.27% | 97.73% | 95.05% | +0.2533 |

## Hard-negative stress

| Split | AUC true-vs-hard | True accept | Hard-negative accept | Same-name wrong accept |
|---|---:|---:|---:|---:|
| VALID | 0.9860 | 98.02% | 2.72% | 0.85% |
| TEST | 0.9830 | 98.27% | 4.04% | 0.81% |

## Reporting rule

Closed-world counterpart-aware results must be reported separately from ordinary independent single-function detection. Oracle-pair rows are diagnostic upper bounds, not deployment results. The primary proposed result is FULL_BLIND_VERIFIER_LEARNED_HEAD, with controlled open-world results demonstrating reject/fallback behavior when no counterpart is present.
