# FlowFuse v7.4 BPRD FULL RELATIVE-HEAD

This is the full follow-up to the successful VALID-only blind-pair experiment.

Observed prior result:

```text
Blind retrieval: precision=1.0000 recall=0.9824 F1=0.9911
v7.4 single:     AUC=0.578805  P-C=0.1608
blind exclusive: AUC=0.720536  P-C=0.6344
```

The package keeps that successful retrieval mechanism and adds a **TRAIN-only anti-symmetric relative orientation head**.

No Qwen is used.

## Method

```text
candidate function pool
        |
        | source code only
        v
blind char-TFIDF retrieval
        |
 mutual nearest neighbor
 + similarity threshold
 + top1-top2 margin
        |
   confident pair?
      /      \
    yes       no
     |         |
     v         v
relative      original v7.4
orientation   single-function fallback
     |
     +-- v7.4 risk difference
     +-- TRAIN-only anti-symmetric code-delta head
```

The relative head is structurally anti-symmetric:

```text
D(A,B) = TFIDF(A) - TFIDF(B)
D(B,A) = -D(A,B)

r(A,B) = w^T D(A,B)
r(B,A) = -r(A,B)
```

TRAIN pair_id/labels are used only for training this direction head.
VALID selects retrieval gate and fusion parameters.
TEST is locked until VALID passes.

## Required existing assets

Default paths in `config.json`:

```text
~/DataFlow_CFG_Def/data/primevul/data/primevul_final_datasets/paired/single_function/processed_DataFlow_v7_4_pmcl_diverse/train_synced.jsonl
~/DataFlow_CFG_Def/data/primevul/data/primevul_final_datasets/paired/single_function/processed_DataFlow_v7_4_pmcl_diverse/valid_synced.jsonl
~/DataFlow_CFG_Def/data/primevul/data/primevul_final_datasets/paired/single_function/processed_DataFlow_v7_4_pmcl_diverse/test_synced.jsonl

~/DataFlow_CFG_Def/output/run_unixcoder_v7_4_pmcl_diverse/predictions_valid.txt
~/DataFlow_CFG_Def/output/run_unixcoder_v7_4_pmcl_diverse/predictions_test.txt
```

The VALID-only pipeline does not read the TEST paths.

## Run VALID first

```bash
conda activate FlowFuse5090

cd ~/DataFlow_CFG_Def
unzip -o FlowFuse_v74_BPRD_FULL_RELHEAD.zip
cd FlowFuse_v74_BPRD_FULL_RELHEAD

bash RUN_VALID_ONLY.sh | tee run_valid_bprd_full.log
```

Important output:

```text
VALID blind retrieval selected
FLOWFUSE v7.4 BPRD FULL — VALID RESULT
CONTINUE_GATE=PASS / FAIL
TEST = NOT OPENED
```

## Open TEST only after VALID PASS

If the gate passes and you deliberately decide to evaluate:

```bash
bash RUN_TEST_IF_PASS.sh | tee run_test_bprd_full.log
```

The TEST script:

1. loads frozen `selected_config.json`;
2. strips TEST metadata for retrieval;
3. discovers pairs from code only;
4. applies frozen relative head/fusion;
5. saves blind predictions;
6. only then opens target/pair_id for metrics;
7. never searches TEST thresholds or weights.

## Output directory

```text
~/DataFlow_CFG_Def/output/run_v74_bprd_full_relhead/
```

Key files:

```text
relative_head.joblib
VALID_REPORT.json
VALID_DISTRACTOR_STRESS.json
selected_config.json
VALID_GATE_PASS
TEST_PREDICTIONS_BLIND.jsonl       # only after test unlock
TEST_REPORT_FROZEN.json            # only after test unlock
```

## Why keep TF-IDF retrieval?

Because VALID already showed that the retrieval problem is nearly solved:

```text
precision = 1.000
recall    = 0.982
```

Replacing that immediately with a learned neural retriever would add complexity while risking worse pairing. The learnable bottleneck is currently **orientation**, not retrieval.

## Paper caveat

The pure PrimeVul-Paired split is constructed from highly similar vulnerability/patch functions. Therefore the package includes `04_valid_distractor_stress.sh`, which mixes VALID pairs with TRAIN singleton distractors. A paper should additionally evaluate on a realistic mixed pool where many functions have no counterpart.
