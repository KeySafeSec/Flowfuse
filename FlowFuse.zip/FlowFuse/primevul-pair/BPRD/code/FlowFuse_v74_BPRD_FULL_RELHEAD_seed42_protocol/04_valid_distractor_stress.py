#!/usr/bin/env python3
"""
VALID-only stress test:
mix all VALID rows with one singleton from many TRAIN pairs.
The retrieval stage still sees source code only.
No parameter is selected from this stress test; it is diagnostic.
"""
import json, random
from pathlib import Path
from bprd_utils import (
    load_cfg, read_jsonl, make_blind_rows, build_retrieval_edges,
    discover_mutual_pairs, atomic_json
)

cfg=load_cfg()
if not cfg["distractor_stress"]["enabled"]:
    print("[SKIP] distractor stress disabled")
    raise SystemExit(0)

outdir=Path(cfg["work_dir"])
sel=json.load(open(outdir/"selected_config.json"))
valid=read_jsonl(cfg["valid_jsonl"])
train=read_jsonl(cfg["train_jsonl"])

# One row per TRAIN pair => its true counterpart is intentionally absent from stress pool.
by_pid={}
for r in train:
    pid=str(r["pair_id"])
    if pid not in by_pid:
        by_pid[pid]=r
singletons=list(by_pid.values())
random.Random(int(cfg["random_seed"])).shuffle(singletons)
singletons=singletons[:int(cfg["distractor_stress"]["max_singletons_from_train"])]

pool=[]
truth=[]
for r in valid:
    pool.append({"func":r["func"]})
    truth.append({"kind":"valid","pair_id":str(r["pair_id"])})
for r in singletons:
    pool.append({"func":r["func"]})
    truth.append({"kind":"distractor","pair_id":None})

blind=make_blind_rows(pool)
print("="*100)
print(f"VALID distractor stress: valid={len(valid)} singleton_distractors={len(singletons)} total={len(pool)}")
print("[INTEGRITY] retrieval input remains code only.")
edges=build_retrieval_edges(blind,cfg["retrieval"])
pairs=discover_mutual_pairs(
    len(pool),edges,
    float(sel["retrieval"]["threshold"]),
    float(sel["retrieval"]["margin"])
)

tp=fp=valid_involved=0
for p in pairs:
    a,b=truth[p["i"]],truth[p["j"]]
    if a["kind"]=="valid" or b["kind"]=="valid":
        valid_involved += 1
        if a["kind"]=="valid" and b["kind"]=="valid" and a["pair_id"]==b["pair_id"]:
            tp += 1
        else:
            fp += 1
precision=tp/(tp+fp) if tp+fp else 0.
recall=tp/int(cfg["expected"]["valid_pairs"])

rep={
    "valid_rows":len(valid),
    "distractor_singletons":len(singletons),
    "predicted_pairs_total":len(pairs),
    "predicted_pairs_involving_valid":valid_involved,
    "true_valid_pairs_recovered":tp,
    "false_pairs_involving_valid":fp,
    "precision_on_valid_involved":precision,
    "recall_of_valid_true_pairs":recall,
    "test_opened":False
}
atomic_json(outdir/"VALID_DISTRACTOR_STRESS.json",rep)
print(json.dumps(rep,indent=2))
print("TEST = NOT OPENED")
