#!/usr/bin/env python3
import numpy as np
from scipy import sparse
from sklearn.linear_model import SGDClassifier
from bprd_utils import discover_mutual_pairs, sigmoid, logit

# mutual retrieval
edges=[
 {"i":0,"j":1,"score":0.95},
 {"i":0,"j":2,"score":0.60},
 {"i":1,"j":2,"score":0.55},
 {"i":2,"j":3,"score":0.96},
 {"i":1,"j":3,"score":0.50}
]
pairs=discover_mutual_pairs(4,edges,0.8,0.1)
assert any({p["i"],p["j"]}=={0,1} for p in pairs),pairs

# anti-symmetric linear head
D=sparse.csr_matrix([[1.,0.5,-0.2],[0.4,1.1,0.3],[0.8,-0.2,0.7]])
X=sparse.vstack([D,-D]); y=np.array([1,1,1,0,0,0])
clf=SGDClassifier(loss="log_loss",fit_intercept=False,alpha=1e-4,random_state=42,max_iter=2000,tol=1e-6)
clf.fit(X,y)
a=clf.decision_function(D); b=clf.decision_function(-D)
assert np.max(np.abs(a+b)) < 1e-8, (a,b)
assert abs(sigmoid(logit(.7))-.7) < 1e-8
print("[SELFTEST PASS] mutual retrieval + anti-symmetric head")
