# BPRD: Blind Patch-pair Retrieval and Relative Vulnerability Disambiguation

## Research question

Can vulnerability detection improve when a system is allowed to first discover a likely security-patch counterpart, without receiving benchmark pair identity?

## Distinction from oracle paired inference

Oracle paired inference:

```text
official pair_id -> vulnerable function + patched function -> joint classification
```

BPRD:

```text
unlabeled code pool -> discover counterpart from code -> relative decision
```

No official pair metadata enters the retrieval stage.

## Stage 1 — Blind counterpart retrieval

The current system uses character 4–5 gram TF-IDF and cosine similarity. For every function, the system selects candidate neighbors and only accepts a pair when:

1. A's top neighbor is B;
2. B's top neighbor is A;
3. cosine similarity exceeds a VALID-selected threshold;
4. top1-minus-top2 similarity margin exceeds a VALID-selected threshold.

This produced near-perfect VALID retrieval in the first experiment.

## Stage 2 — Anti-symmetric relative orientation

The v7.4 UniXcoder detector already provides useful relative direction:

```text
score(V) > score(P)
```

far more often than both samples are absolutely classified correctly.

The new orientation head learns a TRAIN-only patch-direction signal from code delta:

```text
D = TFIDF(A) - TFIDF(B)
r = w^T D
```

with no intercept and swapped training examples. Therefore:

```text
r(B,A) = -r(A,B)
```

by construction.

The final relative signal can combine:

```text
normalized v7.4 logit difference
+
normalized learned code-delta direction
```

VALID selects the fusion weight and strength.

## Stage 3 — Single-function fallback

If no confident counterpart is found, BPRD returns the original v7.4 single-function prediction. This makes the formulation meaningful beyond a benchmark where every item is artificially paired.

## Evaluation protocol

### TRAIN
Allowed:
- target
- pair_id
- current source code

Used to train only the relative orientation head.

### VALID
Pair identity and labels are opened only after blind candidate similarities are frozen. VALID selects:
- retrieval threshold;
- retrieval margin;
- relative-head regularization;
- fusion weights;
- score transformation.

### TEST
All configuration is frozen before TEST. During TEST inference:
- retrieval sees source code only;
- relative inference sees code + frozen v7.4 score;
- official pair_id/target are opened only after predictions have been saved, for evaluation.

## Main claims that would be defensible

Weak claim:
> Known vulnerability/patch pairs are easier to classify jointly.

Stronger claim:
> Security-patch counterpart discovery is itself a useful inference primitive: when a high-confidence counterpart is available, relative security-state disambiguation substantially improves vulnerability detection, while an ordinary single-function detector handles unmatched functions.

For an FSE-strength paper, validate this on mixed pools with distractors and at least one additional patch-pair dataset.
