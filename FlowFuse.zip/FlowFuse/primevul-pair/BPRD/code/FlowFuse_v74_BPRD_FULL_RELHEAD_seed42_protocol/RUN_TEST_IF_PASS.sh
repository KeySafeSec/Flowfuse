#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

if [[ ! -f "<ARTIFACT_ROOT>/output/run_v74_bprd_full_relhead_seed42_protocol/VALID_GATE_PASS" ]]; then
  echo "[LOCKED] VALID gate file missing."
  exit 2
fi
if [[ "$(tr -d '[:space:]' < <ARTIFACT_ROOT>/output/run_v74_bprd_full_relhead_seed42_protocol/VALID_GATE_PASS)" != "PASS" ]]; then
  echo "[LOCKED] VALID gate failed. TEST will not be opened."
  exit 3
fi

bash 06_TEST_IF_PASS.sh
