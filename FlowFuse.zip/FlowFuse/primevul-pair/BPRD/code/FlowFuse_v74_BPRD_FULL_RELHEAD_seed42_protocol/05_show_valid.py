#!/usr/bin/env python3
import json
from pathlib import Path
from bprd_utils import load_cfg
cfg=load_cfg(); out=Path(cfg["work_dir"])
for name in ("VALID_REPORT.json","selected_config.json","VALID_DISTRACTOR_STRESS.json"):
    p=out/name
    if p.is_file():
        print("\n"+"="*100+"\n"+name+"\n"+"="*100)
        print(json.dumps(json.load(open(p)),indent=2))
