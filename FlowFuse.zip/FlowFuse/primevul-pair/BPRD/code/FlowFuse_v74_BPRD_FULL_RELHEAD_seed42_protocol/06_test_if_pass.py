#!/usr/bin/env python3
import argparse, json
from pathlib import Path
import numpy as np
from scipy import sparse
import joblib

from bprd_utils import (
    load_cfg, read_jsonl, make_blind_rows, write_jsonl, build_retrieval_edges,
    discover_mutual_pairs, parse_score_file, logit, sigmoid, full_metrics,
    format_metric, atomic_json
)

ap=argparse.ArgumentParser()
ap.add_argument("--unlock-test",action="store_true",
                help="Explicit acknowledgement that TEST may now be opened.")
args=ap.parse_args()
if not args.unlock_test:
    raise SystemExit("[LOCKED] TEST not opened. Re-run with --unlock-test only after VALID gate PASS.")

cfg=load_cfg()
outdir=Path(cfg["work_dir"])
gate=(outdir/"VALID_GATE_PASS").read_text(encoding="utf-8").strip() if (outdir/"VALID_GATE_PASS").is_file() else ""
sel_path=outdir/"selected_config.json"
if gate!="PASS" or not sel_path.is_file():
    raise SystemExit("[LOCKED] VALID gate did not pass; TEST not opened.")
sel=json.load(open(sel_path))
if not sel.get("valid_gate_passed",False):
    raise SystemExit("[LOCKED] selected_config says VALID gate failed.")

test_path=Path(cfg["test_jsonl"])
score_path=Path(cfg["v74_test_scores"])
if not test_path.is_file():
    raise SystemExit(f"[FATAL] missing TEST jsonl: {test_path}")
if not score_path.is_file():
    raise SystemExit(f"[FATAL] missing v7.4 TEST scores: {score_path}")

# From here TEST is intentionally opened once, with all hyperparameters frozen.
rows=read_jsonl(test_path)
expected=int(cfg["expected"]["test_rows"])
if len(rows)!=expected:
    raise RuntimeError(f"Expected TEST rows={expected}, got {len(rows)}")

# ---------------------------------------------------------------------
# Inference phase: strip metadata before blind retrieval.
# ---------------------------------------------------------------------
blind=make_blind_rows(rows)
write_jsonl(outdir/"blind_test.jsonl",blind)
print("="*120)
print("TEST INFERENCE — FROZEN CONFIG")
print("="*120)
print("[FROZEN]",json.dumps(sel,indent=2))
print("[PAIR DISCOVERY] TEST retrieval receives code only.")
edges=build_retrieval_edges(blind,cfg["retrieval"])
pairs=discover_mutual_pairs(
    len(rows),edges,
    float(sel["retrieval"]["threshold"]),
    float(sel["retrieval"]["margin"])
)
write_jsonl(outdir/"test_blind_pairs.jsonl",pairs)

scores,score_fmt=parse_score_file(score_path,len(rows))
thr=float(sel["v74_threshold"])
base_pred=[int(s>=thr) for s in scores]
z=np.asarray([logit(s) for s in scores],dtype=np.float64)

bundle=joblib.load(outdir/"relative_head.joblib")
vec=bundle["vectorizer"]
alpha=str(sel["orientation"]["head_alpha"])
# tolerate string formatting mismatch in joblib dict
if alpha not in bundle["models"]:
    alpha=min(bundle["models"].keys(),key=lambda k:abs(float(k)-float(sel["orientation"]["head_alpha"])))
clf=bundle["models"][alpha]
Xt=vec.transform([r["func"] for r in rows])
D=sparse.vstack([Xt[int(p["i"])]-Xt[int(p["j"])] for p in pairs]).tocsr() if pairs else sparse.csr_matrix((0,Xt.shape[1]))
h=np.asarray(clf.decision_function(D),dtype=np.float64) if pairs else np.zeros(0)

wv=float(sel["orientation"]["v74_weight"])
wh=float(sel["orientation"]["head_weight"])
scale=float(sel["orientation"]["scale"])
v74s=float(sel["orientation"]["v74_delta_scale"])
heads=float(sel["orientation"]["head_delta_scale"])
mode=sel["orientation"]["mode"]

new_scores=list(scores); new_pred=list(base_pred)
for k,p in enumerate(pairs):
    i,j=int(p["i"]),int(p["j"])
    d0=z[i]-z[j]
    rel=wv*(d0/v74s)+wh*(h[k]/heads)
    if mode=="exclusive":
        new_scores[i]=sigmoid(scale*rel)
        new_scores[j]=sigmoid(-scale*rel)
        if rel>0: new_pred[i],new_pred[j]=1,0
        elif rel<0: new_pred[i],new_pred[j]=0,1
    else:
        center=(z[i]+z[j])/2.0
        new_scores[i]=sigmoid(center+scale*rel/2.0)
        new_scores[j]=sigmoid(center-scale*rel/2.0)
        new_pred[i]=int(new_scores[i]>=thr)
        new_pred[j]=int(new_scores[j]>=thr)

# Save inference outputs before using truth for metrics.
pred_rows=[]
for i,(s,p) in enumerate(zip(new_scores,new_pred)):
    pred_rows.append({
        "row_no":i,
        "blind_id":blind[i]["blind_id"],
        "score":float(s),
        "pred":int(p),
        "paired_by_method":False
    })
for p in pairs:
    pred_rows[int(p["i"])]["paired_by_method"]=True
    pred_rows[int(p["j"])]["paired_by_method"]=True
write_jsonl(outdir/"TEST_PREDICTIONS_BLIND.jsonl",pred_rows)

# ---------------------------------------------------------------------
# Evaluation phase only: now use hidden TEST target/pair_id.
# No selection/tuning occurs here.
# ---------------------------------------------------------------------
base=full_metrics(rows,scores,base_pred,"V74_SINGLE_TEST")
final=full_metrics(rows,new_scores,new_pred,"BPRD_FROZEN_TEST")
true_pid=[str(r["pair_id"]) for r in rows]
tp=sum(1 for p in pairs if true_pid[int(p["i"])]==true_pid[int(p["j"])])
fp=len(pairs)-tp
true_pairs=int(cfg["expected"]["test_pairs"])
ret={
    "pred_pairs":len(pairs),
    "tp":tp,"fp":fp,
    "precision":tp/len(pairs) if pairs else 0.,
    "recall":tp/true_pairs if true_pairs else 0.
}
if ret["precision"]+ret["recall"]:
    ret["f1"]=2*ret["precision"]*ret["recall"]/(ret["precision"]+ret["recall"])
else:
    ret["f1"]=0.

report={
    "version":sel["version"],
    "selected_on_valid":sel,
    "score_parser":score_fmt,
    "retrieval_test":ret,
    "base_test":base,
    "bprd_test":final,
    "auc_gain":final["AUC"]-base["AUC"],
    "pc_absolute_gain":final["P-C_rate"]-base["P-C_rate"],
    "test_opened":True,
    "test_used_for_selection":False
}
atomic_json(outdir/"TEST_REPORT_FROZEN.json",report)

print("-"*120)
print(f"TEST retrieval precision={ret['precision']:.4f} recall={ret['recall']:.4f} F1={ret['f1']:.4f} pairs={ret['pred_pairs']}")
print(format_metric(base))
print(format_metric(final))
print(f"AUC gain={report['auc_gain']:+.6f}")
print(f"P-C absolute gain={report['pc_absolute_gain']:+.4f}")
print("[IMPORTANT] TEST was evaluated once with VALID-frozen hyperparameters; no TEST tuning performed.")
print("REPORT =",outdir/"TEST_REPORT_FROZEN.json")
print("="*120)
