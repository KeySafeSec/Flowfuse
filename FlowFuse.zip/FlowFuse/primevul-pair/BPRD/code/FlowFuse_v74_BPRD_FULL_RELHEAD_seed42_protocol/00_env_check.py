#!/usr/bin/env python3
from pathlib import Path
import sys
from bprd_utils import load_cfg, read_jsonl, parse_score_file

cfg = load_cfg()
print("="*100)
print("FlowFuse v7.4 BPRD FULL — environment / asset check")
print("="*100)

for mod in ("numpy", "scipy", "sklearn", "joblib"):
    try:
        m = __import__(mod)
        print(f"[OK] {mod:10s} {getattr(m,'__version__','')}")
    except Exception as e:
        raise SystemExit(f"[FATAL] import {mod}: {e}")

exp = cfg["expected"]
for split in ("train","valid"):
    p = Path(cfg[f"{split}_jsonl"])
    if not p.is_file():
        raise SystemExit(f"[FATAL] missing {split}: {p}")
    rows = read_jsonl(p)
    expected = int(exp[f"{split}_rows"])
    print(f"[OK] {split:5s} rows={len(rows)} path={p}")
    if len(rows) != expected:
        raise SystemExit(f"[FATAL] {split} expected {expected}, got {len(rows)}")
    for k in ("func","target","pair_id"):
        if any(k not in r for r in rows):
            raise SystemExit(f"[FATAL] {split} missing field {k}")

vp = Path(cfg["v74_valid_scores"])
if not vp.is_file():
    raise SystemExit(f"[FATAL] missing v7.4 valid scores: {vp}")
scores, fmt = parse_score_file(vp, int(exp["valid_rows"]))
print(f"[OK] v7.4 VALID scores n={len(scores)} parser={fmt}")

work = Path(cfg["work_dir"])
work.mkdir(parents=True, exist_ok=True)
print("[INTEGRITY] TRAIN labels/pair_id may train the relative orientation head.")
print("[INTEGRITY] VALID labels/pair_id may select gates/hyperparameters.")
print("[INTEGRITY] TEST is not opened by RUN_VALID_ONLY.sh.")
print("[PASS]")
