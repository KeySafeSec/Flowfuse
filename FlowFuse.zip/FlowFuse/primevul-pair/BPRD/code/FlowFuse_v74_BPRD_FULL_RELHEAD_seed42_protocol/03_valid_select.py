#!/usr/bin/env python3
import json, itertools
from pathlib import Path
import numpy as np
from scipy import sparse
import joblib

from bprd_utils import (
    load_cfg, read_jsonl, write_jsonl, atomic_json, discover_mutual_pairs,
    evaluate_retrieval, parse_score_file, logit, sigmoid, full_metrics,
    median_abs_scale, format_metric
)

cfg = load_cfg()
outdir = Path(cfg["work_dir"])
rows = read_jsonl(cfg["valid_jsonl"])
blind = read_jsonl(outdir/"blind_valid.jsonl")
edges = read_jsonl(outdir/"valid_candidate_edges.jsonl")
scores, score_fmt = parse_score_file(cfg["v74_valid_scores"], len(rows))
thr = float(cfg["v74_threshold"])
base_pred = [int(s >= thr) for s in scores]
base = full_metrics(rows, scores, base_pred, "V74_SINGLE")

# ---------------------------------------------------------------------
# 1) Select retrieval gate using VALID pair truth only AFTER edges frozen.
# ---------------------------------------------------------------------
retrieval_grid = []
best_ret = None
for th in cfg["retrieval"]["threshold_grid"]:
    for mg in cfg["retrieval"]["margin_grid"]:
        pairs = discover_mutual_pairs(len(rows), edges, float(th), float(mg))
        m = evaluate_retrieval(pairs, rows)
        row = {"threshold": float(th), "margin": float(mg), **m}
        retrieval_grid.append(row)
        # F1 primary; precision then recall then #pairs.
        key = (m["f1"], m["precision"], m["recall"], m["pred_pairs"])
        if best_ret is None or key > best_ret[0]:
            best_ret = (key, row, pairs)

_, ret_cfg, pairs = best_ret
write_jsonl(outdir/"valid_retrieval_grid.jsonl", retrieval_grid)
write_jsonl(outdir/"valid_blind_pairs.jsonl", pairs)

print("="*120)
print("VALID blind retrieval selected")
print("="*120)
print(json.dumps(ret_cfg, indent=2))
print(f"unmatched rows = {len(rows)-2*len(pairs)} / {len(rows)}")

# ---------------------------------------------------------------------
# 2) Compute v7.4 pair deltas.
# ---------------------------------------------------------------------
z = np.asarray([logit(s) for s in scores], dtype=np.float64)
v74_delta = np.asarray([z[int(p["i"])] - z[int(p["j"])] for p in pairs], dtype=np.float64)
v74_scale = median_abs_scale(v74_delta)

# ---------------------------------------------------------------------
# 3) Apply TRAIN-only anti-symmetric relative heads to VALID pairs.
# ---------------------------------------------------------------------
bundle = joblib.load(outdir/"relative_head.joblib")
vec, models = bundle["vectorizer"], bundle["models"]
Xv = vec.transform([r["func"] for r in rows])
D = sparse.vstack([Xv[int(p["i"])] - Xv[int(p["j"])] for p in pairs]).tocsr()

head_scores = {}
head_scales = {}
for alpha, clf in models.items():
    h = np.asarray(clf.decision_function(D), dtype=np.float64)
    head_scores[alpha] = h
    head_scales[alpha] = median_abs_scale(h)

# ---------------------------------------------------------------------
# 4) Search only on VALID. Head weight 0 reproduces successful BPRD-v1.
# ---------------------------------------------------------------------
search = []
best = None
for alpha, h in head_scores.items():
    hs = head_scales[alpha]
    for wv, wh, scale, mode in itertools.product(
        cfg["fusion"]["v74_weight_grid"],
        cfg["fusion"]["head_weight_grid"],
        cfg["fusion"]["scale_grid"],
        cfg["fusion"]["modes"],
    ):
        wv=float(wv); wh=float(wh); scale=float(scale)
        if wv == 0.0 and wh == 0.0:
            continue
        rel = wv*(v74_delta/v74_scale) + wh*(h/hs)

        new_scores = list(scores)
        new_pred = list(base_pred)
        correct_orientation = 0
        correct_retrieved = 0

        for k,p in enumerate(pairs):
            i,j=int(p["i"]),int(p["j"])
            r=float(rel[k])
            if mode == "exclusive":
                # Probability is purely relative; classification is exactly one-vulnerable/one-patched.
                new_scores[i]=sigmoid(scale*r)
                new_scores[j]=sigmoid(-scale*r)
                if r > 0:
                    new_pred[i],new_pred[j]=1,0
                elif r < 0:
                    new_pred[i],new_pred[j]=0,1
                # exact tie keeps original predictions
            else:
                # Preserve the pair's original global-risk center, replace/amplify only contrast.
                center=(z[i]+z[j])/2.0
                new_scores[i]=sigmoid(center + scale*r/2.0)
                new_scores[j]=sigmoid(center - scale*r/2.0)
                new_pred[i]=int(new_scores[i] >= thr)
                new_pred[j]=int(new_scores[j] >= thr)

            if str(rows[i]["pair_id"]) == str(rows[j]["pair_id"]):
                correct_retrieved += 1
                if int(rows[i]["target"]) == 1:
                    correct_orientation += int(r > 0)
                else:
                    correct_orientation += int(r < 0)

        name=f"BPRD alpha={alpha} wv={wv:g} wh={wh:g} scale={scale:g} {mode}"
        m=full_metrics(rows,new_scores,new_pred,name)
        orient=correct_orientation/correct_retrieved if correct_retrieved else None
        rec={
            "head_alpha":float(alpha),
            "v74_weight":wv,
            "head_weight":wh,
            "scale":scale,
            "mode":mode,
            "v74_delta_scale":v74_scale,
            "head_delta_scale":hs,
            "orientation_acc_on_correct_retrievals":orient,
            **m
        }
        search.append(rec)
        # AUC is primary. P-C, MCC, orientation are diagnostics/tie-breakers.
        key=(m["AUC"],m["P-C_rate"],m["mcc"], orient if orient is not None else -1)
        if best is None or key > best[0]:
            best=(key,rec,new_scores,new_pred)

best_rec = best[1]
atomic_json(outdir/"valid_search_top.json", {
    "best": best_rec,
    "top20": sorted(search, key=lambda r:(r["AUC"],r["P-C_rate"],r["mcc"]), reverse=True)[:20]
})

auc_gain = best_rec["AUC"] - base["AUC"]
pc_gain = best_rec["P-C_rate"] - base["P-C_rate"]
gcfg = cfg["valid_gate"]
gate_pass = (
    ret_cfg["precision"] >= float(gcfg["min_retrieval_precision"])
    and ret_cfg["recall"] >= float(gcfg["min_retrieval_recall"])
    and auc_gain >= float(gcfg["min_auc_gain_over_v74"])
    and pc_gain >= float(gcfg["min_pc_absolute_gain"])
)

selected = {
    "version":"FlowFuse-v7.4-BPRD-full-relhead-v1",
    "retrieval":{
        "threshold":ret_cfg["threshold"],
        "margin":ret_cfg["margin"],
        "precision_valid":ret_cfg["precision"],
        "recall_valid":ret_cfg["recall"],
        "f1_valid":ret_cfg["f1"]
    },
    "orientation":{
        "head_alpha":best_rec["head_alpha"],
        "v74_weight":best_rec["v74_weight"],
        "head_weight":best_rec["head_weight"],
        "scale":best_rec["scale"],
        "mode":best_rec["mode"],
        "v74_delta_scale":best_rec["v74_delta_scale"],
        "head_delta_scale":best_rec["head_delta_scale"]
    },
    "v74_threshold":thr,
    "valid_gate_passed":bool(gate_pass),
    "valid_auc_gain":auc_gain,
    "valid_pc_absolute_gain":pc_gain,
    "test_opened":False
}
atomic_json(outdir/"selected_config.json", selected)
atomic_json(outdir/"VALID_REPORT.json", {
    "score_parser":score_fmt,
    "retrieval":ret_cfg,
    "base":base,
    "best":best_rec,
    "auc_gain":auc_gain,
    "pc_absolute_gain":pc_gain,
    "gate_passed":bool(gate_pass),
    "test_opened":False
})
(outdir/"VALID_GATE_PASS").write_text("PASS\n" if gate_pass else "FAIL\n",encoding="utf-8")

print("="*120)
print("FLOWFUSE v7.4 BPRD FULL — VALID RESULT")
print("="*120)
print(f"Retrieval precision={ret_cfg['precision']:.4f} recall={ret_cfg['recall']:.4f} F1={ret_cfg['f1']:.4f} pairs={ret_cfg['pred_pairs']}")
print("-"*120)
print(format_metric(base))
print(format_metric(best_rec))
print("-"*120)
print(f"orientation_acc_on_correct_retrievals={best_rec['orientation_acc_on_correct_retrievals']:.4f}")
print(f"AUC gain={auc_gain:+.6f}")
print(f"P-C absolute gain={pc_gain:+.4f}")
print(f"CONTINUE_GATE={'PASS' if gate_pass else 'FAIL'}")
print("TEST = NOT OPENED")
print("SELECTED =", outdir/"selected_config.json")
print("="*120)
