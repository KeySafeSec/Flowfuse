#!/usr/bin/env python3
import csv
import json
import hashlib
from pathlib import Path
from collections import defaultdict

import numpy as np
from sklearn.metrics import f1_score, matthews_corrcoef

ROOT = Path(
    "<ARTIFACT_ROOT>"
)

TEST = ROOT / (
    "data/primevul/data/primevul_final_datasets/paired/"
    "single_function/processed_DataFlow_v7_4_pmcl_diverse/test_synced.jsonl"
)
TRAIN = TEST.parent / "train_synced.jsonl"
VALID = TEST.parent / "valid_synced.jsonl"

SINGLE = ROOT / "output/run_unixcoder_v7_4_pmcl_diverse/predictions_test.txt"

BPRD_DIR = ROOT / "output/run_v74_bprd_full_relhead_seed42_protocol"
BPRD = BPRD_DIR / "TEST_PREDICTIONS_BLIND.jsonl"
REPORT = BPRD_DIR / "TEST_REPORT_FROZEN.json"
SELECTED = BPRD_DIR / "selected_config.json"

OUT = ROOT / "output/flowfuse_fse2027_posthoc_final"
OUT.mkdir(parents=True, exist_ok=True)

BOOTSTRAP_SEED = 20270930
N_BOOT = 10000


def load_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(x) for x in f if x.strip()]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def metric_f1(y, p):
    return float(f1_score(y, p, zero_division=0))


def metric_mcc(y, p):
    return float(matthews_corrcoef(y, p))


def pair_accuracy(rows, pred_key):
    """
    Repair-pair accuracy:
    a pair is correct iff vulnerable member is predicted 1
    and fixed/non-vulnerable member is predicted 0.
    """
    by_pair = defaultdict(list)
    for r in rows:
        by_pair[r["pair_id"]].append(r)

    ok = []
    for pid, rs in by_pair.items():
        if len(rs) != 2:
            raise RuntimeError(f"{pid}: expected 2 rows, got {len(rs)}")

        labels = sorted(int(x["target"]) for x in rs)
        if labels != [0, 1]:
            raise RuntimeError(f"{pid}: targets are not [0,1]: {labels}")

        correct = all(int(x[pred_key]) == int(x["target"]) for x in rs)
        ok.append(int(correct))

    return float(np.mean(ok))


# ------------------------------------------------------------------
# 1. Load canonical test population
# ------------------------------------------------------------------
test = load_jsonl(TEST)

assert len(test) == 808, len(test)
assert len({r["idx"] for r in test}) == 808

pairs = defaultdict(list)
for row_no, r in enumerate(test):
    r["_row_no"] = row_no
    pairs[r["pair_id"]].append(r)

assert len(pairs) == 404, len(pairs)

for pid, rs in pairs.items():
    assert len(rs) == 2, (pid, len(rs))
    assert sorted(int(x["target"]) for x in rs) == [0, 1], pid

# ------------------------------------------------------------------
# 2. Single: strict idx join
# ------------------------------------------------------------------
with open(SINGLE, encoding="utf-8", newline="") as f:
    single_rows = list(csv.DictReader(f, delimiter="\t"))

assert len(single_rows) == 808, len(single_rows)

single_by_idx = {}
for r in single_rows:
    idx = int(r["idx"])
    assert idx not in single_by_idx
    single_by_idx[idx] = r

assert set(single_by_idx) == {int(r["idx"]) for r in test}

for r in test:
    s = single_by_idx[int(r["idx"])]

    # integrity: prediction file truth must match dataset truth
    assert int(s["true"]) == int(r["target"]), (
        r["idx"], s["true"], r["target"]
    )

    r["single_pred"] = int(s["pred"])
    r["single_score"] = float(s["prob1"])

# ------------------------------------------------------------------
# 3. BPRD: strict row_no join
# ------------------------------------------------------------------
bprd = load_jsonl(BPRD)
assert len(bprd) == 808, len(bprd)

bprd_by_row = {}
for r in bprd:
    n = int(r["row_no"])
    assert n not in bprd_by_row
    bprd_by_row[n] = r

assert set(bprd_by_row) == set(range(808))

for r in test:
    b = bprd_by_row[r["_row_no"]]
    r["bprd_pred"] = int(b["pred"])
    r["bprd_score"] = float(b["score"])
    r["paired_by_method"] = bool(b["paired_by_method"])
    r["blind_id"] = b["blind_id"]

# ------------------------------------------------------------------
# 4. Point estimates
# ------------------------------------------------------------------
y = np.asarray([int(r["target"]) for r in test], dtype=int)
sp = np.asarray([r["single_pred"] for r in test], dtype=int)
bp = np.asarray([r["bprd_pred"] for r in test], dtype=int)

point = {
    "Single": {
        "F1": metric_f1(y, sp),
        "MCC": metric_mcc(y, sp),
        "PairAcc": pair_accuracy(test, "single_pred"),
    },
    "BPRD": {
        "F1": metric_f1(y, bp),
        "MCC": metric_mcc(y, bp),
        "PairAcc": pair_accuracy(test, "bprd_pred"),
    },
}

point["Delta_BPRD_minus_Single"] = {
    k: point["BPRD"][k] - point["Single"][k]
    for k in ("F1", "MCC", "PairAcc")
}

# ------------------------------------------------------------------
# 5. Pair-cluster bootstrap
# Same 404 sampled pair IDs are used for Single and BPRD.
# ------------------------------------------------------------------
pair_ids = np.asarray(sorted(pairs.keys()), dtype=object)
rng = np.random.default_rng(BOOTSTRAP_SEED)

boot = {
    "Single": {"F1": [], "MCC": [], "PairAcc": []},
    "BPRD": {"F1": [], "MCC": [], "PairAcc": []},
    "Delta_BPRD_minus_Single": {
        "F1": [], "MCC": [], "PairAcc": []
    },
}

for _ in range(N_BOOT):
    sampled = rng.choice(pair_ids, size=len(pair_ids), replace=True)

    # Duplicate pair draws must remain duplicated in the bootstrap sample.
    rs = []
    for draw_id, pid in enumerate(sampled):
        for original in pairs[pid]:
            x = dict(original)
            x["_bootstrap_pair"] = draw_id
            rs.append(x)

    yy = np.asarray([int(r["target"]) for r in rs], dtype=int)
    ss = np.asarray([r["single_pred"] for r in rs], dtype=int)
    bb = np.asarray([r["bprd_pred"] for r in rs], dtype=int)

    sf1 = metric_f1(yy, ss)
    smcc = metric_mcc(yy, ss)
    bf1 = metric_f1(yy, bb)
    bmcc = metric_mcc(yy, bb)

    # PairAcc over bootstrap draws, not unique original pair_id.
    s_pair_correct = []
    b_pair_correct = []

    by_draw = defaultdict(list)
    for r in rs:
        by_draw[r["_bootstrap_pair"]].append(r)

    for drs in by_draw.values():
        assert len(drs) == 2
        s_pair_correct.append(
            int(all(r["single_pred"] == int(r["target"]) for r in drs))
        )
        b_pair_correct.append(
            int(all(r["bprd_pred"] == int(r["target"]) for r in drs))
        )

    spa = float(np.mean(s_pair_correct))
    bpa = float(np.mean(b_pair_correct))

    vals_s = {"F1": sf1, "MCC": smcc, "PairAcc": spa}
    vals_b = {"F1": bf1, "MCC": bmcc, "PairAcc": bpa}

    for m in ("F1", "MCC", "PairAcc"):
        boot["Single"][m].append(vals_s[m])
        boot["BPRD"][m].append(vals_b[m])
        boot["Delta_BPRD_minus_Single"][m].append(
            vals_b[m] - vals_s[m]
        )


def ci(v):
    a = np.asarray(v, dtype=float)
    lo, hi = np.percentile(a, [2.5, 97.5])
    return {
        "low": float(lo),
        "high": float(hi),
    }


summary = {
    "protocol": {
        "bootstrap_unit": "repair pair",
        "test_pairs": 404,
        "test_functions": 808,
        "bootstrap_resamples": N_BOOT,
        "bootstrap_seed": BOOTSTRAP_SEED,
        "ci": "95% percentile",
        "paired_delta": True,
    },
    "point_estimates": point,
    "bootstrap_ci": {
        method: {m: ci(v) for m, v in metrics.items()}
        for method, metrics in boot.items()
    },
    "preprocessing_sha256": {
        "train_synced.jsonl": sha256(TRAIN),
        "valid_synced.jsonl": sha256(VALID),
        "test_synced.jsonl": sha256(TEST),
    },
}

if REPORT.exists():
    with open(REPORT, encoding="utf-8") as f:
        summary["frozen_test_report"] = json.load(f)

if SELECTED.exists():
    with open(SELECTED, encoding="utf-8") as f:
        summary["selected_config"] = json.load(f)

# ------------------------------------------------------------------
# 6. Save machine-readable and paper-ready output
# ------------------------------------------------------------------
json_path = OUT / "paired_bootstrap_seed42.json"
with open(json_path, "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2)

csv_path = OUT / "paired_bootstrap_seed42.csv"
with open(csv_path, "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["Method", "Metric", "Point", "CI_low", "CI_high"])
    for method in ("Single", "BPRD", "Delta_BPRD_minus_Single"):
        for metric in ("F1", "MCC", "PairAcc"):
            p = point[method][metric]
            c = summary["bootstrap_ci"][method][metric]
            w.writerow([method, metric, p, c["low"], c["high"]])

print("\n============================================================")
print("FlowFuse FSE 2027 — paired repair-pair bootstrap")
print("============================================================")
print(f"Population : 808 functions / 404 repair pairs")
print(f"Bootstrap  : {N_BOOT:,} pair-cluster resamples")
print(f"Seed       : {BOOTSTRAP_SEED}")
print()

for method in ("Single", "BPRD", "Delta_BPRD_minus_Single"):
    print(method)
    for metric in ("F1", "MCC", "PairAcc"):
        p = point[method][metric]
        c = summary["bootstrap_ci"][method][metric]
        print(
            f"  {metric:7s}: "
            f"{100*p:7.3f} "
            f"[{100*c['low']:7.3f}, {100*c['high']:7.3f}]"
        )
    print()

print("SHA-256")
for k,v in summary["preprocessing_sha256"].items():
    print(f"  {k}: {v}")

print()
print("WROTE:", json_path)
print("WROTE:", csv_path)
