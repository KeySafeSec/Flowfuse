#!/usr/bin/env python3
import json
from pathlib import Path
import numpy as np
from scipy import sparse
import joblib

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier

from bprd_utils import load_cfg, read_jsonl, complete_pair_groups, atomic_json

cfg = load_cfg()
rcfg = cfg["relative_head"]
rows = read_jsonl(cfg["train_jsonl"])
groups = complete_pair_groups(rows)
expected = int(cfg["expected"]["train_pairs"])
if len(groups) != expected:
    raise RuntimeError(f"Expected {expected} complete TRAIN pairs, got {len(groups)}")

codes = [r["func"] for r in rows]
print("="*100)
print("TRAIN anti-symmetric code-delta relative head")
print("="*100)
print(f"TRAIN rows={len(rows)} pairs={len(groups)}")
print("[TFIDF] fitting TRAIN-only orientation vocabulary ...")

vec = TfidfVectorizer(
    analyzer=rcfg["analyzer"],
    ngram_range=(int(rcfg["ngram_min"]), int(rcfg["ngram_max"])),
    max_features=int(rcfg["max_features"]),
    min_df=int(rcfg["min_df"]),
    sublinear_tf=bool(rcfg["sublinear_tf"]),
    lowercase=False,
    dtype=np.float32,
    norm="l2",
)
X = vec.fit_transform(codes)
print(f"[TFIDF] train matrix={X.shape} nnz={X.nnz}")

# Build D = vulnerable - patched.
diffs = []
for pid, g in groups.items():
    diffs.append(X[g[1]] - X[g[0]])
D = sparse.vstack(diffs).tocsr()

# Explicit swapped examples enforce anti-symmetry.
Xpair = sparse.vstack([D, -D]).tocsr()
y = np.concatenate([np.ones(D.shape[0], dtype=np.int64),
                    np.zeros(D.shape[0], dtype=np.int64)])

models = {}
for alpha in rcfg["sgd_alpha_grid"]:
    alpha = float(alpha)
    clf = SGDClassifier(
        loss="log_loss",
        penalty="l2",
        alpha=alpha,
        fit_intercept=False,
        max_iter=int(rcfg["max_iter"]),
        tol=float(rcfg["tol"]),
        shuffle=True,
        random_state=int(cfg["random_seed"]),
        average=bool(rcfg.get("average", True)),
    )
    clf.fit(Xpair, y)
    # Structural check: f(-D) must be -f(D) up to numerical precision.
    a = clf.decision_function(D[:min(64, D.shape[0])])
    b = clf.decision_function(-D[:min(64, D.shape[0])])
    anti_err = float(np.max(np.abs(a + b)))
    train_dir = float(np.mean(a > 0))
    print(f"[HEAD alpha={alpha:g}] train_direction={train_dir:.4f} anti_sym_err={anti_err:.3e}")
    models[str(alpha)] = clf

outdir = Path(cfg["work_dir"])
outdir.mkdir(parents=True, exist_ok=True)
joblib.dump({"vectorizer": vec, "models": models}, outdir/"relative_head.joblib", compress=3)
atomic_json(outdir/"relative_head_meta.json", {
    "train_rows": len(rows),
    "train_pairs": len(groups),
    "features": int(X.shape[1]),
    "alphas": [float(x) for x in rcfg["sgd_alpha_grid"]],
    "anti_symmetric_by_design": True,
    "uses_valid": False,
    "uses_test": False
})
print("[SAVED]", outdir/"relative_head.joblib")
print("TEST = NOT OPENED")
