#!/usr/bin/env python3
import json, math, re, hashlib
from pathlib import Path
from collections import defaultdict
import numpy as np

def load_cfg(path="config.json"):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def read_jsonl(path):
    rows = []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for ln, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                raise RuntimeError(f"Bad JSONL {path}:{ln}: {e}")
    return rows

def write_jsonl(path, rows):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def atomic_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
    tmp.replace(path)

def logit(p):
    p = min(max(float(p), 1e-7), 1.0 - 1e-7)
    return math.log(p / (1.0 - p))

def sigmoid(z):
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    e = math.exp(z)
    return e / (1.0 + e)

def normalize_scores(vals):
    vals = [float(x) for x in vals]
    if vals and (min(vals) < 0.0 or max(vals) > 1.0):
        return [sigmoid(x) for x in vals]
    return vals

def parse_score_file(path, expected_n):
    """Parse common FlowFuse prediction exports. Returns probabilities + parser name."""
    lines = [x.strip() for x in open(path, "r", encoding="utf-8", errors="replace") if x.strip()]
    if not lines:
        raise RuntimeError(f"Empty score file: {path}")

    # JSONL
    vals = []
    ok = True
    for ln in lines:
        try:
            o = json.loads(ln)
            if not isinstance(o, dict):
                ok = False; break
            v = None
            for k in ("prob1", "prob_vul", "vuln_score", "score", "prob", "probability"):
                if k in o:
                    v = float(o[k]); break
            if v is None:
                ok = False; break
            vals.append(v)
        except Exception:
            ok = False; break
    if ok and len(vals) == expected_n:
        return normalize_scores(vals), "jsonl"

    # TSV/CSV header
    sep = "\t" if "\t" in lines[0] else ("," if "," in lines[0] else None)
    if sep is not None:
        head = [x.strip().lower() for x in lines[0].split(sep)]
        names = ("prob1", "prob_vul", "vuln_score", "score", "prob", "probability")
        col = next((head.index(k) for k in names if k in head), None)
        if col is not None:
            vals = []
            for ln in lines[1:]:
                parts = [x.strip() for x in ln.split(sep)]
                if len(parts) > col:
                    try: vals.append(float(parts[col]))
                    except Exception: pass
            if len(vals) == expected_n:
                return normalize_scores(vals), f"header:{head[col]}"

    # fallback: last numeric token on each line
    num_re = re.compile(r"(?<![A-Za-z_])[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?")
    vals = []
    for ln in lines:
        nums = num_re.findall(ln)
        if nums:
            try: vals.append(float(nums[-1]))
            except Exception: pass
    if len(vals) == expected_n:
        return normalize_scores(vals), "generic-last-number"
    if len(vals) == expected_n + 1:
        return normalize_scores(vals[1:]), "generic-last-number-skip1"

    raise RuntimeError(
        f"Cannot parse exactly {expected_n} scores from {path}; got {len(vals)}. "
        "Send the first 10 lines of the file if this happens."
    )

def make_blind_rows(rows):
    out = []
    for i, r in enumerate(rows):
        code = r.get("func", "")
        bid = hashlib.sha256((str(i) + "\0" + code).encode("utf-8", "ignore")).hexdigest()[:20]
        out.append({"blind_id": bid, "func": code})
    return out

def build_retrieval_edges(blind_rows, rcfg):
    """
    Fit TF-IDF on the unlabeled candidate pool itself. This is transductive but label-free:
    the retrieval stage sees source code only.
    """
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity

    codes = [r["func"] for r in blind_rows]
    vec = TfidfVectorizer(
        analyzer=rcfg.get("analyzer", "char"),
        ngram_range=(int(rcfg["ngram_min"]), int(rcfg["ngram_max"])),
        max_features=int(rcfg["max_features"]),
        min_df=int(rcfg.get("min_df", 1)),
        sublinear_tf=bool(rcfg.get("sublinear_tf", True)),
        lowercase=False,
        dtype=np.float32,
        norm="l2",
    )
    print(f"[TFIDF] building {rcfg['analyzer']} {rcfg['ngram_min']}-{rcfg['ngram_max']} gram representation ...")
    X = vec.fit_transform(codes)
    print(f"[TFIDF] matrix={X.shape} nnz={X.nnz}")
    print(f"[COSINE] computing {len(codes)}x{len(codes)} similarity matrix ...")
    S = cosine_similarity(X, dense_output=True)
    np.fill_diagonal(S, -1.0)

    topk = int(rcfg["topk"])
    edge_map = {}
    print("[TOPK] selecting candidate counterparts ...")
    for i in range(S.shape[0]):
        k = min(topk, S.shape[1] - 1)
        idx = np.argpartition(-S[i], kth=max(0, k-1))[:k]
        idx = idx[np.argsort(-S[i, idx])]
        for j in idx:
            if i == j:
                continue
            a, b = (i, int(j)) if i < j else (int(j), i)
            s = float(S[i, j])
            old = edge_map.get((a, b))
            if old is None or s > old:
                edge_map[(a, b)] = s
    edges = [{"i": a, "j": b, "score": s} for (a, b), s in edge_map.items()]
    edges.sort(key=lambda e: e["score"], reverse=True)
    print(f"[OK] candidate edges={len(edges)}")
    return edges

def discover_mutual_pairs(n_rows, edges, threshold, margin):
    by_i = defaultdict(list)
    for e in edges:
        i, j, s = int(e["i"]), int(e["j"]), float(e["score"])
        by_i[i].append((s, j))
        by_i[j].append((s, i))

    top = {}
    for i in range(n_rows):
        xs = sorted(by_i.get(i, []), reverse=True)
        if not xs:
            continue
        s1, j1 = xs[0]
        s2 = xs[1][0] if len(xs) > 1 else 0.0
        top[i] = (j1, s1, s1 - s2)

    pairs, used = [], set()
    for i in range(n_rows):
        if i in used or i not in top:
            continue
        j, si, mi = top[i]
        if j in used or j not in top:
            continue
        ji, sj, mj = top[j]
        if ji != i:
            continue
        if min(si, sj) < float(threshold):
            continue
        if min(mi, mj) < float(margin):
            continue
        a, b = sorted((i, j))
        pairs.append({
            "i": a, "j": b,
            "score": min(float(si), float(sj)),
            "margin_i": float(mi), "margin_j": float(mj)
        })
        used.add(a); used.add(b)
    return pairs

def complete_pair_groups(rows):
    groups = defaultdict(dict)
    for i, r in enumerate(rows):
        pid = str(r.get("pair_id", ""))
        if pid == "":
            continue
        groups[pid][int(r["target"])] = i
    return {pid: g for pid, g in groups.items() if 0 in g and 1 in g}

def evaluate_retrieval(pairs, rows):
    true_pid = [str(r["pair_id"]) for r in rows]
    total = len(complete_pair_groups(rows))
    tp = sum(1 for p in pairs if true_pid[p["i"]] == true_pid[p["j"]])
    fp = len(pairs) - tp
    precision = tp / len(pairs) if pairs else 0.0
    recall = tp / total if total else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {
        "pred_pairs": len(pairs), "tp": tp, "fp": fp,
        "precision": precision, "recall": recall, "f1": f1,
        "true_pairs": total
    }

def auc_pr(y, score):
    from sklearn.metrics import roc_auc_score, average_precision_score
    y = np.asarray(y, dtype=int)
    s = np.asarray(score, dtype=float)
    return float(roc_auc_score(y, s)), float(average_precision_score(y, s))

def cls_metrics(y, pred):
    from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, matthews_corrcoef
    y = np.asarray(y, dtype=int); p = np.asarray(pred, dtype=int)
    return {
        "acc": float(accuracy_score(y, p)),
        "precision": float(precision_score(y, p, zero_division=0)),
        "recall": float(recall_score(y, p, zero_division=0)),
        "f1": float(f1_score(y, p, zero_division=0)),
        "mcc": float(matthews_corrcoef(y, p)),
    }

def pair_metrics(rows, scores, preds):
    groups = complete_pair_groups(rows)
    pc = pv = pb = pr = pa = 0
    for g in groups.values():
        vi, pi = g[1], g[0]
        vp, pp = int(preds[vi]), int(preds[pi])
        if vp == 1 and pp == 0: pc += 1
        elif vp == 1 and pp == 1: pv += 1
        elif vp == 0 and pp == 0: pb += 1
        else: pr += 1
        if float(scores[vi]) > float(scores[pi]):
            pa += 1
    n = len(groups); d = max(n, 1)
    return {
        "pairs": n,
        "P-C": pc, "P-V": pv, "P-B": pb, "P-R": pr,
        "P-C_rate": pc/d, "P-V_rate": pv/d, "P-B_rate": pb/d, "P-R_rate": pr/d,
        "PairAcc": pa, "PairAcc_rate": pa/d,
    }

def full_metrics(rows, scores, preds, name):
    y = [int(r["target"]) for r in rows]
    auc, pr = auc_pr(y, scores)
    out = {"name": name, "AUC": auc, "PR_AUC": pr}
    out.update(cls_metrics(y, preds))
    out.update(pair_metrics(rows, scores, preds))
    return out

def median_abs_scale(vals, floor=1e-6):
    arr = np.abs(np.asarray(vals, dtype=float))
    if arr.size == 0:
        return 1.0
    m = float(np.median(arr))
    return max(m, floor)

def format_metric(r):
    return (
        f"{r['name']:<34s} AUC={r['AUC']:.6f} PR={r['PR_AUC']:.6f} "
        f"MCC={r['mcc']:.4f} F1={r['f1']:.4f} "
        f"P-C={r['P-C']}/{r['pairs']}={r['P-C_rate']:.4f} "
        f"PairAcc={r['PairAcc']}/{r['pairs']}={r['PairAcc_rate']:.4f}"
    )
