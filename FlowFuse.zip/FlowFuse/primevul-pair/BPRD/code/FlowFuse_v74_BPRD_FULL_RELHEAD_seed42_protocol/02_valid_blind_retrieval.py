#!/usr/bin/env python3
from pathlib import Path
from bprd_utils import load_cfg, read_jsonl, make_blind_rows, write_jsonl, build_retrieval_edges

cfg = load_cfg()
rows = read_jsonl(cfg["valid_jsonl"])
blind = make_blind_rows(rows)

outdir = Path(cfg["work_dir"])
outdir.mkdir(parents=True, exist_ok=True)
write_jsonl(outdir/"blind_valid.jsonl", blind)

print("="*100)
print(f"[PAIR DISCOVERY FAST] rows={len(blind)} topk={cfg['retrieval']['topk']}")
print("[INTEGRITY] input=code only; no pair_id/target/vul_content/CVE/CWE")
edges = build_retrieval_edges(blind, cfg["retrieval"])
write_jsonl(outdir/"valid_candidate_edges.jsonl", edges)
print("[INTEGRITY] blind pair retrieval completed without pair metadata.")
print("TEST = NOT OPENED")
