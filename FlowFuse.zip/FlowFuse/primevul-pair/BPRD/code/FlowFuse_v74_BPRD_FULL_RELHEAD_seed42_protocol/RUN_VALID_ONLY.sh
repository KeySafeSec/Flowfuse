#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

echo "===================================================================="
echo "FlowFuse v7.4 BPRD FULL RELATIVE-HEAD — VALID ONLY"
echo "TEST WILL NOT BE OPENED"
echo "===================================================================="

bash 00_env_check.sh
bash 01_train_relative_head.sh
bash 02_valid_blind_retrieval.sh
bash 03_valid_select.sh
bash 04_valid_distractor_stress.sh
bash 05_show_valid.sh

echo
echo "[DONE] VALID-only pipeline finished."
echo "If and only if CONTINUE_GATE=PASS and you decide to open TEST:"
echo "  bash 06_TEST_IF_PASS.sh"
