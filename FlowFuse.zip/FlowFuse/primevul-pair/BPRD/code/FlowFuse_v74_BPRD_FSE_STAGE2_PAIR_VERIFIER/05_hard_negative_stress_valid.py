#!/usr/bin/env python3
from pathlib import Path
import json,joblib,numpy as np
from sklearn.metrics import roc_auc_score,average_precision_score
from common import *
cfg=cfg_load();out=Path(cfg["output_dir"]);rows=read_jsonl(cfg["paired_valid"]);groups=pair_groups(rows)
vec=joblib.load(out/"tfidf_vectorizer.joblib");ver=joblib.load(out/"pair_verifier.joblib");g=json.load(open(out/"REJECT_GATE_SELECTED.json"));vc=cfg["pair_verifier"]
codes=[r["func"] for r in rows];X=vec.transform(codes);m=row_meta(codes);e,c=topk_candidate_edges(X,vc["candidate_k_train"]);p=verifier_scores(ver,X,m,e,vc["batch_edges"])
positive={tuple(sorted((d[0],d[1]))) for d in groups.values()}
pe=[x for x in e if x in positive];ne=[x for x in e if x not in positive];hard=sorted(ne,key=lambda x:p[x],reverse=True)[:max(1,len(pe)*3)];same=[x for x in ne if m[x[0]]["name"] and m[x[0]]["name"]==m[x[1]]["name"]]
y=[1]*len(pe)+[0]*len(hard);s=[p[x] for x in pe]+[p[x] for x in hard]
def accept(x):return p[x]>=g["prob_threshold"] and c[x]>=g["min_cosine"]
rep={"candidate_true_pair_edges":len(pe),"hard_negative_edges":len(hard),"same_function_name_wrong_edges":len(same),"verifier_auc_true_vs_hard":float(roc_auc_score(y,s)),"verifier_pr_true_vs_hard":float(average_precision_score(y,s)),"true_pair_edge_accept_rate":float(np.mean([accept(x) for x in pe])) if pe else 0.,"hard_negative_edge_accept_rate":float(np.mean([accept(x) for x in hard])) if hard else 0.,"same_name_wrong_edge_accept_rate":float(np.mean([accept(x) for x in same])) if same else None,"note":"edge-level stress; final retrieval also requires mutual-best and margin","test_opened":False}
atomic_json(out/"VALID_HARD_NEGATIVE_STRESS.json",rep)
print("="*110);print("VALID HARD-NEGATIVE STRESS");print("="*110);print(json.dumps(rep,indent=2))
