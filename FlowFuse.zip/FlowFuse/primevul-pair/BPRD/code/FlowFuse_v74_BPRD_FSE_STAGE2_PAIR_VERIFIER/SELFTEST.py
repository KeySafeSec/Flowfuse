#!/usr/bin/env python3
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from common import *
rows=[]
for p in range(8):
    rows.append({"pair_id":f"p{p}","target":1,"func":f"int f{p}(int *x){{return *x+{p};}}"})
    rows.append({"pair_id":f"p{p}","target":0,"func":f"int f{p}(int *x){{if(x==NULL)return 0;return *x+{p};}}"})
g=pair_groups(rows);pool=build_controlled_openworld(rows,.5,42);assert len(pool)==12
v=TfidfVectorizer(analyzer="char",ngram_range=(3,4),min_df=1).fit([r["func"] for r in rows]);X=v.transform([r["func"] for r in rows]);m=row_meta([r["func"] for r in rows])
pos=[(d[0],d[1]) for d in g.values()];neg=[(g[f"p{i}"][0],g[f"p{(i+1)%8}"][0]) for i in range(8)]
F=edge_features(X,m,pos+neg);y=np.array([1]*8+[0]*8);c=SGDClassifier(loss="log_loss",random_state=1).fit(F,y);assert c.predict_proba(F).shape==(16,2)
print("[SELFTEST PASS] controlled open-world + symmetric pair verifier")
