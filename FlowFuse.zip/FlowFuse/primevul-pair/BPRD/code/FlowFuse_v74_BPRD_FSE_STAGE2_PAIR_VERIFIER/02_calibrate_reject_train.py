#!/usr/bin/env python3
from pathlib import Path
import json,joblib,numpy as np
from common import *
cfg=cfg_load();out=Path(cfg["output_dir"]);rows=read_jsonl(cfg["paired_train"]);cal=json.load(open(out/"TRAIN_SPLIT.json"))["calib_pair_ids"]
vec=joblib.load(out/"tfidf_vectorizer.joblib");ver=joblib.load(out/"pair_verifier.joblib");rg=cfg["reject_gate"];vc=cfg["pair_verifier"];cache=[]
print("="*110);print("TRAIN-HOLDOUT PAIR/REJECT CALIBRATION");print("="*110)
for seed in rg["calib_seeds"]:
    pool=build_controlled_openworld(rows,rg["calib_pair_presence_rate"],seed,cal)
    X=vec.transform([r["func"] for r in pool]);m=row_meta([r["func"] for r in pool]);e,c=topk_candidate_edges(X,vc["candidate_k_train"]);p=verifier_scores(ver,X,m,e,vc["batch_edges"]);cache.append((pool,e,c,p));print(f"[seed={seed}] rows={len(pool)} edges={len(e)}")
best=None;fallback=None;grid=[]
for th in rg["prob_threshold_grid"]:
  for mg in rg["margin_grid"]:
    for mc in rg["min_cosine_grid"]:
      ms=[retrieval_metrics(pool,select_pairs(len(pool),e,p,c,th,mg,mc)) for pool,e,c,p in cache]
      prec=float(np.mean([x["pair_precision"] for x in ms]));rec=float(np.mean([x["pair_recall"] for x in ms]));rej=float(np.mean([x["singleton_reject_rate"] for x in ms]));worst=float(np.min([x["singleton_reject_rate"] for x in ms]))
      row={"prob_threshold":th,"margin":mg,"min_cosine":mc,"mean_pair_precision":prec,"mean_pair_recall":rec,"mean_singleton_reject":rej,"worst_singleton_reject":worst,"per_seed":ms};grid.append(row)
      if fallback is None or (prec+rej+rec,prec,rej)>fallback[0]:fallback=((prec+rej+rec,prec,rej),row)
      if prec>=rg["target_pair_precision"] and rej>=rg["target_singleton_reject"]:
          key=(rec,prec,rej,worst,-th,-mg,-mc)
          if best is None or key>best[0]:best=(key,row)
sel=dict((best or fallback)[1]);sel["feasible_under_target_constraints"]=bool(best);sel["selected_on"]="held-out TRAIN only";sel["test_opened"]=False
atomic_json(out/"REJECT_GATE_GRID_TRAIN.json",grid);atomic_json(out/"REJECT_GATE_SELECTED.json",sel)
print(json.dumps(sel,indent=2));print("TEST = NOT OPENED")
