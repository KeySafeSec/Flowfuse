#!/usr/bin/env python3
from pathlib import Path
import random,joblib,numpy as np
from scipy.sparse import vstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import roc_auc_score,average_precision_score
from common import *
cfg=cfg_load();out=Path(cfg["output_dir"]);rows=read_jsonl(cfg["paired_train"]);groups=pair_groups(rows)
fit_ids,cal_ids=split_pair_ids(groups,cfg["train_fit_fraction"],cfg["random_seed"])
atomic_json(out/"TRAIN_SPLIT.json",{"fit_pair_ids":fit_ids,"calib_pair_ids":cal_ids})
tc=cfg["tfidf"];codes=[r["func"] for r in rows]
vec=TfidfVectorizer(analyzer=tc["analyzer"],ngram_range=(tc["ngram_min"],tc["ngram_max"]),max_features=tc["max_features"],min_df=tc["min_df"],sublinear_tf=tc["sublinear_tf"],lowercase=False,norm="l2",dtype=np.float32)
print("="*110);print("FIT TRAIN TFIDF");print("="*110)
X=vec.fit_transform(codes);meta=row_meta(codes);joblib.dump(vec,out/"tfidf_vectorizer.joblib",compress=3)
print(f"X={X.shape} nnz={X.nnz} fit_pairs={len(fit_ids)} calib_pairs={len(cal_ids)}")

oc=cfg["orientation"]
def obatch(ids):
    a=[];b=[]
    for pid in ids:
        g=groups[pid];a.append(X[g[1]]-X[g[0]]);b.append(X[g[0]]-X[g[1]])
    return vstack(a+b,format="csr"),np.array([1]*len(a)+[0]*len(b))
def train_o(alpha,ids):
    c=SGDClassifier(loss="log_loss",penalty="l2",alpha=alpha,fit_intercept=False,average=True,random_state=cfg["random_seed"])
    first=True
    for ep in range(oc["epochs"]):
        z=list(ids);random.Random(cfg["random_seed"]+ep).shuffle(z)
        for st in range(0,len(z),oc["batch_pairs"]):
            xb,yb=obatch(z[st:st+oc["batch_pairs"]])
            if first:c.partial_fit(xb,yb,classes=np.array([0,1]));first=False
            else:c.partial_fit(xb,yb)
    return c
def oacc(c,ids):
    return float(np.mean([c.decision_function(X[groups[p][1]]-X[groups[p][0]])[0]>0 for p in ids]))
ogrid=[];best=None
for a in oc["alphas"]:
    c=train_o(a,fit_ids);fa=oacc(c,fit_ids);ca=oacc(c,cal_ids)
    print(f"[ORIENT alpha={a:g}] fit={fa:.4f} calib={ca:.4f}");ogrid.append({"alpha":a,"fit_acc":fa,"calib_acc":ca})
    if best is None or (ca,-a)>best[0]:best=((ca,-a),a)
sel_o=best[1];ori=train_o(sel_o,list(groups));joblib.dump(ori,out/"orientation_head.joblib",compress=3)
print(f"[ORIENT SELECT] alpha={sel_o:g} full_train={oacc(ori,list(groups)):.4f}")

vc=cfg["pair_verifier"];fit_rows=sorted(groups[p][t] for p in fit_ids for t in (0,1));Xf=X[fit_rows]
print("="*110);print("MINE HIGH-SIMILARITY WRONG TRAIN PAIRS");print("="*110)
edges,cos=topk_candidate_edges(Xf,vc["candidate_k_train"]);pid=[str(rows[g]["pair_id"]) for g in fit_rows]
neg=sorted([(cos[e],e) for e in edges if pid[e[0]]!=pid[e[1]]],reverse=True)
npos=len(fit_ids);neg=neg[:npos*vc["hard_negatives_per_positive"]]
posg=[(groups[p][0],groups[p][1]) for p in fit_ids];negg=[(fit_rows[a],fit_rows[b]) for _,(a,b) in neg]
print(f"positive={len(posg)} hard_negative={len(negg)}")
Fp=edge_features(X,meta,posg);Fn=edge_features(X,meta,negg);Ft=vstack([Fp,Fn],format="csr");yt=np.array([1]*len(posg)+[0]*len(negg))

cal_rows=sorted(groups[p][t] for p in cal_ids for t in (0,1));Xc=X[cal_rows];cpid=[str(rows[g]["pair_id"]) for g in cal_rows]
ce,cc=topk_candidate_edges(Xc,vc["candidate_k_train"]);cn=sorted([(cc[e],e) for e in ce if cpid[e[0]]!=cpid[e[1]]],reverse=True)
cpos=[(groups[p][0],groups[p][1]) for p in cal_ids];cneg=[(cal_rows[a],cal_rows[b]) for _,(a,b) in cn[:len(cpos)*vc["hard_negatives_per_positive"]]]
Fc=edge_features(X,meta,cpos+cneg);yc=np.array([1]*len(cpos)+[0]*len(cneg))
vgrid=[];vbest=None;bestclf=None
n0=int(np.sum(yt==0));n1=int(np.sum(yt==1));nt=len(yt)
print(f"[VERIFIER CLASS WEIGHT] y0={n0} y1={n1} w0={nt/(2.0*n0):.6f} w1={nt/(2.0*n1):.6f}")
for a in vc["alphas"]:
    n0=int(np.sum(yt==0));n1=int(np.sum(yt==1));nt=len(yt)
    cw={0: nt/(2.0*n0), 1: nt/(2.0*n1)}
    clf=SGDClassifier(loss="log_loss",penalty="l2",alpha=a,average=True,class_weight=cw,random_state=cfg["random_seed"])
    idx=np.arange(len(yt));first=True
    for ep in range(vc["epochs"]):
        np.random.default_rng(cfg["random_seed"]+ep).shuffle(idx)
        for st in range(0,len(idx),vc["batch_edges"]):
            ii=idx[st:st+vc["batch_edges"]]
            if first:clf.partial_fit(Ft[ii],yt[ii],classes=np.array([0,1]));first=False
            else:clf.partial_fit(Ft[ii],yt[ii])
    pp=clf.predict_proba(Fc)[:,1];auc=float(roc_auc_score(yc,pp));pr=float(average_precision_score(yc,pp));pm=float(np.median(pp[:len(cpos)]));n95=float(np.quantile(pp[len(cpos):],.95))
    print(f"[VERIFIER alpha={a:g}] AUC={auc:.4f} PR={pr:.4f} pos_med={pm:.4f} neg_p95={n95:.4f}")
    vgrid.append({"alpha":a,"calib_auc":auc,"calib_pr_auc":pr,"positive_median":pm,"negative_p95":n95})
    key=(auc,pr,pm-n95,-a)
    if vbest is None or key>vbest[0]:vbest=(key,a);bestclf=clf
joblib.dump(bestclf,out/"pair_verifier.joblib",compress=3)
atomic_json(out/"TRAIN_MODEL_REPORT.json",{"orientation_grid":ogrid,"orientation_selected_alpha":sel_o,"verifier_grid":vgrid,"verifier_selected_alpha":vbest[1],"fit_pairs":len(fit_ids),"calib_pairs":len(cal_ids),"hard_negative_edges":len(negg),"valid_used_for_selection":False,"test_opened":False})
print(f"[VERIFIER SELECT] alpha={vbest[1]:g}")
print("TEST = NOT OPENED")
