# Stage2 HOTFIX — sklearn partial_fit / class_weight

The original Stage2 package used:

```python
SGDClassifier(..., class_weight="balanced").partial_fit(...)
```

scikit-learn 1.5.x rejects `"balanced"` with `partial_fit`.

This hotfix changes:

## Orientation head

Training examples are constructed exactly 1:1:

- vulnerable - patched -> 1
- patched - vulnerable -> 0

Therefore balanced weights are mathematically unnecessary and are removed.

## Pair verifier

Training intentionally uses approximately:

- 1 true counterpart positive
- 3 high-similarity wrong-pair hard negatives

The verifier therefore keeps balancing, but uses explicit global class weights:

```python
w0 = N / (2 * N0)
w1 = N / (2 * N1)
class_weight = {0: w0, 1: w1}
```

This is the standard balanced-class formula, but is compatible with `partial_fit`.

No dataset split, label use, VALID protocol, threshold grid, or TEST protocol was changed.
