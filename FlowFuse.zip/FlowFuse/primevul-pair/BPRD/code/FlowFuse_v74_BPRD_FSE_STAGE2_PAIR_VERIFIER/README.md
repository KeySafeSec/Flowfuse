# FlowFuse v7.4 BPRD — FSE Stage 2: Learned Pair Verifier

This package is the next decisive experiment after the first open-world run.

## Current bottleneck

The previous run already showed that relative orientation remains useful, but lexical PAIR/REJECT is too weak.

Therefore this package does **not** keep tuning the orientation head. It learns a separate, symmetric counterpart verifier.

## Inference

```text
unlabeled function pool
        |
        v
top-k lexical candidate generation
        |
        v
symmetric counterpart verifier
        |
   +----+----+
 ACCEPT     REJECT
   |           |
   v           v
anti-symmetric  v7.4 single
orientation    fallback
```

Verifier input is symmetric:
- `abs(TFIDF_i - TFIDF_j)`
- cosine similarity
- token-set Jaccard
- token/line length ratios
- same code-derived function name
- symmetric differences in security-relevant token counts

TRAIN positives are true V/P counterparts.
TRAIN negatives are the highest-similarity **wrong pair_id** candidates, not random negatives.

## No VALID tuning of the pair gate

TRAIN pairs are split:
- 85% verifier fit
- 15% gate calibration

The held-out TRAIN split selects:
- verifier regularization
- accept probability threshold
- mutual-best margin
- minimum cosine

VALID only evaluates the frozen choices.

## One VALID run produces three experiments

### 1. PrimeVul-Pair closed-world

All original 908 VALID functions remain in the pool.

This is the paired-benchmark result to report next to prior PrimeVul/Phoenix/ICLR paired evaluations, while clearly disclosing that our inference protocol retrieves and jointly orients a pair.

It reports five variants:

```text
V74_SINGLE
ORACLE_PAIR_EXCLUSIVE_V74_DIRECTION
BLIND_VERIFIER_EXCLUSIVE_V74_DIRECTION
ORACLE_PAIR_EXCLUSIVE_LEARNED_HEAD
FULL_BLIND_VERIFIER_LEARNED_HEAD
```

This is the key causal ablation explaining where the large gain comes from.

### 2. Open-world counterpart-missing

Counterpart availability:
- 25%
- 50%
- 75%

Three fixed seeds each.

For singleton queries the real counterpart is physically absent.

Metrics:
- pair precision
- pair recall
- singleton reject rate
- MCC gain after fallback

### 3. Hard-negative / shortcut stress

The verifier is evaluated against:
- highest-scoring wrong candidate edges
- wrong edges with the same function name

This directly tests whether it is merely exploiting lexical similarity or naming.

## Run VALID only

```bash
conda activate FlowFuse5090

cd ~/DataFlow_CFG_Def
unzip -o FlowFuse_v74_BPRD_FSE_STAGE2_PAIR_VERIFIER.zip
cd FlowFuse_v74_BPRD_FSE_STAGE2_PAIR_VERIFIER

chmod +x *.sh *.py

bash RUN_VALID_FSE_STAGE2.sh 2>&1 \
  | tee ~/DataFlow_CFG_Def/output/run_v74_bprd_fse_stage2_verifier/VALID_FSE_STAGE2.log
```

Only if the end prints:

```text
CONTINUE_GATE = PASS
```

run TEST once:

```bash
bash 08_TEST_IF_PASS.sh 2>&1 \
  | tee ~/DataFlow_CFG_Def/output/run_v74_bprd_fse_stage2_verifier/TEST_FROZEN.log
```

## After Stage 2

The next FSE requirement is frozen cross-dataset evaluation.

Discover existing assets with:

```bash
bash 09_FIND_CROSSDATASET_ASSETS.sh
```

Send that output back before constructing the VulFixed / MegaVul zero-shot runner.
