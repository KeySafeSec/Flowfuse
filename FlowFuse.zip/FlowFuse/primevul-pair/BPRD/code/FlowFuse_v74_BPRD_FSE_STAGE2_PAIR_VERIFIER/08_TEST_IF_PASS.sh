#!/usr/bin/env bash
set -euo pipefail
export PYTHONUNBUFFERED=1
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
python 08_test_frozen.py
