#!/usr/bin/env bash
set -euo pipefail
export PYTHONUNBUFFERED=1
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
OUT="$(python - <<'PY'
import json,os
print(os.path.expanduser(json.load(open("config.json"))["output_dir"]))
PY
)"
mkdir -p "$OUT"
echo "===================================================================="
echo "FlowFuse v7.4 BPRD FSE STAGE2 — LEARNED PAIR VERIFIER"
echo "TRAIN + VALID ONLY. TEST WILL NOT BE OPENED."
echo "===================================================================="
python SELFTEST.py
python 00_check_assets.py
python 01_fit_models_train.py
python 02_calibrate_reject_train.py
python 03_eval_valid_closedworld.py
python 04_eval_valid_openworld.py
python 05_hard_negative_stress_valid.py
set +e
python 06_gate_and_freeze.py
RC=$?
set -e
python 07_show_valid.py
if [ "$RC" -eq 0 ]; then
  echo "[PASS] VALID gate passed. TEST remains unopened."
  echo "Run exactly once: bash 08_TEST_IF_PASS.sh"
else
  echo "[STOP] VALID gate failed. Do NOT run TEST."
fi
exit "$RC"
