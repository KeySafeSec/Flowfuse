#!/usr/bin/env python3
from pathlib import Path
import json,joblib,numpy as np
from common import *
cfg=cfg_load();out=Path(cfg["output_dir"]);fr=json.load(open(out/"FROZEN_CONFIG.json"))
if not fr["validation_gate_passed"]:raise SystemExit("[STOP] VALID gate failed")
for k,n in (("tfidf_vectorizer","tfidf_vectorizer.joblib"),("pair_verifier","pair_verifier.joblib"),("orientation_head","orientation_head.joblib"),("reject_gate","REJECT_GATE_SELECTED.json")):
    if sha256_file(out/n)!=fr["artifact_sha256"][k]:raise SystemExit(f"[FATAL] artifact changed: {n}")
rows=read_jsonl(cfg["paired_test"]);base,fmt=parse_score_file(cfg["v74_test_scores"],len(rows));vec=joblib.load(out/"tfidf_vectorizer.joblib");ver=joblib.load(out/"pair_verifier.joblib");ori=joblib.load(out/"orientation_head.joblib");vc=cfg["pair_verifier"];g=fr["reject_gate"];thr=fr["v74_threshold"]
def retrieve(pool):
    X=vec.transform([r["func"] for r in pool]);m=row_meta([r["func"] for r in pool]);e,c=topk_candidate_edges(X,vc["candidate_k_train"]);p=verifier_scores(ver,X,m,e,vc["batch_edges"]);pp=select_pairs(len(pool),e,p,c,g["prob_threshold"],g["margin"],g["min_cosine"]);return X,pp,retrieval_metrics(pool,pp)
pool=build_closedworld(rows);X,pairs,rm=retrieve(pool);oracle=oracle_pairs(pool)
def ev(name,pp,mode,t):
    y,b,s,o=hybrid_scores(pool,X,pp,base,ori,mode);return {"name":name,"classification":cls_metrics(y,s,t),"pair_metrics":pair_metrics(rows,s,t),"orientation_acc":o}
vs=[{"name":"V74_SINGLE","classification":cls_metrics([int(r["target"]) for r in rows],base,thr),"pair_metrics":pair_metrics(rows,base,thr),"orientation_acc":None},ev("ORACLE_PAIR_EXCLUSIVE_V74_DIRECTION",oracle,"v74",.5),ev("BLIND_VERIFIER_EXCLUSIVE_V74_DIRECTION",pairs,"v74",.5),ev("ORACLE_PAIR_EXCLUSIVE_LEARNED_HEAD",oracle,"head",.5),ev("FULL_BLIND_VERIFIER_LEARNED_HEAD",pairs,"head",.5)]
tc=cfg["test_openworld"];runs=[]
for rate in tc["pair_presence_rates"]:
  for seed in tc["seeds"]:
    p=build_controlled_openworld(rows,rate,seed);XX,pp,rr=retrieve(p);y,b,s,o=hybrid_scores(p,XX,pp,base,ori,"head");bm=cls_metrics(y,b,thr);hm=cls_metrics(y,s,.5);runs.append({"pair_presence_rate":rate,"seed":seed,"pool_rows":len(p),"retrieval":rr,"base":bm,"hybrid":hm,"mcc_gain":hm["mcc"]-bm["mcc"],"orientation_acc":o})
ow={"mean_pair_precision":float(np.mean([r["retrieval"]["pair_precision"] for r in runs])),"mean_pair_recall":float(np.mean([r["retrieval"]["pair_recall"] for r in runs])),"mean_singleton_reject":float(np.mean([r["retrieval"]["singleton_reject_rate"] for r in runs])),"worst_singleton_reject":float(np.min([r["retrieval"]["singleton_reject_rate"] for r in runs])),"mean_mcc_gain":float(np.mean([r["mcc_gain"] for r in runs])),"runs":runs}
rep={"protocol":"TEST frozen before opening; no TEST tuning","score_parser":fmt,"closedworld":{"retrieval":rm,"variants":vs},"openworld":ow,"no_test_tuning":True};atomic_json(out/"TEST_FROZEN_REPORT.json",rep)
print("="*130);print("FROZEN TEST — CLOSED WORLD");print("="*130);print(json.dumps(rm,indent=2))
for v in vs:
    a=v["classification"];q=v["pair_metrics"];print(f"{v['name']:46s} AUC={a['AUC']:.6f} MCC={a['mcc']:.4f} F1={a['f1']:.4f} P-C={q['P-C_rate']:.4f} PairAcc={q['PairAcc_rate']:.4f}")
print("="*130);print("FROZEN TEST — OPEN WORLD");print("="*130);print(json.dumps({k:v for k,v in ow.items() if k!='runs'},indent=2));print("[IMPORTANT] no TEST tuning.");print("REPORT =",out/"TEST_FROZEN_REPORT.json")
