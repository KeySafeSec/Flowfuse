#!/usr/bin/env python3
from pathlib import Path
import json,joblib,numpy as np
from common import *
cfg=cfg_load();out=Path(cfg["output_dir"]);rows=read_jsonl(cfg["paired_valid"]);base,fmt=parse_score_file(cfg["v74_valid_scores"],len(rows))
vec=joblib.load(out/"tfidf_vectorizer.joblib");ver=joblib.load(out/"pair_verifier.joblib");ori=joblib.load(out/"orientation_head.joblib");g=json.load(open(out/"REJECT_GATE_SELECTED.json"));vc=cfg["pair_verifier"];thr=cfg["v74_threshold"];oc=cfg["valid_openworld"]
runs=[]
print("="*130);print("VALID OPEN-WORLD — COUNTERPART MAY BE ABSENT");print("="*130)
for rate in oc["pair_presence_rates"]:
  for seed in oc["seeds"]:
    pool=build_controlled_openworld(rows,rate,seed);X=vec.transform([r["func"] for r in pool]);m=row_meta([r["func"] for r in pool]);e,c=topk_candidate_edges(X,vc["candidate_k_train"]);p=verifier_scores(ver,X,m,e,vc["batch_edges"]);pairs=select_pairs(len(pool),e,p,c,g["prob_threshold"],g["margin"],g["min_cosine"]);rm=retrieval_metrics(pool,pairs)
    y,b,s,o=hybrid_scores(pool,X,pairs,base,ori,"head");bm=cls_metrics(y,b,thr);hm=cls_metrics(y,s,.5)
    r={"pair_presence_rate":rate,"seed":seed,"pool_rows":len(pool),"retrieval":rm,"base":bm,"hybrid":hm,"mcc_gain":hm["mcc"]-bm["mcc"],"orientation_acc":o};runs.append(r)
    print(f"[rate={rate:.2f} seed={seed}] rows={len(pool)} precision={rm['pair_precision']:.4f} recall={rm['pair_recall']:.4f} reject={rm['singleton_reject_rate']:.4f} MCC={bm['mcc']:.4f}->{hm['mcc']:.4f} gain={r['mcc_gain']:+.4f}")
stress=None;npth=Path(cfg["normal_valid"])
if npth.is_file():
    normal=read_jsonl(npth);core=build_controlled_openworld(rows,.50,oc["external_background_seed"]);pool,n=add_external_background(core,normal,rows,oc["external_normal_background"],oc["external_background_seed"])
    X=vec.transform([r["func"] for r in pool]);m=row_meta([r["func"] for r in pool]);e,c=topk_candidate_edges(X,vc["candidate_k_train"]);p=verifier_scores(ver,X,m,e,vc["batch_edges"]);pairs=select_pairs(len(pool),e,p,c,g["prob_threshold"],g["margin"],g["min_cosine"]);stress=retrieval_metrics(pool,pairs);stress.update({"pool_rows":len(pool),"external_added":n})
    print("-"*130);print("[ORDINARY VALID BACKGROUND STRESS]");print(json.dumps(stress,indent=2))
summary={"mean_pair_precision":float(np.mean([r["retrieval"]["pair_precision"] for r in runs])),"mean_pair_recall":float(np.mean([r["retrieval"]["pair_recall"] for r in runs])),"mean_singleton_reject":float(np.mean([r["retrieval"]["singleton_reject_rate"] for r in runs])),"worst_singleton_reject":float(np.min([r["retrieval"]["singleton_reject_rate"] for r in runs])),"mean_mcc_gain":float(np.mean([r["mcc_gain"] for r in runs])),"runs":runs,"ordinary_background_stress":stress,"test_opened":False}
atomic_json(out/"VALID_OPENWORLD_REPORT.json",summary)
print("="*130)
for k in ("mean_pair_precision","mean_pair_recall","mean_singleton_reject","worst_singleton_reject","mean_mcc_gain"):print(f"{k:30s} {summary[k]:.6f}")
print("TEST = NOT OPENED")
