# FSE logic

## RQ1: Absolute vs relative vulnerability detection
Measure v7.4 single-function performance and pair metrics.

## RQ2: How much does merely knowing the true pair help?
Use `ORACLE_PAIR_EXCLUSIVE_V74_DIRECTION` only as a diagnostic upper bound.

## RQ3: Does learned relative orientation add real signal?
Compare oracle v7.4 direction with oracle learned-head direction.

## RQ4: Can pair identity be recovered without official pair_id?
Compare oracle vs blind verifier on the full original PrimeVul-Pair pool.

## RQ5: Can the system refuse pairing when a counterpart is absent?
Controlled open-world removes real counterparts from the pool.

## RQ6: Is counterpart retrieval a lexical benchmark shortcut?
Use high-similarity wrong pair_ids, same-name wrong edges, and ordinary PrimeVul background.

## RQ7: Does it generalize beyond PrimeVul construction?
Required after this stage:
- frozen VulFixed evaluation;
- ideally non-security version-history revisions;
- optionally MegaVul if its pair semantics are compatible.

## Claim boundary

Do not claim the closed-world BPRD AUC is directly comparable to an ordinary independent single-function AUC.

Report separately:

1. **PrimeVul-Pair closed-world counterpart-aware evaluation**
2. **Open-world counterpart-aware evaluation**

The main proposed contribution is:
`retrieve -> verify/reject -> relative orientation -> single-function fallback`.
