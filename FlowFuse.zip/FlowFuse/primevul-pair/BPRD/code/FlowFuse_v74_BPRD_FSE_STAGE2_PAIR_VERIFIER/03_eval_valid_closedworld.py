#!/usr/bin/env python3
from pathlib import Path
import json,joblib
from common import *
cfg=cfg_load();out=Path(cfg["output_dir"]);rows=read_jsonl(cfg["paired_valid"]);base,fmt=parse_score_file(cfg["v74_valid_scores"],len(rows))
vec=joblib.load(out/"tfidf_vectorizer.joblib");ver=joblib.load(out/"pair_verifier.joblib");ori=joblib.load(out/"orientation_head.joblib");g=json.load(open(out/"REJECT_GATE_SELECTED.json"));vc=cfg["pair_verifier"];thr=cfg["v74_threshold"]
pool=build_closedworld(rows);X=vec.transform([r["func"] for r in pool]);m=row_meta([r["func"] for r in pool]);e,c=topk_candidate_edges(X,vc["candidate_k_train"]);p=verifier_scores(ver,X,m,e,vc["batch_edges"]);pairs=select_pairs(len(pool),e,p,c,g["prob_threshold"],g["margin"],g["min_cosine"]);rm=retrieval_metrics(pool,pairs);oracle=oracle_pairs(pool)
def ev(name,pp,mode,t):
    y,b,s,o=hybrid_scores(pool,X,pp,base,ori,mode);return {"name":name,"classification":cls_metrics(y,s,t),"pair_metrics":pair_metrics(rows,s,t),"orientation_acc":o}
vs=[{"name":"V74_SINGLE","classification":cls_metrics([int(r["target"]) for r in rows],base,thr),"pair_metrics":pair_metrics(rows,base,thr),"orientation_acc":None},ev("ORACLE_PAIR_EXCLUSIVE_V74_DIRECTION",oracle,"v74",.5),ev("BLIND_VERIFIER_EXCLUSIVE_V74_DIRECTION",pairs,"v74",.5),ev("ORACLE_PAIR_EXCLUSIVE_LEARNED_HEAD",oracle,"head",.5),ev("FULL_BLIND_VERIFIER_LEARNED_HEAD",pairs,"head",.5)]
atomic_json(out/"VALID_CLOSEDWORLD_REPORT.json",{"score_parser":fmt,"retrieval":rm,"variants":vs,"test_opened":False})
print("="*130);print("VALID CLOSED-WORLD — FULL ORIGINAL PAIRED POOL");print("="*130);print(json.dumps(rm,indent=2))
for v in vs:
    a=v["classification"];q=v["pair_metrics"];print(f"{v['name']:46s} AUC={a['AUC']:.6f} MCC={a['mcc']:.4f} F1={a['f1']:.4f} P-C={q['P-C_rate']:.4f} PairAcc={q['PairAcc_rate']:.4f} orient={v['orientation_acc']}")
print("TEST = NOT OPENED")
