#!/usr/bin/env python3
from pathlib import Path
from common import *
cfg=cfg_load();out=Path(cfg["output_dir"]);out.mkdir(parents=True,exist_ok=True)
print("="*110);print("FSE STAGE2 — ASSET / PROTOCOL CHECK");print("="*110)
for k in ("paired_train","paired_valid","v74_valid_scores"):
    p=Path(cfg[k]);print(f"{k:20s} {p} exists={p.is_file()}")
    if not p.is_file():raise SystemExit(f"[FATAL] missing {k}")
tr=read_jsonl(cfg["paired_train"]);va=read_jsonl(cfg["paired_valid"])
print(f"TRAIN rows={len(tr)} pairs={len(pair_groups(tr))}")
print(f"VALID rows={len(va)} pairs={len(pair_groups(va))}")
s,fmt=parse_score_file(cfg["v74_valid_scores"],len(va));print(f"VALID scores={len(s)} parser={fmt}")
print("[PROTOCOL] model/gate selection uses TRAIN only.")
print("[PROTOCOL] closed-world VALID keeps all original rows.")
print("[PROTOCOL] open-world VALID physically removes counterparts.")
print("[PROTOCOL] VALID labels/pair_id are evaluation only.")
print("[PROTOCOL] TEST is not opened by RUN_VALID_FSE_STAGE2.sh.")
print("[PASS]")
