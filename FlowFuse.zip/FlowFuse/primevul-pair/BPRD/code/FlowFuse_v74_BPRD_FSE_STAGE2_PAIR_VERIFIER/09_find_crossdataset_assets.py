#!/usr/bin/env python3
from pathlib import Path
root=Path.home()/"DataFlow_CFG_Def"/"data";keys=("vulfixed","vul_fixed","megavul","mega_vul")
print("="*100);print("CROSS-DATASET ASSET DISCOVERY (READ-ONLY)");print("="*100)
hits=[]
if root.exists():
    for p in root.rglob("*"):
        s=str(p).lower()
        if p.is_file() and any(k in s for k in keys) and p.suffix.lower() in (".jsonl",".pkl",".json",".csv"):hits.append(p)
for p in hits[:300]:print(p)
print(f"TOTAL={len(hits)}")
print("Send this output back before building frozen zero-shot VulFixed/MegaVul evaluation.")
