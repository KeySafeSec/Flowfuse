#!/usr/bin/env python3
import json,re,math,hashlib,random
from pathlib import Path
from collections import defaultdict
import numpy as np
from scipy.sparse import csr_matrix,hstack
COMMENT_RE=re.compile(r'//.*?$|/\*.*?\*/',re.M|re.S)
WS_RE=re.compile(r'\s+')
TOK_RE=re.compile(r'[A-Za-z_]\w*|0x[0-9A-Fa-f]+|\d+|==|!=|<=|>=|->|&&|\|\||[^\s]')
FUN_RE=re.compile(r'([A-Za-z_]\w*)\s*\([^;{}]*\)\s*(?:const\s*)?\{')
KEYWORDS=("if","return","NULL","nullptr","free","malloc","calloc","realloc","memcpy","memmove","strcpy","strlen","sizeof","assert","goto","for","while")

def cfg_load(path="config.json"): return json.load(open(path,"r",encoding="utf-8"))
def read_jsonl(path):
    out=[]
    with open(path,"r",encoding="utf-8",errors="replace") as f:
        for n,l in enumerate(f,1):
            l=l.strip()
            if l:
                try: out.append(json.loads(l))
                except Exception as e: raise RuntimeError(f"bad json {path}:{n}: {e}")
    return out
def atomic_json(path,obj):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+".tmp")
    json.dump(obj,open(t,"w",encoding="utf-8"),ensure_ascii=False,indent=2);t.replace(p)
def clean_code(c): return WS_RE.sub(" ",COMMENT_RE.sub(" ",c or "")).strip()
def code_hash(c): return hashlib.sha256(clean_code(c).encode("utf-8","ignore")).hexdigest()
def toks(c): return TOK_RE.findall(c or "")
def func_name(c):
    m=list(FUN_RE.finditer((c or "")[:1500])); return m[-1].group(1) if m else ""
def pair_groups(rows):
    g=defaultdict(dict)
    for i,r in enumerate(rows):
        if "pair_id" in r and "target" in r:
            try:g[str(r["pair_id"])][int(r["target"])]=i
            except:pass
    return {p:d for p,d in g.items() if 0 in d and 1 in d}
def sigmoid(z):
    z=float(np.clip(z,-50,50));return 1/(1+math.exp(-z))
def logit(p):
    p=min(max(float(p),1e-7),1-1e-7);return math.log(p/(1-p))
def parse_score_file(path,n):
    lines=[x.strip() for x in open(path,"r",encoding="utf-8",errors="replace") if x.strip()]
    sep="\t" if lines and "\t" in lines[0] else ("," if lines and "," in lines[0] else None)
    if sep:
        h=[x.strip().lower() for x in lines[0].split(sep)]
        for k in ("prob1","prob_vul","vuln_score","score","prob","probability"):
            if k in h:
                c=h.index(k);v=[]
                for l in lines[1:]:
                    a=l.split(sep)
                    if len(a)>c:
                        try:v.append(float(a[c]))
                        except:pass
                if len(v)==n:return v,f"header:{k}"
    v=[]
    for l in lines:
        try:
            o=json.loads(l)
            if isinstance(o,dict):
                x=next((o[k] for k in ("prob1","prob_vul","vuln_score","score","prob","probability") if k in o),None)
                if x is not None:v.append(float(x))
        except:pass
    if len(v)==n:return v,"jsonl"
    v=[]
    for l in lines:
        ns=re.findall(r"[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?",l)
        if ns:v.append(float(ns[-1]))
    if len(v)==n:return v,"generic"
    if len(v)==n+1:return v[1:],"generic-skip1"
    raise RuntimeError(f"cannot parse {n} scores from {path}; got {len(v)}")
def split_pair_ids(groups,frac,seed):
    ids=sorted(groups);random.Random(seed).shuffle(ids);n=max(1,min(len(ids)-1,int(round(len(ids)*frac))));return ids[:n],ids[n:]
def build_closedworld(rows):
    return [{"orig_index":i,"func":r["func"],"target":int(r["target"]),"pair_id":str(r["pair_id"]),"kind":"complete_pair"} for i,r in enumerate(rows)]
def build_controlled_openworld(rows,rate,seed,allowed_pair_ids=None):
    g=pair_groups(rows);ids=sorted(g if allowed_pair_ids is None else set(allowed_pair_ids)&set(g));rr=random.Random(seed);rr.shuffle(ids)
    complete=set(ids[:int(round(len(ids)*rate))]);pool=[]
    for pid in ids:
        if pid in complete:
            for t in (0,1):
                i=g[pid][t];pool.append({"orig_index":i,"func":rows[i]["func"],"target":int(rows[i]["target"]),"pair_id":pid,"kind":"complete_pair"})
        else:
            t=rr.choice([0,1]);i=g[pid][t];pool.append({"orig_index":i,"func":rows[i]["func"],"target":int(rows[i]["target"]),"pair_id":pid,"kind":"controlled_singleton"})
    rr.shuffle(pool);return pool
def add_external_background(pool,normal,paired,max_n,seed):
    ph={code_hash(r.get("func","")) for r in paired};seen=set();cand=[]
    for r in normal:
        h=code_hash(r.get("func",""))
        if h and h not in ph and h not in seen:seen.add(h);cand.append(r)
    rr=random.Random(seed);rr.shuffle(cand);cand=cand[:max_n];out=list(pool)
    for r in cand:out.append({"orig_index":None,"func":r["func"],"target":r.get("target"),"pair_id":None,"kind":"external_normal_background"})
    rr.shuffle(out);return out,len(cand)
def row_meta(codes):
    out=[]
    for c in codes:
        tt=toks(c);ss=set(tt);out.append({"set":ss,"n":max(1,len(tt)),"lines":max(1,c.count("\n")+1),"name":func_name(c),"counts":[tt.count(k) for k in KEYWORDS]})
    return out
def edge_features(X,meta,edges):
    if not edges:return csr_matrix((0,X.shape[1]+5+len(KEYWORDS)),dtype=np.float32)
    I=np.array([a for a,b in edges]);J=np.array([b for a,b in edges]);D=(X[I]-X[J]).tocsr();D.data=np.abs(D.data).astype(np.float32)
    cos=np.asarray(X[I].multiply(X[J]).sum(axis=1)).reshape(-1);sc=[]
    for i,j,c in zip(I,J,cos):
        a,b=meta[int(i)],meta[int(j)];u=len(a["set"]|b["set"]);jac=len(a["set"]&b["set"])/u if u else 1.
        lr=min(a["n"],b["n"])/max(a["n"],b["n"]);lir=min(a["lines"],b["lines"])/max(a["lines"],b["lines"])
        sn=float(bool(a["name"]) and a["name"]==b["name"]);cd=[abs(x-y)/(1+x+y) for x,y in zip(a["counts"],b["counts"])]
        sc.append([2*c,2*lr,2*lir,2*jac,2*sn]+cd)
    return hstack([D,csr_matrix(np.asarray(sc,np.float32))],format="csr",dtype=np.float32)
def topk_candidate_edges(X,k):
    from sklearn.neighbors import NearestNeighbors
    nn=NearestNeighbors(n_neighbors=min(k+1,X.shape[0]),metric="cosine",algorithm="brute",n_jobs=-1).fit(X)
    dist,ind=nn.kneighbors(X);edges=set();cos={}
    for i in range(X.shape[0]):
        for d,j in zip(dist[i],ind[i]):
            j=int(j)
            if j==i:continue
            e=(i,j) if i<j else (j,i);edges.add(e);cos[e]=max(cos.get(e,-1),1-float(d))
    return sorted(edges),cos
def verifier_scores(clf,X,meta,edges,batch=1024):
    out={}
    for st in range(0,len(edges),batch):
        ee=edges[st:st+batch];pp=clf.predict_proba(edge_features(X,meta,ee))[:,1]
        for e,p in zip(ee,pp):out[e]=float(p)
    return out
def select_pairs(n,edges,prob,cos,pth,margin,mincos):
    neigh=[[] for _ in range(n)]
    for a,b in edges:
        if cos[(a,b)]<mincos:continue
        p=prob[(a,b)];neigh[a].append((p,b));neigh[b].append((p,a))
    best=np.full(n,-1);bp=np.zeros(n);sec=np.zeros(n)
    for i,l in enumerate(neigh):
        l.sort(reverse=True)
        if l:
            bp[i],best[i]=l[0];sec[i]=l[1][0] if len(l)>1 else 0.
    used=set();out=[]
    for i in range(n):
        j=int(best[i])
        if i in used or j<0 or j in used or int(best[j])!=i:continue
        e=(i,j) if i<j else (j,i)
        if prob[e]>=pth and cos[e]>=mincos and bp[i]-sec[i]>=margin and bp[j]-sec[j]>=margin:
            out.append({"i":e[0],"j":e[1],"prob":prob[e],"cos":cos[e]});used|={i,j}
    return out
def retrieval_metrics(pool,pairs):
    used=set();tp=fp=0
    for p in pairs:
        i,j=p["i"],p["j"];used|={i,j};a,b=pool[i],pool[j]
        if a["kind"]=="complete_pair" and b["kind"]=="complete_pair" and a["pair_id"]==b["pair_id"]:tp+=1
        else:fp+=1
    true=sum(r["kind"]=="complete_pair" for r in pool)//2;ss=[i for i,r in enumerate(pool) if r["kind"]=="controlled_singleton"];ee=[i for i,r in enumerate(pool) if r["kind"]=="external_normal_background"]
    return {"pred_pairs":len(pairs),"true_pairs_present":true,"tp_pairs":tp,"fp_pairs":fp,"pair_precision":tp/(tp+fp) if tp+fp else 1.,"pair_recall":tp/true if true else 1.,"controlled_singletons":len(ss),"singleton_reject_rate":sum(i not in used for i in ss)/len(ss) if ss else 1.,"external_background_rows":len(ee),"external_background_reject_rate":sum(i not in used for i in ee)/len(ee) if ee else None}
def cls_metrics(y,s,t):
    from sklearn.metrics import roc_auc_score,average_precision_score,accuracy_score,precision_score,recall_score,f1_score,matthews_corrcoef
    y=np.asarray(y);s=np.asarray(s);p=(s>=t).astype(int)
    return {"AUC":float(roc_auc_score(y,s)),"PR_AUC":float(average_precision_score(y,s)),"acc":float(accuracy_score(y,p)),"precision":float(precision_score(y,p,zero_division=0)),"recall":float(recall_score(y,p,zero_division=0)),"f1":float(f1_score(y,p,zero_division=0)),"mcc":float(matthews_corrcoef(y,p))}
def pair_metrics(rows,s,t):
    g=pair_groups(rows);pred=[int(x>=t) for x in s];pc=pv=pb=pr=pa=0
    for d in g.values():
        v,p=d[1],d[0];a,b=pred[v],pred[p]
        if (a,b)==(1,0):pc+=1
        elif (a,b)==(1,1):pv+=1
        elif (a,b)==(0,0):pb+=1
        else:pr+=1
        pa+=int(s[v]>s[p])
    n=len(g);return {"pairs":n,"P-C":pc,"P-V":pv,"P-B":pb,"P-R":pr,"P-C_rate":pc/n,"PairAcc_rate":pa/n}
def oracle_pairs(pool):
    d=defaultdict(list)
    for i,r in enumerate(pool):
        if r["kind"]=="complete_pair":d[r["pair_id"]].append(i)
    return [{"i":min(v),"j":max(v)} for v in d.values() if len(v)==2]
def hybrid_scores(pool,X,pairs,base,ori,mode):
    ids=[i for i,r in enumerate(pool) if r["orig_index"] is not None];loc={i:k for k,i in enumerate(ids)};y=[int(pool[i]["target"]) for i in ids];bs=[base[int(pool[i]["orig_index"])] for i in ids];out=list(bs);ok=tot=0
    for p in pairs:
        i,j=p["i"],p["j"]
        if pool[i]["orig_index"] is None or pool[j]["orig_index"] is None:continue
        if mode=="head":z=float(ori.decision_function(X[i]-X[j])[0])
        else:z=logit(base[int(pool[i]["orig_index"])])-logit(base[int(pool[j]["orig_index"])])
        out[loc[i]]=sigmoid(z);out[loc[j]]=1-sigmoid(z)
        if pool[i]["kind"]=="complete_pair" and pool[j]["kind"]=="complete_pair" and pool[i]["pair_id"]==pool[j]["pair_id"]:
            tot+=1;ti=int(pool[i]["target"]);ok+=int((z>0 and ti==1) or (z<0 and ti==0))
    return y,bs,out,(ok/tot if tot else None)
def sha256_file(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1<<20),b""):h.update(b)
    return h.hexdigest()
