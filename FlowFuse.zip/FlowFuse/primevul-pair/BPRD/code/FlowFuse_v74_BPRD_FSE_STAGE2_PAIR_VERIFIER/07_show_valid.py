#!/usr/bin/env python3
from pathlib import Path
from common import cfg_load
out=Path(cfg_load()["output_dir"])
for n in ("TRAIN_MODEL_REPORT.json","REJECT_GATE_SELECTED.json","VALID_CLOSEDWORLD_REPORT.json","VALID_OPENWORLD_REPORT.json","VALID_HARD_NEGATIVE_STRESS.json","FROZEN_CONFIG.json"):
    p=out/n
    if p.is_file():print("\n"+"="*110+"\n"+n+"\n"+"="*110+"\n"+p.read_text())
