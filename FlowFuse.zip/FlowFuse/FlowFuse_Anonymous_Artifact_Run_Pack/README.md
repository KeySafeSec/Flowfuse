# FlowFuse — Anonymous Artifact

This artifact contains the reviewer-facing code and frozen experimental evidence for FlowFuse.

## 1. What is included

The uploaded artifact is organized around four evaluation blocks:

```text
primevul-normal/
primevul-pair/
VulFix/
MegaVul/
```

The main paper-facing evidence is already frozen in the artifact. Reviewers do **not**
need to retrain FlowFuse to verify the reported results.

The recommended order is:

```text
00_CHECK_ARTIFACT.sh
        ↓
01_VERIFY_FROZEN_RESULTS.sh
        ↓
(optional full BPRD reproduction)
02_RUN_BPRD_SEED42_REPRO.sh valid
        ↓
02_RUN_BPRD_SEED42_REPRO.sh test
```

For the normal artifact review, the first two commands are sufficient.

---

## 2. Environment

Python 3.10 is recommended.

```bash
conda create -n flowfuse-artifact python=3.10 -y
conda activate flowfuse-artifact
pip install -r requirements.txt
```

The frozen-result verification path uses only Python's standard library.
The packages in `requirements.txt` are needed only when running the model/BPRD code.

---

## 3. Quick start: verify the frozen paper results

From the artifact root:

```bash
chmod +x 00_CHECK_ARTIFACT.sh 01_VERIFY_FROZEN_RESULTS.sh \
         02_RUN_BPRD_SEED42_REPRO.sh verify_all.sh

bash verify_all.sh
```

`verify_all.sh` performs read-only checks on the frozen reviewer-facing evidence.
It does not train a model, select a new threshold, or modify TEST results.

Expected PrimeVul-Pair BPRD FINAL3 results:

```text
seed 42:   F1=79.05  MCC=58.69  AUC=87.36  accepted=388 (386 true + 2 false)
seed 123:  F1=80.10  MCC=60.66  AUC=87.61  accepted=388 (386 true + 2 false)
seed 2026: F1=78.85  MCC=58.18  AUC=87.26  accepted=388 (386 true + 2 false)

mean ± sample SD:
F1   = 79.33 ± 0.67
MCC  = 59.18 ± 1.31
AUC  = 87.41 ± 0.18
```

The script also checks the frozen VulFixed and MegaVul result files.

---

## 4. PrimeVul-Pair: independent Single protocol

The independent Single random-seed results are stored under:

```text
primevul-pair/output/42/
primevul-pair/output/123/
primevul-pair/output/2026/
```

Each directory contains:

```text
predictions_valid.txt
predictions_test.txt
```

The VALID-selected thresholds used by the independent Single protocol are:

| Seed | VALID-selected threshold | TEST F1 |
|---:|---:|---:|
| 42 | 0.560 | 46.29 |
| 123 | 0.520 | 51.54 |
| 2026 | 0.575 | 33.22 |

Important: the `base_test` / `BPRDProtocolBase_*` values embedded inside BPRD reports
are **not** the independent Single random-seed protocol and must not be substituted for it.

---

## 5. PrimeVul-Pair: BPRD FINAL3

The three frozen BPRD runs are stored at:

```text
primevul-pair/BPRD/output/run_v74_bprd_full_relhead_seed42_protocol/
primevul-pair/BPRD/output/run_v74_bprd_full_relhead_seed123_protocol/
primevul-pair/BPRD/output/run_v74_bprd_full_relhead_seed2026_protocol/
```

The canonical evidence for every seed is:

```text
selected_config.json
TEST_REPORT_FROZEN.json
TEST_PREDICTIONS_BLIND.jsonl
```

The protocol is:

```text
TRAIN
  ↓
VALID configuration selection
  ↓
freeze configuration
  ↓
TEST exactly with the frozen configuration
```

TEST is not used for threshold or configuration selection.

A relative-path-safe three-seed summarizer is supplied as:

```text
06_SUMMARIZE_THREE_SEEDS_FINAL3_ARTIFACT.py
```

Run:

```bash
python 06_SUMMARIZE_THREE_SEEDS_FINAL3_ARTIFACT.py
```

or simply:

```bash
bash 01_VERIFY_FROZEN_RESULTS.sh
```

---

## 6. PrimeVul Stage2 / robustness evidence

The artifact also contains the earlier controlled BPRD evaluation:

```text
primevul-pair/BPRD/output/run_v74_bprd_fse_stage2_verifier/
primevul-pair/BPRD/output/run_v74_bprd_fse_stage3_frozen_test/
```

Key files include:

```text
VALID_CLOSEDWORLD_REPORT.json
VALID_OPENWORLD_REPORT.json
VALID_HARD_NEGATIVE_STRESS.json
FROZEN_CONFIG.json

TABLE_CLOSEDWORLD.csv
TABLE_RETRIEVAL.csv
TABLE_OPENWORLD.csv
TABLE_HARD_NEGATIVE.csv
TEST_FROZEN_REPORT.json
PAPER_RESULTS.md
```

These files support the controlled ablation, retrieval, missing-counterpart, and
hard-distractor analyses.

---

## 7. VulFixed

The final VulFixed TEST evidence is under:

```text
VulFix/output/VulFixed_BPRD_PAIRED_FINAL/test/
```

The main files are:

```text
TEST_PREDICTIONS_STRICT_PAIRED.jsonl
TEST_ACCEPTED_PAIRS.csv
TEST_RETRIEVAL.json
TEST_MAIN_TABLE.csv
TEST_MAIN_TABLE.json
TEST_OPENWORLD_25_50_75.csv
TEST_OPENWORLD_25_50_75.json
TEST_HARD_NEGATIVES.json
TEST_FAILURE_DECOMPOSITION.json
TEST_FAILURE_DETAILS.jsonl
TEST_BOOTSTRAP_95CI.json
TEST_VULNERABILITY_TYPE_ANALYSIS.json
VULFIXED_FINAL_REPORT.json
```

The main comparison covers:

```text
Single
Top-1
BPRD
SuppliedPair
```

The per-row reviewer-facing evidence is
`TEST_PREDICTIONS_STRICT_PAIRED.jsonl`.

---

## 8. MegaVul zero-shot replay

The frozen cross-dataset replay is under:

```text
MegaVul/run_v74_bprd_megavul_frozen_replay/
```

Canonical files:

```text
MEGAVUL_FROZEN_REPLAY_PREDICTIONS.jsonl
MEGAVUL_FROZEN_REPLAY_REPORT.json
selected_config.FROZEN.json
relative_head_meta.FROZEN.json
```

Protocol:

```text
PrimeVul-Pair frozen FlowFuse/BPRD
              ↓
       MegaVul paired TEST
              ↓
no training / no fine-tuning / no target calibration
```

The report contains 1,086 rows / 543 complete pairs.

Expected headline results:

| Condition | F1 | MCC | PairAcc |
|---|---:|---:|---:|
| V7.4-Single | 51.08 | 8.73 | 59.85 |
| BPRD-Blind | 66.86 | 36.39 | 73.30 |
| BPRD-Paired | 67.18 | 36.94 | 73.66 |

BPRD-Blind automatically accepts 540/543 pairs.

---

## 9. Optional: reproduce the seed-42 BPRD VALID → TEST protocol

This step is **not required** for quick artifact verification.

The supplied BPRD implementation is:

```text
primevul-pair/BPRD/code/FlowFuse_v74_BPRD_FULL_RELHEAD_seed42_protocol/
```

The original code uses a `config.json`.  The artifact-safe wrapper
`02_RUN_BPRD_SEED42_REPRO.sh` generates a temporary relative/configurable
`config.json` from environment variables, backs up the bundled historical config,
runs the protocol, and restores the historical file afterward.

Required inputs:

```text
TRAIN JSONL
VALID JSONL
TEST JSONL
FlowFuse v7.4 VALID scores
FlowFuse v7.4 TEST scores
```

Set them explicitly:

```bash
export FLOWFUSE_TRAIN_JSONL=/absolute/path/to/train_synced.jsonl
export FLOWFUSE_VALID_JSONL=/absolute/path/to/valid_synced.jsonl
export FLOWFUSE_TEST_JSONL=/absolute/path/to/test_synced.jsonl
export FLOWFUSE_VALID_SCORES=/absolute/path/to/predictions_valid.txt
export FLOWFUSE_TEST_SCORES=/absolute/path/to/predictions_test.txt
```

Run VALID only:

```bash
bash 02_RUN_BPRD_SEED42_REPRO.sh valid
```

This performs:

```text
environment/self-test
TRAIN-only relative-head fitting
VALID blind retrieval
VALID configuration selection
VALID distractor stress
VALID gate
```

TEST is not opened.

Only after VALID passes:

```bash
bash 02_RUN_BPRD_SEED42_REPRO.sh test
```

The wrapper refuses to run TEST unless the reproduction output contains
`VALID_GATE_PASS` with value `PASS`.

By default, reproduction output is written to:

```text
artifact_reproduction/seed42_bprd/
```

This keeps the supplied frozen paper evidence unchanged.

---

## 10. Full FlowFuse model code

The v7.4 model implementation used by PrimeVul-Pair is under:

```text
primevul-pair/code/
├── run.py
├── model.py
├── data_process_single.py
└── c_cfg.py
```

The normal-set model implementation is under:

```text
primevul-normal/code/
```

The artifact does not require retraining these models to verify the frozen paper
results. Full preprocessing/training additionally requires the original dataset,
the UniXcoder backbone, and the preprocessing parser support expected by
`data_process_single.py`.

---

## 11. Artifact integrity and anonymity

Do not upload machine-specific paths, usernames, API keys, tokens, private
endpoints, `.git`, caches, checkpoints, or historical debug logs.

Before publishing the anonymous repository, run:

```bash
grep -RInE \
  '(/media/server207|/home/wuyou|server207|zhangyao|api[_-]?key|access[_-]?token|secret)' \
  . \
  --exclude='*.joblib' --exclude='*.zip' || true
```

The historical package supplied for preparation contained several absolute
server paths in scripts/manifests. Those should be removed or replaced before
the repository is mirrored for anonymous review.

---

## 12. Recommended reviewer path

For most reviewers:

```bash
pip install -r requirements.txt
bash verify_all.sh
```

For reviewers who want to exercise the BPRD protocol:

```bash
# provide the five required inputs first
bash 02_RUN_BPRD_SEED42_REPRO.sh valid

# only after VALID_GATE_PASS=PASS
bash 02_RUN_BPRD_SEED42_REPRO.sh test
```

No baseline repository is required to verify FlowFuse's frozen results.
