#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

bash "$ROOT/00_CHECK_ARTIFACT.sh"
echo
bash "$ROOT/01_VERIFY_FROZEN_RESULTS.sh"

echo
echo "============================================================"
echo "FlowFuse artifact verification complete"
echo "============================================================"
echo "Quick verification: PASS"
echo
echo "Optional full seed-42 BPRD protocol:"
echo "  bash 02_RUN_BPRD_SEED42_REPRO.sh valid"
echo "  bash 02_RUN_BPRD_SEED42_REPRO.sh test   # only after VALID PASS"
