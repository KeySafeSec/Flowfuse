#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:-}"
CODE="$ROOT/primevul-pair/BPRD/code/FlowFuse_v74_BPRD_FULL_RELHEAD_seed42_protocol"
OUT="${FLOWFUSE_REPRO_OUT:-$ROOT/artifact_reproduction/seed42_bprd}"

usage() {
  cat <<'EOF'
Usage:
  bash 02_RUN_BPRD_SEED42_REPRO.sh valid
  bash 02_RUN_BPRD_SEED42_REPRO.sh test

Required environment variables:
  FLOWFUSE_TRAIN_JSONL
  FLOWFUSE_VALID_JSONL
  FLOWFUSE_TEST_JSONL
  FLOWFUSE_VALID_SCORES
  FLOWFUSE_TEST_SCORES

Optional:
  FLOWFUSE_REPRO_OUT   (default: artifact_reproduction/seed42_bprd)
EOF
}

[[ "$MODE" == "valid" || "$MODE" == "test" ]] || { usage; exit 2; }

for v in FLOWFUSE_TRAIN_JSONL FLOWFUSE_VALID_JSONL FLOWFUSE_TEST_JSONL \
         FLOWFUSE_VALID_SCORES FLOWFUSE_TEST_SCORES; do
  [[ -n "${!v:-}" ]] || { echo "[ERROR] $v is not set"; exit 3; }
  [[ -f "${!v}" ]] || { echo "[ERROR] ${!v} does not exist ($v)"; exit 4; }
done

[[ -d "$CODE" ]] || { echo "[ERROR] Missing BPRD code: $CODE"; exit 5; }
mkdir -p "$OUT"

CONFIG="$CODE/config.json"
BACKUP="$CODE/config.json.artifact-backup"
cp "$CONFIG" "$BACKUP"
restore() { mv -f "$BACKUP" "$CONFIG" 2>/dev/null || true; }
trap restore EXIT

python - "$CONFIG" "$OUT" <<'PY'
import json, os, sys
p, out = sys.argv[1], sys.argv[2]
old=json.load(open(p,encoding="utf-8"))
cfg=dict(old)
cfg["project_root"]=os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(p))))))
cfg["train_jsonl"]=os.environ["FLOWFUSE_TRAIN_JSONL"]
cfg["valid_jsonl"]=os.environ["FLOWFUSE_VALID_JSONL"]
cfg["test_jsonl"]=os.environ["FLOWFUSE_TEST_JSONL"]
cfg["v74_valid_scores"]=os.environ["FLOWFUSE_VALID_SCORES"]
cfg["v74_test_scores"]=os.environ["FLOWFUSE_TEST_SCORES"]
cfg["work_dir"]=os.path.abspath(out)
json.dump(cfg,open(p,"w",encoding="utf-8"),indent=2,ensure_ascii=False)
print("[OK] Wrote temporary artifact-safe config:", p)
print("[OK] Reproduction output:", cfg["work_dir"])
PY

cd "$CODE"

if [[ "$MODE" == "valid" ]]; then
  echo "============================================================"
  echo "Seed-42 BPRD reproduction — VALID ONLY"
  echo "TEST WILL NOT BE OPENED"
  echo "============================================================"
  bash RUN_VALID_ONLY.sh
  echo
  echo "[DONE] VALID-only reproduction finished."
  echo "Inspect: $OUT/VALID_GATE_PASS"
else
  GATE="$OUT/VALID_GATE_PASS"
  [[ -f "$GATE" ]] || { echo "[LOCKED] VALID_GATE_PASS is missing: $GATE"; exit 10; }
  [[ "$(tr -d '[:space:]' < "$GATE")" == "PASS" ]] || {
    echo "[LOCKED] VALID gate is not PASS. TEST will not be opened."; exit 11;
  }
  echo "============================================================"
  echo "Seed-42 BPRD reproduction — FROZEN TEST"
  echo "============================================================"
  # Call the Python test entry directly because the historical RUN_TEST_IF_PASS.sh
  # contains a machine-specific gate path.
  python 06_test_if_pass.py --unlock-test
  echo "[DONE] Frozen TEST reproduction finished."
fi
